"""RG4F1 (R675) 차량 전용 시그널 테이블 추출 규칙.  AR 프로젝트(기존 sigtable 규칙)와 분리되어 있고, 이 파일의 규칙은 RG4F1 도면에만 적용된다.

RG4F1 도면이 AR 도면과 다른 점
  1. 레퍼런스: 선/점 없이 글자만 있고 ('시트:WDID.커넥터 핀' 처럼 핀이 공백으로 붙음), 와이어 끝에는 '>>' 두 줄 화살표가 따로 그려져 있다.
  2. 접지: 이중 원 기호이며 선 끝 옆에 '31/43.X1' 단자 글자가 이미 적혀 있다.
  3. 와이어 끝의 점(검정 원 + 흰 X) 아래에 'WDID 설명' 글자 (31/HV001 GROUND BECM) 가 붙는 경우가 있다.
"""
import math
import re

RE_SHEET_REF = re.compile(r"^([^:\s]+):(\S.*?)\s+(\d+[A-Z]?|X)$")          # 시트:WDID.커넥터 핀   (4/200.1.X1 2 / B027:V0:.X1 34)
RE_GND_LBL = re.compile(r"^(\d+/[A-Z0-9]+(?:\.[A-Za-z0-9]+)*?)\.([A-Za-z]\d*)$")   # 31/43.X1 / 31/109.1.X1
RE_DOT_LBL = re.compile(r"^(\d+/[A-Z0-9]+)\s+\S")                          # 31/HV001 GROUND BECM / 1/4 HIGH VOLTAGE BATTERY


def _f(a, k, d=0.0):
    try:
        return float(a.get(k, d))
    except (TypeError, ValueError):
        return d


def _pts(d):
    return [(float(x), float(y)) for x, y in re.findall(r"[ML]\s*(-?[\d.]+)[ ,]+(-?[\d.]+)", d or "")]


def _text(p):
    return (getattr(p, "text", "") or "").strip()


def detect(doc):
    """도면이 RG4F1 방식인지: 레퍼런스 글자에 '시트:WDID 핀' (핀이 공백) 이 있고 AR 방식 ':핀' 이 없으면 RG4F1."""
    sp = col = 0
    for g in doc.groups:
        if g.get("type") != "reference_connector":
            continue
        for p in g.prims:
            if p.tag == "text":
                t = _text(p)
                if RE_SHEET_REF.match(t):
                    sp += 1
                elif re.match(r"^[^:\s]+:\d+/\d+.*:\d+$", t):
                    col += 1
    if sp == 0 and col == 0:      # 시트 레퍼런스가 없는 시트(CAN 버스 등): SP_xxx 이름이 있으면 RG4F1
        for g in doc.groups:
            for p in g.prims:
                if p.tag == "text" and re.match(r"^SP_[A-Z0-9_]+$", _text(p).strip()):
                    return True
        # 그래도 단서가 없으면: 부품 안의 'WDID.커넥터' 라벨(27/13.X1)과 '커넥터 핀' 글자(X1 1) 가 같이 있으면 RG4F1
        lbl = pin = 0
        for g in doc.groups:
            if g.get("type") != "component":
                continue
            for p in g.prims:
                if p.tag == "text":
                    t = _text(p).strip()
                    if re.match(r"^\d+/\d+(?:\.\d+)*\.[A-Za-z]\d*$", t):
                        lbl += 1
                    elif re.match(r"^[A-Za-z]{1,3}\d* \d+[A-Z]?$", t):
                        pin += 1
        if lbl >= 2 and pin >= 2:
            return True
    return sp > 0 and sp >= col


def _chevrons(doc):
    """'>' 모양 3점 path -> (x0, x1, 꼭짓점 y, 그룹 gid)."""
    out = []
    for g in doc.groups:
        for p in g.prims:
            if p.tag != "path" or "A" in p.attrs.get("d", ""):
                continue
            q = _pts(p.attrs.get("d", ""))
            if len(q) != 3 or abs(q[0][0] - q[2][0]) > 0.3:
                continue
            dx, dy = q[1][0] - q[0][0], abs(q[2][1] - q[0][1])
            if 5 <= abs(dx) <= 10 and 10 <= dy <= 18 and abs(q[1][1] - (q[0][1] + q[2][1]) / 2) < 0.5:
                out.append((q[0][0], q[1][0], q[1][1], g.gid))
    return out


class RgRef:
    """'>>' 화살표 + 글자로 이뤄진 레퍼런스.  hit(pt) 는 화살표 두 줄 양끝 어느 쪽이든 와이어 끝이면 참."""

    def __init__(self, x0, x1, y, text):
        self.pt = (x0, y)
        self.pt2 = (x1, y)
        self.texts = [text]
        self.rg = True
        self.g = None

    def hit(self, pt, tol=3.0):
        return math.dist(self.pt, pt) <= tol or math.dist(self.pt2, pt) <= tol


def build_refs(doc):
    """도면의 '>>' 화살표 짝을 찾아 가장 가까운 레퍼런스 글자와 짝지은 RgRef 목록."""
    chev = _chevrons(doc)
    pairs = []
    used = set()
    for i, a in enumerate(chev):
        if i in used:
            continue
        for j, b in enumerate(chev):
            if j <= i or j in used:
                continue
            if abs(a[2] - b[2]) < 0.3 and 6 <= abs(a[1] - b[1]) <= 8.5 and abs(a[0] - b[0]) < 8.5:
                xs = [a[0], a[1], b[0], b[1]]
                pairs.append((min(xs), max(xs), a[2]))
                used.update((i, j))
                break
    texts = []
    seen = set()
    for g in doc.groups:                                  # reference_connector 가 아닌 그룹(component/AUTO_GENERATED 등)에 들어간 레퍼런스 글자도 인식
        isref = g.get("type") == "reference_connector"
        for p in g.prims:
            if p.tag != "text" or ":" not in _text(p):
                continue
            if not isref and not RE_SHEET_REF.match(_text(p)):
                continue
            k = (_text(p), round(_f(p.attrs, "x")), round(_f(p.attrs, "y")))
            if k in seen:
                continue
            seen.add(k)
            texts.append((_f(p.attrs, "x"), _f(p.attrs, "y"), _f(p.attrs, "textLength", 30.0), _text(p)))
    cand = []
    for k, (x0, x1, y) in enumerate(pairs):
        for m, (tx, ty, tl, t) in enumerate(texts):
            dy = ty - y
            if not -3 <= dy <= 10:
                continue
            gap = max(x0 - (tx + tl), tx - x1, 0)
            if gap > 260:
                continue
            cand.append((gap + 4 * abs(dy - 3), k, m))
    cand.sort()
    pu, tu, refs = set(), set(), []
    for _, k, m in cand:
        if k in pu or m in tu:
            continue
        pu.add(k); tu.add(m)
        x0, x1, y = pairs[k]
        refs.append(RgRef(x0, x1, y, texts[m][3]))
    return refs


def ref_end(rf):
    """'시트:WDID.커넥터 핀' -> 끝 정보.  WDID 는 부품 쪽 핀 글자(4/1132.J3, 4/184.1.A)와 같은 형태로 적고, 핀 번호는 port, 설명은 socket."""
    s = (rf.texts[0] if rf.texts else "").strip()
    m = RE_SHEET_REF.match(s)
    if not m:
        return dict(kind="ref", wdid=s, conn=s, port="", des="", term="", ok=False)
    wdid, pin = m.group(2).strip(), m.group(3)
    sp = re.match(r"^(SP\d+[A-Z]*)$", wdid)
    if sp:
        return dict(kind="ref", wdid=wdid, conn=wdid, port="junction", des="junction", term="", ok=True)
    mc = re.match(r"^(.+)\.([A-Za-z]\d*)$", wdid)                  # 4/1170.X1 -> WDID 4/1170, 커넥터 4/1170.X1 (부품 쪽 표기와 같게)
    if mc:
        return dict(kind="ref", wdid=mc.group(1), conn=wdid, port=pin, des="socket", term="", ok=True)
    return dict(kind="ref", wdid=wdid, conn=wdid, port=pin, des="socket", term="", ok=True)


def label_ends(doc):
    """접지 단자 글자(31/43.X1) 와 점 아래 글자(31/HV001 GROUND BECM) 목록."""
    gl, dl = [], []
    for g in doc.groups:
        if g.get("tag") == "AUTO_GENERATED":
            continue
        for p in g.prims:
            if p.tag != "text":
                continue
            t = _text(p)
            x, y, L = _f(p.attrs, "x"), _f(p.attrs, "y"), _f(p.attrs, "textLength", 30.0)
            if RE_GND_LBL.match(t):
                gl.append((x, y, L, t))
            elif RE_DOT_LBL.match(t) and g.cls == "wire":
                dl.append((x, y, L, t))
    return gl, dl


def circle_ground_end(pt, doc_rings, gl):
    """와이어 끝(pt) 이 이중 원 접지 기호 위쪽에 닿아 있으면 가장 가까운 '31/NN.Xn' 글자로 끝을 만든다."""
    for cx, cy, r in doc_rings:
        if r >= 6 and abs(pt[0] - cx) <= 3 and 0 <= (cy - r) - pt[1] <= 3 + 0.01 or (r >= 6 and math.dist(pt, (cx, cy - r)) <= 3):
            best, bd = None, 60.0
            for x, y, L, t in gl:
                d = math.hypot(x + L / 2 - pt[0], y - 3 - pt[1])
                if d < bd:
                    best, bd = t, d
            if best:
                m = RE_GND_LBL.match(best)
                return dict(kind="ref", wdid=m.group(1), conn=best, port="1", des=m.group(2), term="", ok=True, ground=True)
            return None
    return None


def stub_segments(doc):
    """접지 단자 선(짧은 2점 path)들 -> [(a, b)].  와이어 그룹 안/밖 어디에 있든 모은다."""
    out = []
    for g in doc.groups:
        if g.cls != "wire":
            continue
        for p in g.prims[1:] if g.prims and g.prims[0].tag == "path" else g.prims:
            if p.tag == "path" and "A" not in p.attrs.get("d", ""):
                q = _pts(p.attrs.get("d", ""))
                if len(q) == 2 and 5 <= math.dist(q[0], q[1]) <= 40 and abs(q[0][0] - q[1][0]) < 0.3:
                    out.append((q[0], q[1]))
    return out


def follow_stub(pt, segs):
    """와이어 끝 pt 에서 다른 와이어 그룹의 짧은 세로선이 이어져 있으면 그 끝점을 돌려준다 (두 와이어가 한 접지 단자에 같이 물린 경우)."""
    cur = pt
    for _ in range(3):
        nxt = None
        for a, b in segs:
            for u, v in ((a, b), (b, a)):
                if math.dist(u, cur) <= 1.5 and v[1] > u[1] + 1.5:               # 접지 기호는 선 아래쪽에 있다
                    nxt = v
        if not nxt:
            break
        cur = nxt
    return cur


def rings(doc):
    out = []
    for g in doc.groups:
        for p in g.prims:
            if p.tag == "ellipse" and p.attrs.get("fill") == "none":
                r = _f(p.attrs, "rx")
                if 6 <= r <= 8:
                    out.append((_f(p.attrs, "cx"), _f(p.attrs, "cy"), r))
    return out


def dot_label_end(pt, doc_dots, dl):
    """와이어 끝이 점(검정 원 + 흰 X)이고 그 아래 'WDID 설명' 글자가 있으면 그 WDID 를 끝으로 한다."""
    for cx, cy in doc_dots:
        if math.dist(pt, (cx, cy)) <= 3:
            best, bd = None, 40.0
            for x, y, L, t in dl:
                if -4 <= x - cx <= 5 + 100 or -40 <= x - cx:
                    dy = (y - 8) - cy
                    if 4 <= dy <= 40 and x - 40 <= cx <= x + L + 40:
                        d = abs(dy) + abs((x + L / 2) - cx) * 0.3
                        if d < bd:
                            best, bd = t, d
            if best:
                w = RE_DOT_LBL.match(best).group(1)
                return dict(kind="ref", wdid=w, conn=w, port="1", des="socket", term="", ok=True, guess=True)
    return None


def dots(doc):
    out = []
    for g in doc.groups:
        if g.cls != "wire":
            continue
        for p in g.prims:
            if p.tag == "ellipse" and p.attrs.get("fill") not in (None, "none") and 4.5 <= _f(p.attrs, "rx") <= 6:
                out.append((_f(p.attrs, "cx"), _f(p.attrs, "cy")))
    return out
