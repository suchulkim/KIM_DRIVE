"""라이선스 키 확인 (PC 1대에 묶인 키).  EXE 로 실행할 때만 검사한다 (python main.py 개발 실행은 검사 안 함).

키 = XXXX-XXXX-XXXX-XXXX (16자) : [만료일 16비트 | HMAC 64비트] 를 base32 로 표기.  만료일 0 = 영구.
키는 PC 고유 코드에 묶여 있어 다른 PC 에서는 통과하지 못한다.  만료일이 지나면 실행되지 않는다.
키 생성: tools/make_key.py (개발자 전용 - SECRET 이 같은 licensing.py 를 사용)
"""
import base64
import datetime
import hashlib
import hmac
import os
import sys

SECRET = b"5c7190af30f18e4194d4d277328841b2c9fd4d5cb6a90b6e"       # 바꾸고 싶으면 다른 임의 문자열로 바꾸고 다시 빌드 (이미 발급한 키는 무효가 됨)
EPOCH = datetime.date(2020, 1, 1)
WARN_DAYS = 14


def machine_code():
    raw = ""
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY)
        raw = str(winreg.QueryValueEx(k, "MachineGuid")[0])
    except Exception:
        pass
    if not raw:
        import uuid
        raw = "mac-%012x" % uuid.getnode()
    h = hashlib.sha256(("WDStudio|" + raw).encode("utf-8")).hexdigest().upper()[:20]
    return "-".join(h[i:i + 4] for i in range(0, 20, 4))


def _norm(code):
    return "".join(c for c in (code or "").upper() if c.isalnum())


def make_key(code, expiry=None):
    """code: PC 고유 코드, expiry: datetime.date | None(영구) -> 'XXXX-XXXX-XXXX-XXXX'"""
    days = 0 if expiry is None else (expiry - EPOCH).days
    if not 0 < days < 65536 and expiry is not None:
        raise ValueError("만료일 범위 오류")
    head = days.to_bytes(2, "big")
    mac = hmac.new(SECRET, _norm(code).encode() + b"|" + head, hashlib.sha256).digest()[:8]
    s = base64.b32encode(head + mac).decode().rstrip("=")
    return "-".join(s[i:i + 4] for i in range(0, 16, 4))


def parse_key(code, key):
    """-> (유효여부, 만료일|None).  PC 코드/키 불일치면 (False, None)"""
    try:
        s = "".join(c for c in (key or "").upper() if c.isalnum())
        raw = base64.b32decode(s + "=" * (-len(s) % 8))
        if len(raw) != 10:
            return False, None
        head, mac = raw[:2], raw[2:]
        exp = hmac.new(SECRET, _norm(code).encode() + b"|" + head, hashlib.sha256).digest()[:8]
        if not hmac.compare_digest(mac, exp):
            return False, None
        d = int.from_bytes(head, "big")
        return True, (None if d == 0 else EPOCH + datetime.timedelta(days=d))
    except Exception:
        return False, None


# ------------------------------------------------------------------ 저장
def _dir():
    d = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "WDStudio")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def _key_path():
    return os.path.join(_dir(), "license.key")


def _state_path():
    return os.path.join(_dir(), "wd.state")


def _tag(d):
    return hashlib.sha256(("%s|%s" % (d, machine_code())).encode()).hexdigest()[:16]


def _state_read():
    try:
        d, h = open(_state_path(), encoding="utf-8").read().strip().split("|")
        if _tag(d) == h:
            return datetime.date.fromisoformat(d)
    except Exception:
        pass
    return None


def _state_write(d):
    try:
        open(_state_path(), "w", encoding="utf-8").write("%s|%s" % (d.isoformat(), _tag(d.isoformat())))
    except Exception:
        pass


def check(force=False):
    """-> (상태, 만료일|None).  상태: 'ok' | 'dev' | 'none' | 'bad' | 'expired' | 'clock'
    force=True 면 개발 실행에서도 검사 (시험용)"""
    if not force and not getattr(sys, "frozen", False):
        return "dev", None                                   # 개발(스크립트) 실행은 검사하지 않는다
    try:
        key = open(_key_path(), encoding="utf-8").read().strip()
    except Exception:
        return "none", None
    ok, exp = parse_key(machine_code(), key)
    if not ok:
        return "bad", None
    today = datetime.date.today()
    last = _state_read()
    if exp is not None:
        if last and today < last - datetime.timedelta(days=1):       # 시스템 날짜를 되돌린 흔적
            return "clock", exp
        if today > exp:
            return "expired", exp
    _state_write(max(today, last) if last else today)
    return "ok", exp


def save_key(key):
    """입력한 키가 이 PC 에 맞으면 저장 -> (성공, 문구)"""
    ok, exp = parse_key(machine_code(), key)
    if not ok:
        return False, "라이선스 키가 올바르지 않거나 이 PC 용이 아닙니다."
    if exp is not None and datetime.date.today() > exp:
        return False, "만료된 키입니다 (%s)." % exp
    try:
        open(_key_path(), "w", encoding="utf-8").write(key.strip().upper())
    except Exception as ex:
        return False, str(ex)
    return True, ""


_MSG = {"none": "라이선스 키를 입력하세요.", "bad": "저장된 라이선스 키가 올바르지 않습니다.",
        "clock": "시스템 날짜가 이전 사용 기록보다 과거입니다. 날짜를 바로잡은 뒤 다시 실행하세요."}


def enforce_cli():
    st, exp = check()
    if st in ("ok", "dev"):
        return
    print("라이선스 만료 (%s)" % exp if st == "expired" else _MSG.get(st, st), " PC 코드:", machine_code())
    sys.exit(2)


def enforce_gui():
    from PyQt6.QtWidgets import QMessageBox
    st, exp = check()
    if st == "dev":
        return
    if st == "ok":
        if exp is not None and (exp - datetime.date.today()).days <= WARN_DAYS:
            QMessageBox.information(None, "라이선스", "라이선스가 %s 에 만료됩니다.\n갱신이 필요하면 PC 코드를 보내 새 키를 받으세요.\nPC 코드: %s" % (exp, machine_code()))
        return
    if st == "clock":
        QMessageBox.critical(None, "라이선스", _MSG["clock"]); sys.exit(2)
    reason = "라이선스가 만료되었습니다 (%s). 새 키를 입력하세요." % exp if st == "expired" else _MSG.get(st, "")
    if not key_dialog(reason) or check()[0] != "ok":
        sys.exit(2)


def key_dialog(reason=""):
    from PyQt6.QtWidgets import QApplication, QDialog, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton, QVBoxLayout
    dlg = QDialog(); dlg.setWindowTitle("라이선스 키 입력"); dlg.setMinimumWidth(440)
    lay = QVBoxLayout(dlg)
    lay.addWidget(QLabel((reason + "\n\n" if reason else "") + "PC 코드를 개발자에게 보내 라이선스 키를 받으세요."))
    e = QLineEdit(machine_code()); e.setReadOnly(True); lay.addWidget(e)
    k = QLineEdit(); k.setPlaceholderText("XXXX-XXXX-XXXX-XXXX"); lay.addWidget(k)
    row = QHBoxLayout(); b_copy = QPushButton("PC 코드 복사"); b_ok = QPushButton("확인"); b_exit = QPushButton("종료")
    for b in (b_copy, b_ok, b_exit):
        row.addWidget(b)
    lay.addLayout(row)
    b_copy.clicked.connect(lambda: QApplication.clipboard().setText(e.text()))
    b_exit.clicked.connect(dlg.reject)

    def ok():
        good, msg = save_key(k.text())
        if good:
            dlg.accept()
        else:
            QMessageBox.warning(dlg, "라이선스", msg)
    b_ok.clicked.connect(ok); k.returnPressed.connect(ok)
    return dlg.exec() == QDialog.DialogCode.Accepted


def info_text():
    st, exp = check()
    if st == "dev":
        return "개발 모드 (라이선스 검사 안 함)\nPC 코드: " + machine_code()
    return "PC 코드: %s\n만료일: %s" % (machine_code(), exp or "영구")
