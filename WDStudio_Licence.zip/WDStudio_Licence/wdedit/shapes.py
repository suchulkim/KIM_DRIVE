"""도형/그림/표 개체 생성과 변형(크기·회전·대칭) 계산 (GUI 와 무관한 순수 로직)."""
import base64
import math

from model import Group, Prim, fmt, local_rect, xf_get, xf_set

# (키, 표시 이름)
KINDS = [("line", "직선"), ("arrow", "화살표 선"), ("rect", "사각형"), ("round", "둥근 사각형"), ("ellipse", "타원"),
         ("triangle", "이등변 삼각형"), ("rtriangle", "직각 삼각형"), ("diamond", "마름모"), ("trapezoid", "사다리꼴"),
         ("pentagon", "오각형"), ("hexagon", "육각형"), ("star", "별"), ("rarrow", "오른쪽 화살표"), ("plus", "더하기")]
KIND_NAME = dict(KINDS)

# 8방향 핸들 (dx, dy) : 사각형 기준 좌우/상하 방향
HANDLES = {"nw": (-1, -1), "n": (0, -1), "ne": (1, -1), "e": (1, 0), "se": (1, 1), "s": (0, 1), "sw": (-1, 1), "w": (-1, 0)}


def _unit_poly(kind):
    """단위 정사각형(0~1) 안의 다각형 꼭짓점."""
    if kind == "triangle":
        return [(0.5, 0), (1, 1), (0, 1)]
    if kind == "rtriangle":
        return [(0, 0), (1, 1), (0, 1)]
    if kind == "diamond":
        return [(0.5, 0), (1, 0.5), (0.5, 1), (0, 0.5)]
    if kind == "trapezoid":
        return [(0.2, 0), (0.8, 0), (1, 1), (0, 1)]
    if kind == "pentagon":
        return [(0.5, 0), (1, 0.38), (0.81, 1), (0.19, 1), (0, 0.38)]
    if kind == "hexagon":
        return [(0.25, 0), (0.75, 0), (1, 0.5), (0.75, 1), (0.25, 1), (0, 0.5)]
    if kind == "star":
        pts = []
        for i in range(10):
            r = 0.5 if i % 2 == 0 else 0.2
            a = -math.pi / 2 + i * math.pi / 5
            pts.append((0.5 + r * math.cos(a), 0.5 + r * math.sin(a)))
        return pts
    if kind == "rarrow":
        return [(0, 0.3), (0.6, 0.3), (0.6, 0), (1, 0.5), (0.6, 1), (0.6, 0.7), (0, 0.7)]
    if kind == "plus":
        return [(0.35, 0), (0.65, 0), (0.65, 0.35), (1, 0.35), (1, 0.65), (0.65, 0.65), (0.65, 1), (0.35, 1), (0.35, 0.65), (0, 0.65), (0, 0.35), (0.35, 0.35)]
    return None


def _geometry(kind, x, y, w, h, sw=1.0):
    """도형 종류별 SVG 속성(tag, {geometry attrs}) 계산."""
    if kind == "rect":
        return "rect", {"x": fmt(x), "y": fmt(y), "width": fmt(w), "height": fmt(h)}
    if kind == "round":
        r = min(w, h) * 0.18
        return "rect", {"x": fmt(x), "y": fmt(y), "width": fmt(w), "height": fmt(h), "rx": fmt(r), "ry": fmt(r)}
    if kind == "ellipse":
        return "ellipse", {"cx": fmt(x + w / 2), "cy": fmt(y + h / 2), "rx": fmt(w / 2), "ry": fmt(h / 2)}
    if kind == "line":
        return "path", {"d": "M%s,%s L%s,%s" % (fmt(x), fmt(y), fmt(x + w), fmt(y + h))}
    if kind == "arrow":
        L = math.hypot(w, h) or 1.0
        ux, uy = w / L, h / L
        hs = min(max(8.0, 4.0 * sw), L * 0.6)
        bx, by = x + w - ux * hs, y + h - uy * hs
        px, py = -uy * hs * 0.45, ux * hs * 0.45
        return "path", {"d": "M%s,%s L%s,%s M%s,%s L%s,%s L%s,%s Z" % (
            fmt(x), fmt(y), fmt(bx), fmt(by), fmt(x + w), fmt(y + h), fmt(bx + px), fmt(by + py), fmt(bx - px), fmt(by - py))}
    pts = _unit_poly(kind)
    if pts is None:
        return _geometry("rect", x, y, w, h)
    d = " ".join(("M" if i == 0 else "L") + "%s,%s" % (fmt(x + u * w), fmt(y + v * h)) for i, (u, v) in enumerate(pts)) + " Z"
    return "path", {"d": d}


def make_prim(kind, x, y, w, h, stroke="#000000", fill="none", sw=1.5):
    tag, geo = _geometry(kind, x, y, w, h, sw)
    at = dict(geo)
    if kind == "arrow":
        fill = stroke
    elif kind == "line":
        fill = "none"
    at.update({"stroke": stroke, "fill": fill, "stroke-width": fmt(sw), "stroke-linejoin": "miter" if kind not in ("round",) else "round",
               "data-shape": kind, "data-rect": " ".join(fmt(v) for v in (x, y, w, h))})
    return Prim(tag, at)


def regen(p):
    """data-rect 에 맞춰 도형 기하 속성을 다시 계산 (스타일/변환은 유지)."""
    kind = p.attrs.get("data-shape")
    if not kind:
        return
    x, y, w, h = local_rect(p)
    tag, geo = _geometry(kind, x, y, w, h, float(p.attrs.get("stroke-width", 1.5)))
    for k in ("x", "y", "width", "height", "rx", "ry", "cx", "cy", "d"):
        if k in p.attrs and k not in geo:
            del p.attrs[k]
    for k, v in geo.items():
        p.attrs[k] = v
    # 속성 순서 정리(기하 -> 스타일)
    order = list(geo) + [k for k in p.attrs if k not in geo]
    p.attrs = {k: p.attrs[k] for k in order}


def set_rect(p, x, y, w, h):
    """사각형(위치/크기) 변경. 그림은 x,y,width,height, 도형은 data-rect + 기하 재계산. 회전/대칭 기준점도 갱신."""
    if p.tag == "image":
        p.attrs.update(x=fmt(x), y=fmt(y), width=fmt(w), height=fmt(h))
    else:
        p.attrs["data-rect"] = " ".join(fmt(v) for v in (x, y, w, h)); regen(p)
    a, sx, sy = xf_get(p)
    xf_set(p, a, sx, sy)


def set_xf(p, ang, sx, sy):
    ang = ((ang + 180) % 360) - 180
    xf_set(p, ang, sx, sy)


def is_obj(p):
    return p.tag == "image" or "data-shape" in p.attrs


# ---------------------------------------------------------------- 크기/회전 계산
def _mat(a, sx, sy):
    c, s = math.cos(math.radians(a)), math.sin(math.radians(a))
    return lambda vx, vy: (c * (sx * vx) - s * (sy * vy), s * (sx * vx) + c * (sy * vy))


def _inv(a, sx, sy):
    c, s = math.cos(math.radians(-a)), math.sin(math.radians(-a))
    return lambda vx, vy: ((c * vx - s * vy) / sx, (s * vx + c * vy) / sy)


def to_scene(rect, a, sx, sy, q):
    """로컬 점 q -> 장면 좌표."""
    x, y, w, h = rect; cx, cy = x + w / 2, y + h / 2
    vx, vy = _mat(a, sx, sy)(q[0] - cx, q[1] - cy)
    return cx + vx, cy + vy


def handle_pos(rect, a, sx, sy, dx, dy):
    x, y, w, h = rect
    return to_scene(rect, a, sx, sy, (x + w / 2 + dx * w / 2, y + h / 2 + dy * h / 2))


def corners(rect, a, sx, sy):
    x, y, w, h = rect
    return [to_scene(rect, a, sx, sy, q) for q in ((x, y), (x + w, y), (x + w, y + h), (x, y + h))]


def resize(rect, a, sx, sy, kind, P, keep_aspect=False, min_size=1.0, allow_zero=False):
    """핸들(kind)을 장면 좌표 P 로 끌었을 때의 새 사각형. 반대편(기준점)은 화면에서 고정."""
    x, y, w, h = rect; cx, cy = x + w / 2, y + h / 2
    dx, dy = HANDLES[kind]
    M, Mi = _mat(a, sx, sy), _inv(a, sx, sy)
    ax_, ay_ = M(-dx * w / 2, -dy * h / 2)
    As = (cx + ax_, cy + ay_)
    u = Mi(P[0] - As[0], P[1] - As[1])
    lo = 0.0 if allow_zero else min_size
    nw = max(lo, dx * u[0]) if dx else w
    nh = max(lo, dy * u[1]) if dy else h
    if keep_aspect and dx and dy and w > 0 and h > 0:
        f = max(nw / w, nh / h); nw, nh = w * f, h * f
    off = M(dx * nw / 2, dy * nh / 2)
    C = (As[0] + off[0], As[1] + off[1])
    return (C[0] - nw / 2, C[1] - nh / 2, nw, nh)


def rotate_angle(rect, sy, P, snap=False):
    x, y, w, h = rect; cx, cy = x + w / 2, y + h / 2
    th = math.degrees(math.atan2(P[1] - cy, P[0] - cx))
    a = th + 90 if sy > 0 else th - 90
    if snap:
        a = round(a / 15.0) * 15.0
    return ((a + 180) % 360) - 180


def flip(a, sx, sy, horizontal):
    """화면 기준 좌우(horizontal) / 상하 대칭."""
    return (-a, -sx, sy) if horizontal else (-a, sx, -sy)


# ---------------------------------------------------------------- 그룹(개체) 생성
def _next_tag(doc, pre):
    used = {g.get("tag", "") for g in doc.groups}
    n = 1070000 + doc.next_id()
    while "%s_%d" % (pre, n) in used:
        n += 1
    return "%s_%d" % (pre, n)


def image_group(doc, data, pw, ph, x, y, w, h, mime="image/png"):
    g = Group(gid=doc.next_id(), cls="symbol")
    g.meta = [("type", "drawing", True), ("tag", _next_tag(doc, "IMAGE"), True)]
    b64 = base64.b64encode(data).decode("ascii")
    g.prims.append(Prim("image", {"x": fmt(x), "y": fmt(y), "width": fmt(w), "height": fmt(h), "preserveAspectRatio": "none",
                                  "data-natural": "%d %d" % (pw, ph), "xlink:href": "data:%s;base64," % mime + b64}))
    return g


def shape_group(doc, kind, x, y, w, h, **style):
    g = Group(gid=doc.next_id(), cls="symbol")
    g.meta = [("type", "drawing", True), ("tag", _next_tag(doc, "SHAPE"), True)]
    g.prims.append(make_prim(kind, x, y, w, h, **style))
    return g


# ---------------------------------------------------------------- 표
def _text_len(s, fs):
    return sum(fs * (0.55 if ord(c) < 0x2E80 else 1.0) for c in s)


def table_prims(x, y, rows, cols, cw, ch, texts, fs=10.0, header=True, sw=1.0):
    """표 prim 목록 : [머리글 배경, 격자선(data-table 보관), 셀 글자...]."""
    out = []
    W, H = cols * cw, rows * ch
    if header and rows > 0:
        out.append(Prim("rect", {"x": fmt(x), "y": fmt(y), "width": fmt(W), "height": fmt(ch), "stroke": "none", "fill": "#e6e6e6", "stroke-width": "0"}))
    d = ["M%s,%s L%s,%s L%s,%s L%s,%s Z" % (fmt(x), fmt(y), fmt(x + W), fmt(y), fmt(x + W), fmt(y + H), fmt(x), fmt(y + H))]
    for r in range(1, rows):
        d.append("M%s,%s L%s,%s" % (fmt(x), fmt(y + r * ch), fmt(x + W), fmt(y + r * ch)))
    for c in range(1, cols):
        d.append("M%s,%s L%s,%s" % (fmt(x + c * cw), fmt(y), fmt(x + c * cw), fmt(y + H)))
    out.append(Prim("path", {"d": " ".join(d), "stroke": "#000000", "fill": "none", "stroke-width": fmt(sw), "stroke-linejoin": "miter",
                             "data-table": " ".join(fmt(v) for v in (rows, cols, x, y, cw, ch, fs, 1 if header else 0))}))
    for r in range(rows):
        for c in range(cols):
            t = texts[r][c] if r < len(texts) and c < len(texts[r]) else ""
            if not t:
                continue
            L = _text_len(t, fs)
            if L > cw - 4:                                   # 칸을 넘으면 글자 폭을 칸에 맞춤
                L = cw - 4
            tx = x + c * cw + (cw - L) / 2
            ty = y + r * ch + (ch + fs * 0.75) / 2 - fs * 0.1
            out.append(Prim("text", {"x": fmt(tx), "y": fmt(ty), "text-anchor": "start", "fill": "#000000",
                                     "transform": "rotate(0,%s,%s)" % (fmt(tx), fmt(ty)), "textLength": fmt(L),
                                     "font-family": "Times New Roman", "font-size": fmt(fs), "data-cell": "%d,%d" % (r, c)}, t))
    return out


def table_group(doc, x, y, rows, cols, cw, ch, texts, fs=10.0, header=True):
    g = Group(gid=doc.next_id(), cls="symbol")
    g.meta = [("type", "drawing", True), ("tag", _next_tag(doc, "TABLE"), True)]
    g.prims = table_prims(x, y, rows, cols, cw, ch, texts, fs, header)
    return g


def table_spec(g):
    """(rows, cols, x, y, cw, ch, fs, header, texts) — 표 그룹이 아니면 None."""
    for p in g.prims:
        if "data-table" in p.attrs:
            v = [float(t) for t in p.attrs["data-table"].split()]
            rows, cols = int(v[0]), int(v[1])
            texts = [["" for _ in range(cols)] for _ in range(rows)]
            for q in g.prims:
                if q.tag == "text" and "data-cell" in q.attrs:
                    r, c = (int(t) for t in q.attrs["data-cell"].split(","))
                    if r < rows and c < cols:
                        texts[r][c] = q.text
            return rows, cols, v[2], v[3], v[4], v[5], v[6], bool(v[7]), texts
    return None


# ---------------------------------------------------------------- 그림 자르기
def image_bytes(p):
    """<image> 의 data URI -> (bytes, mime) / 실패 시 (None, None)"""
    h = p.attrs.get("xlink:href") or p.attrs.get("href") or ""
    if not h.startswith("data:") or "," not in h:
        return None, None
    head, b64 = h.split(",", 1)
    try:
        return base64.b64decode(b64), head[5:].split(";")[0]
    except Exception:
        return None, None


def crop_image(p, l, t, r, b):
    """그림 p 를 자른다. l,t,r,b = 왼/위/오른/아래에서 잘라낼 비율(0~1). 픽셀 데이터를 실제로 잘라 다시 저장하므로
    어떤 뷰어에서도 동일하게 보인다. 회전/대칭이 있어도 화면상 남은 부분의 위치는 그대로 유지. 성공 시 True."""
    from PyQt6.QtCore import QBuffer, QByteArray, QIODevice, QRect
    from PyQt6.QtGui import QImage
    data, mime = image_bytes(p)
    if data is None:
        return False
    img = QImage.fromData(data)
    if img.isNull():
        return False
    pw, ph = img.width(), img.height()
    x0 = max(0, min(pw - 1, round(l * pw))); y0 = max(0, min(ph - 1, round(t * ph)))
    x1 = max(x0 + 1, min(pw, round(pw - r * pw))); y1 = max(y0 + 1, min(ph, round(ph - b * ph)))
    if x0 == 0 and y0 == 0 and x1 == pw and y1 == ph:
        return True
    sub = img.copy(QRect(x0, y0, x1 - x0, y1 - y0))
    jpg = "jpeg" in (mime or "") or "jpg" in (mime or "")
    ba = QByteArray(); buf = QBuffer(ba); buf.open(QIODevice.OpenModeFlag.WriteOnly)
    sub.save(buf, "JPG" if jpg else "PNG", 90 if jpg else -1); buf.close()
    X, Y, W, H = local_rect(p)
    nx, ny = X + W * x0 / pw, Y + H * y0 / ph
    nw, nh = W * (x1 - x0) / pw, H * (y1 - y0) / ph
    a, sx, sy = xf_get(p)
    if abs(a) > 1e-9 or sx != 1 or sy != 1:                      # 회전/대칭 중심이 바뀌므로 화면 위치 보정
        M = _mat(a, sx, sy)
        c0 = (X + W / 2, Y + H / 2); c1 = (nx + nw / 2, ny + nh / 2)
        wx, wy = M(c1[0] - c0[0], c1[1] - c0[1])
        nx += c0[0] + wx - c1[0]; ny += c0[1] + wy - c1[1]
    key = "xlink:href" if "xlink:href" in p.attrs else "href"
    p.attrs[key] = "data:%s;base64," % ("image/jpeg" if jpg else "image/png") + base64.b64encode(bytes(ba)).decode("ascii")
    p.attrs["data-natural"] = "%d %d" % (x1 - x0, y1 - y0)
    set_rect(p, nx, ny, nw, nh)
    return True
