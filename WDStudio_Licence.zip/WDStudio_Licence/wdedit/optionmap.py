"""option 코드 -> option_description 사전 (option_map.json). AIM SVG 를 열 때마다 새 항목을 학습한다."""
import json, os

PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "option_map.json")
DEFAULT = {"ALL": "STD", "AL04": "{Panoramic Sunroof}", "LE02": "{Auto Power Tailgate}",
           "DE04": "LED_REAR", "DE05": "{Rear LED BAR Lamp : To be deleted}"}


def load():
    m = dict(DEFAULT)
    try:
        with open(PATH, encoding="utf-8") as f:
            m.update(json.load(f))
    except Exception:
        pass
    return m


def save(m):
    try:
        with open(PATH, "w", encoding="utf-8") as f:
            json.dump(m, f, ensure_ascii=False, indent=2, sort_keys=True)
    except Exception:
        pass


def learn(doc):
    """doc 의 wire 에서 option -> option_description 을 학습(기존 값은 덮어쓰지 않음). 추가 건수 반환."""
    m = load(); n = 0
    for g in doc.groups:
        if g.kind == "wire":
            o, d = g.get("option", ""), g.get("option_description", "")
            if o and d and o not in m:
                m[o] = d; n += 1
    if n:
        save(m)
    return n


def apply(doc):
    """option_description 이 비어 있는 wire 를 사전으로 채움. 채운 건수 반환."""
    m = load(); n = 0
    for g in doc.groups:
        if g.kind == "wire" and g.has("option_description") and not g.get("option_description") and g.get("option") in m:
            g.set("option_description", m[g.get("option")], True); n += 1
    return n
