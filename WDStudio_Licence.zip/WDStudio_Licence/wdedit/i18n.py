"""다국어(한국어/English). 한국어 문자열이 key 이다 : tr("열기") -> 영어 모드에서는 EN["열기"]."""
import json
import os

LANG = "ko"
_SETTINGS = os.path.join(os.path.expanduser("~"), ".wdstudio_settings.json")


def load_lang():
    global LANG
    try:
        with open(_SETTINGS, encoding="utf-8") as f:
            LANG = json.load(f).get("lang", "ko")
    except Exception:
        LANG = "ko"
    return LANG


def set_lang(lang):
    global LANG
    LANG = lang if lang in ("ko", "en") else "ko"
    set_setting("lang", LANG)


def _read():
    try:
        with open(_SETTINGS, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def get_setting(key, default=None):
    return _read().get(key, default)


def set_setting(key, value):
    d = _read(); d[key] = value
    try:
        with open(_SETTINGS, "w", encoding="utf-8") as f:
            json.dump(d, f)
    except Exception:
        pass


def tr(s):
    if LANG == "en":
        return EN.get(s, s)
    return s


EN = {
    '도구': 'Tools', '시그널 테이블 내보내기(엑셀)…': 'Export signal table (Excel)…', '시그널 테이블 대조 / 도면 기준 엑셀 수정…': 'Compare signal table / update Excel from drawings…', '시그널 테이블 내보내기': 'Export signal table', '시그널 테이블 대조 / 도면 기준 엑셀 수정': 'Compare signal table / update Excel from drawings', '시그널 테이블': 'Signal table', '자동 판별': 'Auto-detect', '차량 규칙': 'Vehicle rules', '배선도 SVG 에서 시그널 테이블(엑셀)을 만듭니다. wire 가 없는 도면은 제외됩니다.': 'Builds the signal table (Excel) from the wiring-diagram SVGs. Drawings without wires are skipped.', '배선도 SVG 의 wire / 부품 / 커넥터 정보에서 시그널 테이블(엑셀)을 만듭니다. wire 가 없는 도면은 제외됩니다.': 'Builds the signal table (Excel) from wires / components / connectors in the SVGs. Drawings without wires are skipped.', "도면을 기준으로 기존 시그널 테이블(엑셀)의 값을 수정합니다. 수정한 칸은 노란색, 추가한 행은 녹색으로 표시하고 '변경 내역' 시트를 만듭니다. 원본 파일은 바꾸지 않고 새 파일로 저장합니다.": "Updates an existing signal table (Excel) using the drawings as the reference. Changed cells are yellow, added rows green, and a 'Change log' sheet is added. The original file is not modified; a new file is saved.", '도면(SVG) 목록': 'Drawing (SVG) list', '열린 문서 추가': 'Add open documents', '파일 추가…': 'Add files…', '폴더 추가…': 'Add folder…', '선택 삭제': 'Remove selected', '목록 비우기': 'Clear list', '엑셀 선택…': 'Select Excel…', '기존 시그널 테이블(엑셀)': 'Existing signal table (Excel)', '저장 위치…': 'Save as…', '저장할 엑셀': 'Excel to save', '결과 폴더 열기': 'Open result folder', '실행': 'Run', '열림': 'open', '도면(SVG) 선택': 'Select drawings (SVG)', '폴더 선택': 'Select folder', '저장할 엑셀 파일을 지정하세요.': 'Specify the Excel file to save.', '기존 시그널 테이블(엑셀)을 선택하세요.': 'Select the existing signal table (Excel).', '원본을 덮어쓰지 않도록 다른 이름으로 저장하세요.': 'Save under a different name so the original is not overwritten.', '읽는 중: ': 'Reading: ', '읽기 실패': 'Read failed', '선택된 도면이 없습니다.': 'No drawing selected.', '와이어가 있는 도면이 없어 만들 내용이 없습니다.': 'No drawing with wires, nothing to create.', '완료': 'Done', '행': 'rows', '수정한 칸': 'cells changed', '수정한 행': 'rows changed', '추가한 행': 'rows added', '변경 내역 시트 참조': 'see Change log sheet', '제외된 도면(와이어 없음)': 'Skipped drawings (no wires)', '시그널 테이블 저장: ': 'Signal table saved: ',
    # 메뉴
    "파일": "File", "편집": "Edit", "보기": "View", "그리기": "Draw", "규칙": "Rules", "설정": "Settings", "도움말": "Help",
    "열기 (PDF/SVG)…": "Open (PDF/SVG)…", "SVG 저장": "Save SVG", "다른 이름으로 SVG 저장…": "Save SVG As…",
    "PDF 내보내기…": "Export PDF…", "종료": "Exit",
    "실행 취소": "Undo", "다시 실행": "Redo", "잘라내기": "Cut", "복사": "Copy", "붙여넣기": "Paste", "삭제": "Delete",
    "전체 선택": "Select All", "전체 보기": "Fit View", "확대": "Zoom In", "축소": "Zoom Out",
    "규칙 검사": "Rule Check", "자동 수정": "Auto Fix", "이미지 네비게이션 ID 재생성": "Regenerate image-navigation IDs",
    "규칙 설명…": "Rule Help…", "WD Studio 정보…": "About WD Studio…", "언어 / Language": "Language / 언어",
    "한국어": "Korean", "English": "English",
    # 툴바
    "선택": "Select", "이동": "Pan", "선택/이동": "Select / Pan", "도구": "Tools", "표 크기": "Table size", "칸": "cell", "그림 자르기…": "Crop picture…", "그림 자르기": "Crop picture", "자를 그림 1개를 먼저 선택하세요": "Select one picture to crop first", "그림을 잘랐습니다": "Picture cropped", "초기화": "Reset", "왼쪽": "Left", "위쪽": "Top", "오른쪽": "Right", "아래쪽": "Bottom", "남는 크기: %d × %d px": "Result size: %d × %d px", "이 그림은 내장 데이터가 아니라 자를 수 없습니다": "This picture has no embedded data and cannot be cropped", "선택한 그림의 일부만 남기고 나머지를 잘라냅니다 (잘라낸 부분은 복원되지 않으므로 필요하면 되돌리기 Ctrl+Z)": "Keep only part of the selected picture (cropped pixels are discarded; use Undo to revert)", "남길 영역을 끌어서 지정하세요. 모서리/변: 크기, 안쪽: 이동, 바깥에서 끌기: 새로 지정": "Drag to choose the area to keep. Edges/corners: resize, inside: move, outside: new area",  "패널 배치 초기화": "Reset panel layout", "파일 도구": "File", "편집 도구": "Edit", "그리기 도구": "Draw", "규칙 도구": "Rules",
    "Wire": "Wire", "Component": "Component", "Inline": "Inline", "Reference": "Reference", "Splice(SP)": "Splice(SP)",
    "Twist": "Twist", "Unshielded": "Unshielded", "Text": "Text", "열기": "Open", "저장": "Save", "PDF": "PDF",
    "검사": "Check", "자동수정": "Auto Fix", "전체보기": "Fit",
    "선택: 클릭/드래그로 요소 선택, 선택 후 드래그하면 요소 이동": "Select: click/drag to select; drag a selected element to move it",
    "이동(Pan): 마우스 드래그로 화면을 이동 (마우스 가운데 버튼 드래그도 가능)": "Pan: drag with the mouse to move the view (middle-button drag also works)",
    "클릭으로 꺾임점 추가, 더블클릭/Enter 로 완료": "Click to add bend points, double-click/Enter to finish",
    "드래그하여 사각형 생성": "Drag to create a rectangle", "wire 위를 클릭 (Shift: 세로)": "Click on a wire (Shift: vertical)",
    "클릭하여 reference connector 추가": "Click to add a reference connector", "wire 끝점 근처 클릭": "Click near a wire end",
    "wire 사이를 클릭 (왼쪽-위 모서리)": "Click between wires (top-left corner)", "wire 사이를 클릭": "Click between wires",
    "클릭하여 일반 텍스트 추가": "Click to add free text",
    # 도크/패널
    "요소 목록 / SVG 코드": "Elements / SVG code", "속성": "Properties", "규칙 검사 패널": "Rule check", "코드 편집": "Code editor",
    "metadata": "metadata", "visible data": "visible data", "meta": "meta", "값": "Value", "속성명": "Attribute",
    "meta 추가": "Add meta", "meta 삭제": "Delete meta", "속성 추가": "Add attribute", "속성 삭제": "Delete attribute",
    "선택 없음": "Nothing selected", "선택 %d개": "%d selected", "적용": "Apply", "되돌리기": "Revert", "이미지 네비게이션 ID 생성": "Generate image-navigation IDs",
    "선택한 그룹(id)의 SVG 코드를 직접 수정하고 [적용]을 누르세요": "Edit the SVG code of the selected group (id) and press [Apply]",
    "한 개의 그룹을 선택하세요": "Select a single group", "코드 적용 완료": "Code applied", "코드 오류": "Code error",
    "오류": "Error", "경고": "Warning", "자동수정 가능": "auto-fixable", "오류 %d, 경고 %d, 자동수정 가능 %d": "Errors %d, warnings %d, auto-fixable %d",
    "(자동수정 가능)": "(auto-fixable)", "자동 수정 %d건 적용": "Auto-fix applied: %d", "이미지 네비게이션 ID %d개 생성": "Image-navigation IDs created: %d",
    "<metadata>": "<metadata>",
    # 메시지
    "PDF 또는 SVG 파일을 여세요 (Ctrl+O)": "Open a PDF or SVG file (Ctrl+O)", "열기 실패": "Open failed", "변환 경고": "Conversion warnings",
    "열기 완료: ": "Opened: ", "저장: ": "Saved: ", "PDF 저장: ": "PDF saved: ", "PDF 내보내기 실패": "PDF export failed",
    "종료 확인": "Exit", "저장하지 않은 변경 내용이 있습니다. 종료할까요?": "There are unsaved changes. Exit anyway?",
    "wire 가 없습니다.": "There is no wire.", "ref (94/번호:핀)": "ref (94/number:pin)", "ref (31/숫자)": "ref (31/number)",
    "라벨 (SP숫자문자)": "Label (SP<digits><letters>)", "라벨": "Label", "내용": "Text", "ref (숫자/숫자)": "ref (number/number)", "description": "description",
    "harness": "harness", "variant": "variant", "ref (신호명+문자)": "ref (signal+letter)", "option": "option", "area": "area", "color": "color",
    "option_description": "option_description", "클립보드가 비어 있습니다.": "Clipboard is empty.", "붙여넣기 대상 그룹을 선택하세요.": "Select a target group to paste into.",
    "다른 id 로 이동": "Moved to another id", "요소(그룹)를 다른 id 로 병합하시겠습니까? 원래 id 는 삭제됩니다.": "Merge this element (group) into another id? The original id will be deleted.",
    "병합": "Merge", "이동 완료": "Moved", "시트 정보": "Sheet",
    # 정보
    "정보": "About", "개발자": "Developer", "버전": "Version", "빌드 날짜": "Build date",
    "PDF 배선도를 배선도 템플릿/WDID 규칙에 맞는 SVG 로 변환하고 편집하는 도구": "Converts PDF wiring diagrams to template/WDID-compliant SVG and lets you edit them",
    "규칙 설명": "Rule help", "닫기": "Close", "드래그하여 이동 / Ctrl+C,X,V": "Drag to move / Ctrl+C,X,V",
    "캔버스": "Canvas", "새로 만들기…": "New…", "남은 오류 %d건은 수동 수정 필요": "%d errors left need manual fixing",
    "참고": "Note", "참고 %d": "Notes %d",
    "중국어 글자 삭제": "Delete Chinese text", "PDF 변환 시 중국어 자동 삭제": "Auto-delete Chinese text on PDF import", "PDF 변환 시 글자 그림 OCR 복원": "OCR-restore bitmap text on PDF import", "중국어 글자 %d개 삭제": "%d Chinese texts deleted", "글자 길이": "Text length", "글자 크기": "Font size",
    "배선도 PDF(여러 개 선택 또는 폴더 전체, 다중 페이지 포함)를 페이지별 배선도명(표제란 Document title)으로 PDF 저장하고 SVG 로 변환합니다.": "Pick several wiring-diagram PDFs (or a whole folder, multi-page allowed); each page is saved as PDF named by the title block (Document title) and converted to SVG.",
    "폴더의 PDF 전체…": "All PDFs in folder…", "폴더에 PDF 파일이 없습니다.": "No PDF files in the folder.", "개 PDF": " PDFs", "폴더 선택…": "Choose folder…",
    "PDF 분할 / SVG 일괄 변환…": "Split PDF / Batch convert to SVG…", "PDF 분할 / SVG 일괄 변환": "Split PDF / Batch convert to SVG",
    "여러 페이지 배선도 PDF 를 페이지별 배선도명으로 PDF 저장하고 SVG 로 변환합니다": "Splits a multi-page wiring-diagram PDF by page, saves each as PDF named after its diagram title, and converts to SVG",
    "여러 페이지 배선도 PDF 를 페이지별 배선도명(표제란 Document title)으로 PDF 저장하고 SVG 로 변환합니다.": "Split a multi-page wiring-diagram PDF into per-page PDFs named by the title block (Document title) and convert each to SVG.",
    "입력 PDF": "Input PDF", "저장 폴더": "Output folder", "PDF 선택…": "Choose PDF…", "폴더 선택…": "Choose folder…",
    "페이지별 PDF 저장": "Save per-page PDF", "SVG 변환 저장": "Save SVG", "자동 수정 적용": "Apply auto-fix", "이미지 네비게이션 ID 생성": "Generate image navigation IDs",
    "실행": "Run", "중지": "Stop", "닫기": "Close", "페이지 수: ": "Pages: ", "완료: ": "Done: ", "확인 필요": "needs review",
    "입력 PDF 와 저장 폴더를 지정하세요.": "Specify the input PDF and output folder.",
    "전체 탭 닫기": "Close all tabs", "최대 문서 수": "Max open documents", "동시에 열 수 있는 문서 수: %d": "Max open documents: %d",
    "저장하지 않은 변경 내용이 있는 문서가 %d개 있습니다. 모두 닫을까요?": "%d document(s) have unsaved changes. Close all?",
    "현재 탭(문서)을 닫습니다. 동시에 열 수 있는 문서 수는 설정에서 바꿀 수 있습니다": "Closes the current tab. The max number of open documents can be changed in Settings",
    "열려 있는 모든 탭(문서)을 닫고 빈 도면 하나만 남깁니다": "Closes all tabs and leaves one blank drawing",
    "열기": "Open", "이름 바꾸기": "Rename", "복사": "Copy", "잘라내기": "Cut", "붙여넣기": "Paste", "삭제": "Delete", "새 폴더": "New folder", "경로 복사": "Copy path", "새로 고침": "Refresh",
    "새 이름": "New name", "복사본": "Copy", "잘라냄 %d개": "Cut %d item(s)", "복사함 %d개": "Copied %d item(s)", "붙여넣기 %d개 완료": "Pasted %d item(s)",
    "열려 있는 문서는 옮길 수 없습니다. 탭을 먼저 닫으세요.": "Open documents cannot be moved. Close the tab first.",
    "열려 있는 문서는 이름을 바꿀 수 없습니다. 탭을 먼저 닫으세요.": "Open documents cannot be renamed. Close the tab first.",
    "열려 있는 문서는 삭제할 수 없습니다. 탭을 먼저 닫으세요.": "Open documents cannot be deleted. Close the tab first.",
    "자기 자신 안으로는 옮길 수 없습니다": "Cannot move into itself", "열려 있음": "is open", "같은 이름이 이미 있습니다. 덮어쓸까요?": "A file with the same name exists. Overwrite?",
    "같은 이름이 이미 있습니다.": "A file with the same name already exists.", "이름에 쓸 수 없는 문자가 있습니다: ": "Invalid characters in name: ",
    "%d개 항목을 휴지통으로 보낼까요?": "Move %d item(s) to the Recycle Bin?", "휴지통으로 보낼 수 없습니다. 완전히 삭제할까요?": "Cannot move to the Recycle Bin. Delete permanently?",
    "탭": "Tab", "탭 닫기": "Close tab", "탐색기": "Explorer", "상위 폴더": "Parent folder", "폴더 선택…": "Choose folder…",
    "문서는 최대 %d개까지 동시에 열 수 있습니다. 탭을 닫은 후 다시 시도하세요.": "Up to %d documents can be open at once. Close a tab and try again.",
    "저장하지 않은 변경 내용이 있습니다. 이 탭을 닫을까요?": "There are unsaved changes. Close this tab?",
    "더블클릭하면 새 탭으로 엽니다 (최대 %d개 동시 열람)": "Double-click to open in a new tab (up to %d documents at once)",
    "현재 탭(문서)을 닫습니다. 문서는 최대 5개까지 동시에 열 수 있습니다": "Closes the current tab (document). Up to 5 documents can be open at once",
    "서식 복사": "Copy format", "서식 붙여넣기": "Paste format", "서식 복사 항목 선택…": "Choose format items to copy…", "서식 브러시": "Format brush",
    "선택한 객체(글자)의 서식(폰트·크기·길이 등 선택한 속성)을 복사합니다": "Copies the format (chosen attributes such as font, size, length) of the selected object",
    "복사한 서식을 선택한 객체에 적용합니다": "Applies the copied format to the selected objects",
    "선택한 객체의 속성 중 복사할 항목을 골라 서식을 복사합니다": "Choose which attributes of the selected object to copy as format",
    "서식 브러시: 먼저 원본 객체를 선택한 뒤 이 도구를 켜고, 서식을 적용할 객체를 클릭 (Esc: 종료)": "Format brush: select the source object, turn this tool on, then click objects to apply the format (Esc: exit)",
    "서식 복사 항목 선택": "Choose format items", "복사할 속성을 선택하세요. 위치(x, y 등) 속성은 목록에서 제외됩니다.": "Select the attributes to copy. Position attributes (x, y, ...) are excluded.",
    "글자 서식 (폰트·크기·길이)": "Text format (font, size, length)", "모두 선택": "Select all", "모두 해제": "Clear all",
    "서식을 복사할 객체 1개를 먼저 선택하세요 (개별 객체는 더블클릭 또는 Alt+클릭)": "Select one object to copy its format first (double-click or Alt+click for a single object)",
    "복사할 속성이 선택되지 않았습니다 (편집 > 서식 복사 항목 선택…)": "No attributes selected to copy (Edit > Choose format items to copy…)",
    "서식 복사: ": "Format copied: ", "먼저 서식을 복사하세요 (Ctrl+Shift+C)": "Copy a format first (Ctrl+Shift+C)",
    "같은 종류(%s)의 대상 객체가 없습니다": "No target objects of the same kind (%s)", "서식 적용: %d개": "Format applied: %d", "클릭한 위치에 객체가 없습니다": "No object at the clicked position",
    "이동 (%s, %s)": "Moved (%s, %s)",
    "이 객체만 선택": "Select this object only", "id 전체 선택": "Select whole id",
    "삽입": "Insert", "개체": "Object", "도형": "Shapes", "순서": "Order", "회전/대칭": "Rotate / Flip", "삽입 도구": "Insert tools",
    "그림 삽입…": "Insert picture…", "클립보드 그림 붙여넣기": "Paste picture from clipboard", "표 삽입…": "Insert table…", "표 편집…": "Edit table…",
    "오른쪽으로 90° 회전": "Rotate right 90°", "왼쪽으로 90° 회전": "Rotate left 90°", "각도 지정 회전…": "Rotate by angle…", "좌우 대칭": "Flip horizontal", "상하 대칭": "Flip vertical",
    "크기 및 위치…": "Size and position…", "도형 서식…": "Format shape…", "그림 원본 비율로": "Restore picture aspect ratio", "맨 앞으로": "Bring to front", "앞으로": "Bring forward", "뒤로": "Send backward", "맨 뒤로": "Send to back",
    "직선": "Line", "화살표 선": "Arrow", "사각형": "Rectangle", "둥근 사각형": "Rounded rectangle", "타원": "Ellipse", "이등변 삼각형": "Triangle", "직각 삼각형": "Right triangle",
    "마름모": "Diamond", "사다리꼴": "Trapezoid", "오각형": "Pentagon", "육각형": "Hexagon", "별": "Star", "오른쪽 화살표": "Right arrow", "더하기": "Plus",
    "그림 파일(PNG/JPG/BMP/GIF 등)을 도면에 삽입합니다. 파일을 도면으로 끌어놓아도 됩니다": "Inserts a picture file (PNG/JPG/BMP/GIF...) into the diagram. You can also drag a file onto the canvas",
    "캡처하거나 복사한 그림을 도면에 붙여넣습니다 (그림이 클립보드에 있으면 Ctrl+V 로도 가능)": "Pastes a captured or copied picture (Ctrl+V also works when the clipboard holds a picture)",
    "행·열 수와 칸 내용을 지정해 표를 삽입합니다": "Inserts a table with the given rows, columns and cell contents",
    "선택한 표의 행·열 수, 칸 크기, 내용을 편집합니다": "Edits the rows, columns, cell size and contents of the selected table",
    "선택한 그림/도형을 시계 방향으로 90° 회전합니다": "Rotates the selected picture/shape 90° clockwise", "선택한 그림/도형을 반시계 방향으로 90° 회전합니다": "Rotates the selected picture/shape 90° counter-clockwise",
    "회전 각도를 직접 입력합니다 (마우스: 위쪽 초록 핸들을 끌기, Shift: 15° 단위)": "Enter a rotation angle (mouse: drag the green handle above, Shift: 15° steps)",
    "선택한 그림/도형을 좌우로 뒤집습니다": "Flips the selected picture/shape horizontally", "선택한 그림/도형을 위아래로 뒤집습니다": "Flips the selected picture/shape vertically",
    "선택한 그림/도형의 위치, 크기, 회전, 대칭을 숫자로 지정합니다": "Sets position, size, rotation and flip of the selected picture/shape numerically",
    "채우기/선 색, 선 굵기·종류, 불투명도를 지정합니다": "Sets fill/line color, line width and style, and opacity",
    "선택한 그림의 높이를 원본 가로세로 비율에 맞춥니다": "Matches the height of the selected picture to its original aspect ratio",
    "선택한 개체를 맨 앞(맨 위)으로 가져옵니다": "Brings the selected object to the front", "선택한 개체를 한 단계 앞으로 가져옵니다": "Brings the selected object forward one step",
    "선택한 개체를 한 단계 뒤로 보냅니다": "Sends the selected object backward one step", "선택한 개체를 맨 뒤(맨 아래)로 보냅니다": "Sends the selected object to the back",
    "도형: 종류를 고른 뒤 도면에서 드래그하여 그립니다 (Shift: 정사각형/45°, 클릭만 하면 기본 크기, Esc/오른쪽 클릭: 종료)": "Shapes: pick a kind, then drag on the canvas (Shift: square/45°, click for default size, Esc/right-click: exit)",
    "도면에서 드래그하여 그립니다 (Shift: 정사각형/45°, 클릭만 하면 기본 크기, Esc/오른쪽 클릭: 종료)": "Drag on the canvas to draw (Shift: square/45°, click for default size, Esc/right-click: exit)",
    "그림 삽입": "Insert picture", "그림 파일": "Picture files", "그림을 읽을 수 없습니다.": "Cannot read the picture.",
    "그림 삽입: %d × %d px (모서리 핸들로 크기, 위쪽 초록 핸들로 회전)": "Picture inserted: %d × %d px (corner handles resize, green handle above rotates)",
    "클립보드에 그림이 없습니다. (Win+Shift+S 로 화면을 캡처한 뒤 붙여넣으세요)": "No picture on the clipboard. (Capture the screen with Win+Shift+S, then paste)",
    "그림 또는 도형 1개를 먼저 선택하세요": "Select one picture or shape first", "순서를 바꿀 개체 1개를 선택하세요": "Select one object to change its order",
    "표를 선택하세요 (삽입한 표만 편집할 수 있습니다)": "Select a table (only inserted tables can be edited)", "크기": "Size", "회전": "Rotation",
    "도형 서식": "Format shape", "채우기": "Fill", "선": "Line", "선 굵기": "Line width", "선 종류": "Line style", "실선": "Solid", "파선": "Dashed", "점선": "Dotted", "불투명도": "Opacity",
    "크기 및 위치": "Size and position", "너비": "Width", "높이": "Height", "회전 (°)": "Rotation (°)", "좌우 반전": "Flip horizontal", "상하 반전": "Flip vertical", "가로세로 비율 유지": "Keep aspect ratio",
    "표 편집": "Edit table", "표 삽입": "Insert table", "행": "Rows", "열": "Columns", "칸 너비": "Cell width", "칸 높이": "Cell height", "글자 크기": "Font size",
    "첫 행을 머리글로 (회색 배경)": "First row as header (gray)", "칸을 더블클릭해 내용을 입력하세요. 빈 칸은 글자가 만들어지지 않습니다.": "Double-click a cell to type. Empty cells create no text.",
    "각도 지정 회전": "Rotate by angle", "회전 각도 (°)": "Rotation angle (°)",
    "이미지 PDF": "Image PDF", "이 PDF 는 선/글자 정보가 없는 이미지(사진) 입니다.\n처리 방법을 선택하세요.": "This PDF is a raster image without vector/text data.\nChoose how to process it.", "이미지로 삽입": "Insert as image", "OCR 로 글자/상자 재현": "Recreate text/boxes with OCR", "취소": "Cancel", "변환 실패": "Conversion failed",
    "찾기": "Find", "찾기…": "Find…", "다음 찾기": "Find Next", "이전 찾기": "Find Previous", "이전": "Prev", "다음": "Next", "찾을 내용 (글자, id-번호, meta 값)": "Search text, id-number, meta value", "대/소문자 구분": "Match case", "전체 (글자+id+meta)": "All (text+id+meta)", "글자만": "Text only", "id/meta 만": "id/meta only", "%d건": "%d found", "스크롤바 두께": "Scrollbar width",
    "새 도면": "New drawing", "기본 캔버스 크기…": "Default canvas size…", "도면 이름": "Drawing name",
    "캔버스 폭": "Canvas width", "캔버스 높이": "Canvas height", "기본값으로 저장": "Save as default",
    "새 도면을 만들기 전에 현재 변경 내용을 버릴까요?": "Discard current changes and create a new drawing?",
    "새 도면의 기본 캔버스 크기를 설정합니다 (SVG 단위)": "Set the default canvas size for new drawings (SVG units)",
    "기본 캔버스 크기 저장: ": "Default canvas size saved: ", "숫자를 입력하세요 (>0)": "Enter a number (>0)",
    "글자 크기": "Font size", "드래그하여 캔버스 크기 조정": "Drag to resize the canvas", "캔버스 크기": "Canvas size", "새 속성 이름": "New attribute name", "이름": "Name",
}
