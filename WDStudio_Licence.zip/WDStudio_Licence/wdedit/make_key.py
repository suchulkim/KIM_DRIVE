#!/usr/bin/env python3
"""개발자 전용 라이선스 키 생성 (배포하지 마세요).

  python make_key.py PC코드                    영구 키
  python make_key.py PC코드 --days 365         오늘부터 365일
  python make_key.py PC코드 --expiry 2027-12-31

licensing.py 의 SECRET 이 같아야 키가 통과합니다 (SECRET 을 바꾸면 이전에 발급한 키는 모두 무효).
"""
import argparse
import datetime
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import licensing

ap = argparse.ArgumentParser()
ap.add_argument("pc_code"); ap.add_argument("--days", type=int); ap.add_argument("--expiry")
a = ap.parse_args()
exp = datetime.date.fromisoformat(a.expiry) if a.expiry else (datetime.date.today() + datetime.timedelta(days=a.days) if a.days else None)
print("PC 코드 :", a.pc_code.upper())
print("만료일  :", exp or "영구")
print("키      :", licensing.make_key(a.pc_code, exp))
