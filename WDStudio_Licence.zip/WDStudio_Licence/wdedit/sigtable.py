"""배선도 SVG -> 시그널 테이블(엑셀) 추출 / 내보내기 / 도면 기준 엑셀 수정.

열 구성(마스터 시그널 테이블과 동일 + V열, 22열):
Wire, Wireinfo, From WDID, From Connector, From Port, From Port Des, From Terminal,
To WDID, To Connector, To Port, To Port Des, To Terminal,
Type, Area, Color, Note, Pummel, PummelVdn, Variant, VariantVdn, harness,
wiring diagram name  (V열: 그 와이어가 그려진 배선도 이름, 여러 도면이면 ", " 로 연결)
"""
from __future__ import annotations
import math
import os
import re

HEADERS = ["Wire", "Wireinfo", "From WDID", "From Connector", "From Port", "From Port Des", "From Terminal",
           "To WDID", "To Connector", "To Port", "To Port Des", "To Terminal",
           "Type", "Area", "Color", "Note", "Pummel", "PummelVdn", "Variant", "VariantVdn", "harness",
           "wiring diagram name"]

RE_PIN = re.compile(r"^([A-Za-z][A-Za-z0-9_]{0,9})\s+(\d+S?)$")   # 5S, 1S 처럼 실드 핀은 S 가 붙는다
RE_WDID = re.compile(r"^\d+/\d+(\.\w+)*$")
RE_WDID_DESC = re.compile(r"^(\d+/\d+(?:\.\w+)*)\s+[A-Za-z]")      # "7/124 BRAKE PEDAL SENSOR" 처럼 WDID 와 부품 이름이 한 글자로 합쳐진 머리글
RE_CONN_LINE = re.compile(r"^([A-Za-z][A-Za-z0-9_]{0,9}):")
RE_REFTXT = re.compile(r"^(?:[^:]*:)?(\d+/\d+)(?:\.([A-Za-z0-9]+))?(?::(\d+))?")
RE_SP = re.compile(r"(SP\d+[A-Z]*)")
RE_SPNAME_AR = re.compile(r"^SP\d+[A-Z]*$")
RE_SPNAME_RG = re.compile(r"^SP_?[A-Z0-9]+(?:_[A-Z0-9]+)*$")
RE_SPNAME = RE_SPNAME_AR
RE_WIRELBL = re.compile(r"^(\S+) (\S+) ([\d.]+) (\S+)\s*$")


def _num(s, d=0.0):
    try:
        return float(s)
    except Exception:
        return d


def _pts(d):
    return [(float(a), float(b)) for a, b in re.findall(r"(-?\d+\.?\d*),(-?\d+\.?\d*)", d or "")]


def _text(p):
    return (p.text or "")


# ---------------------------------------------------------------- 도면 요소 수집
class Comp:
    def __init__(self, g):
        self.g = g
        self.ref = g.get("ref") or ""
        self.harness = (g.get("harness") or "").strip()
        self.rects = []          # 본체(굵은 선)
        self.small = []          # 그 밖의 사각형(피그테일 끝 등)
        self.texts = []
        for p in g.prims:
            if p.tag == "rect":
                r = (float(p.attrs["x"]), float(p.attrs["y"]), float(p.attrs["width"]), float(p.attrs["height"]))
                if _num(p.attrs.get("stroke-width")) >= 2:
                    self.rects.append(r)
                else:
                    self.small.append(r)
            elif p.tag == "text":
                self.texts.append((_num(p.attrs.get("x")), _num(p.attrs.get("y")), _num(p.attrs.get("textLength")), _text(p).strip()))
        # WDID : 머리글 텍스트 (예: 6/163.1), 없으면 meta ref
        hdr = [t for t in self.texts if RE_WDID.match(t[3])]
        hdr += [(t[0], t[1], t[2], RE_WDID_DESC.match(t[3]).group(1)) for t in self.texts if RE_WDID_DESC.match(t[3])]
        hdr.sort(key=lambda t: (t[1], t[0]))
        self.wdid = hdr[0][3] if hdr else self.ref
        self.letters = sorted({m.group(1) for t in self.texts for m in [RE_CONN_LINE.match(t[3])] if m})
        self._merge_split_pins()
        self.pins = [(t, RE_PIN.match(t[3])) for t in self.texts if RE_PIN.match(t[3])]
        self.pin_prefixes = sorted({m.group(1) for t, m in self.pins})

    def _merge_split_pins(self):
        """핀 글자가 'A' 와 '3' 처럼 둘로 나뉘어 있으면 'A 3' 으로 합친다"""
        T = list(self.texts)
        used = set()
        for i, a in enumerate(T):
            if not re.match(r"^[A-Z]{1,3}\d*$", a[3]):
                continue
            for j, b in enumerate(T):
                if j != i and re.match(r"^\d+$", b[3]) and abs(a[1] - b[1]) < 0.6 and 0 <= b[0] - (a[0] + a[2]) < 12:
                    used.add(i); used.add(j)
                    T.append((a[0], a[1], b[0] + b[2] - a[0], "%s %s" % (a[3], b[3])))
                    break
        self.texts = [t for k, t in enumerate(T) if k not in used]

    def hit(self, pt, tol=3.0):
        """끝점이 상자 가장자리에 닿으면 (rect, side) 반환 (본체 우선)"""
        x, y = pt
        for group in (self.rects, self.small):
            for r in group:
                x0, y0, w, h = r
                if y0 - tol <= y <= y0 + h + tol and x0 - tol <= x <= x0 + w + tol:
                    if abs(x - x0) <= tol:
                        return r, "L"
                    if abs(x - (x0 + w)) <= tol:
                        return r, "R"
                    if abs(y - y0) <= tol:
                        return r, "T"
                    if abs(y - (y0 + h)) <= tol:
                        return r, "B"
        return None


class _Hdrs(list):
    """문서 전체의 WDID 머리글 글자 목록 (+ 문서 전체 부품 상자 목록 .rects)"""
    rects = ()


def fix_wdid_by_position(comp, hdrs):
    """부품 그룹의 머리글(WDID) 글자가 다른 그룹에 들어가 있는 경우(그룹이 한 칸씩 어긋난 SVG)를 위해,
    본체 상자 바로 위(약 90 단위 이내)에 놓인 WDID 글자를 찾아 comp.wdid 로 쓴다.
    그룹 자신의 머리글이 상자 바로 위에 있으면 그대로 둔다.
    그래도 WDID 가 없으면(머리글 아래에 부품번호 줄이 여러 개 있어 상자와 멀리 떨어진 경우, 예: 4/185 + A:/B:/CSD:/PSD:/USB:/TUNER: 줄)
    다른 부품 상자가 차지하지 않은 머리글 중 위쪽 170 단위 이내에서 가장 가까운 것을 쓴다."""
    if not comp.rects or not hdrs:
        return

    def above(t, r, lim=90):
        return r[0] - 25 <= t[0] <= r[0] + r[2] and r[1] - lim <= t[1] <= r[1] - 4

    own = [t for t in comp.texts if RE_WDID.match(t[3])] + [(t[0], t[1], t[2], RE_WDID_DESC.match(t[3]).group(1)) for t in comp.texts if RE_WDID_DESC.match(t[3])]
    if any(above(t, r) for t in own for r in comp.rects):
        return
    best = None
    for t in hdrs:
        for r in comp.rects:
            if above(t, r):
                d = r[1] - t[1]
                if best is None or d < best[0]:
                    best = (d, t[3], t)
    if best:
        comp.wdid = best[1]
        comp.hdr_pos = best[2]
        return
    if comp.wdid:
        return
    others = [r for r in getattr(hdrs, "rects", ()) if r not in comp.rects]
    for t in hdrs:
        for r in comp.rects:
            if above(t, r, 170) and not any(above(t, o, 90) for o in others):
                d = r[1] - t[1]
                if best is None or d < best[0]:
                    best = (d, t[3], t)
    if best:
        comp.wdid = best[1]
        comp.hdr_pos = best[2]
        return
    # 머리글이 상자보다 왼쪽에서 시작하는 경우(피그테일 커넥터: 머리글이 선 시작 쪽에 있고 상자는 오른쪽). 위쪽 45 이내, 왼쪽 90 이내
    for t in hdrs:
        for r in comp.rects:
            if r[1] - 45 <= t[1] <= r[1] - 4 and r[0] - 90 <= t[0] <= r[0] + r[2] and not any(above(t, o, 90) for o in others):
                d = (r[1] - t[1]) + abs(r[0] - t[0]) * 0.1
                if best is None or d < best[0]:
                    best = (d, t[3], t)
    if best:
        comp.wdid = best[1]
        comp.hdr_pos = best[2]


def add_header_letters(comp, loose):
    """머리글(WDID)이 다른 그룹에 있어 위치로 찾은 경우, 그 머리글 바로 아래의 'CSD:부품번호' 같은 커넥터 줄도 이 부품의 커넥터 이름으로 본다."""
    t = getattr(comp, "hdr_pos", None)
    if not t or not loose or not comp.rects:
        return
    top = min(r[1] for r in comp.rects)
    add = set()
    for x, y, L, txt in loose:
        m = RE_CONN_LINE.match(txt)
        if m and abs(x - t[0]) < 8 and t[1] < y < top:
            add.add(m.group(1))
    if add:
        comp.letters = sorted(set(comp.letters) | add)


def _doc_headers(doc):
    out = _Hdrs()
    rects = []
    for g in doc.groups:
        if g.get("type") == "component" and g.get("tag") != "AUTO_GENERATED":
            try:
                rects.extend(Comp(g).rects)
            except Exception:
                pass
        for p in g.prims:
            if p.tag == "text":
                tx = _text(p).strip()
                m_ = RE_WDID.match(tx) and tx or (RE_WDID_DESC.match(tx).group(1) if RE_WDID_DESC.match(tx) else None)
                if m_:
                    out.append((_num(p.attrs.get("x")), _num(p.attrs.get("y")), _num(p.attrs.get("textLength")), m_))
    out.rects = rects
    return out


def _is_name(t):
    s = t[3]
    return bool(s) and not RE_PIN.match(s) and not RE_WDID.match(s) and not RE_WDID_DESC.match(s) and not RE_CONN_LINE.match(s) and not s.startswith("G:")


def _connector_text(comp, letter):
    """엑셀 Connector 열 규칙(마스터 시그널 테이블 대조로 확인):
    - 이름이 긴 커넥터(AIRBAG, PT_FR_RH 등 3글자 이상)는 WDID 그대로
    - 문자가 A 가 아니면(F, IP, B, C, G ...) WDID.<문자>
    - 문자가 A 이면: 커넥터가 둘 이상이거나 부품에 하네스가 지정된 경우만 WDID.A, 아니면 WDID
    """
    if getattr(comp, "rg", False):                           # RG4F1: 부품 핀 글자와 같이 항상 WDID.커넥터 (4/1132.J3, 4/184.1.A)
        return "%s.%s" % (comp.wdid, letter)
    many_c = len(set(comp.letters) | set(comp.pin_prefixes)) > 1
    if len(letter) > 2:                      # 긴 이름: 머리글에 "이름:부품번호" 줄이 있고 커넥터가 여럿이면 WDID.이름 (예 15/43.HBF01, 4/889.GND)
        return "%s.%s" % (comp.wdid, letter) if (letter in comp.letters and many_c) else comp.wdid
    if letter != "A":
        return "%s.%s" % (comp.wdid, letter)
    many = len(set(comp.letters) | set(comp.pin_prefixes)) > 1
    return "%s.%s" % (comp.wdid, letter) if (many or comp.harness not in ("", "*opt*")) else comp.wdid


_RG_STUBS = []


def stub_end(comp, pt):
    """부품 그룹 안의 핀 선(피그테일)이 본체 밖으로 나와 있고 와이어가 그 끝에 닿은 경우.
    핀 이름/번호 글자는 부품 그룹 밖의 낱개 글자(comp.loose)에서 찾는다."""
    loose = getattr(comp, "loose", None)
    if not loose or not comp.rects:
        return None
    for p in comp.g.prims:
        if p.tag != "path":
            continue
        q = _pts(p.attrs.get("d", ""))
        if "A" in p.attrs.get("d", ""):
            continue
        if len(q) == 2:
            pairs_ = ((q[0], q[1]), (q[1], q[0]))
            if abs(q[0][1] - q[1][1]) > 0.2:
                continue
        elif len(q) > 2:                                      # 꺾인 핀 선(3점 이상): 끝점에서 시작하는 첫 구간이 가로이면 같은 방식으로 본다
            pairs_ = tuple((e0, o0) for e0, o0 in ((q[0], q[1]), (q[-1], q[-2])) if abs(e0[1] - o0[1]) <= 0.2)
        else:
            continue
        for e, o in pairs_:
            if math.dist(e, pt) > 1.5 or abs(o[0] - e[0]) < 10:
                continue
            if not any(r[1] <= e[1] <= r[1] + r[3] and min(e[0], o[0]) <= r[0] + r[2] and max(e[0], o[0]) >= r[0] for r in comp.rects):
                continue
            sgn = 1 if o[0] > e[0] else -1
            near = [t for t in loose if 0 <= sgn * ((t[0] + t[2] / 2) - e[0]) <= 60]
            pins = [(t, RE_PIN.match(t[3])) for t in near if RE_PIN.match(t[3]) and 0 < t[1] - e[1] <= 16]
            if not pins:
                continue
            t, m = min(pins, key=lambda c: abs(c[0][1] - e[1] - 9))
            names = [u for u in near if _is_name(u) and -2 <= e[1] - u[1] <= 14 and abs((u[0] + u[2] / 2) - (t[0] + t[2] / 2)) < 20]
            des = min(names, key=lambda u: abs(e[1] - u[1] - 3))[3] if names else ""
            out = dict(kind="comp", wdid=comp.wdid, conn=comp.wdid, port=m.group(2), des=des, term="", letter=m.group(1), ok=True)
            out["conn"] = _connector_text(comp, m.group(1))
            both = all(min(o[0], e[0]) < r[0] and max(o[0], e[0]) > r[0] + r[2] for r in comp.rects[:1])
            if both and m.group(1) == "A":                 # 본체를 가로지르는 핀 선(양쪽 핀) = 핀이 둘 이상인 커넥터 -> WDID.A (마스터 10/114.A)
                out["conn"] = "%s.A" % comp.wdid
            return out
    if getattr(comp, "rg", False):                           # RG4F1: 핀 선이 본체 밖으로 나와 있고 핀 이름/번호 글자는 본체 안에 있다 -> 선이 본체 가장자리와 만나는 점으로 판단
        for p in comp.g.prims:
            if p.tag != "path" or "A" in p.attrs.get("d", ""):
                continue
            q = _pts(p.attrs.get("d", ""))
            if len(q) < 2 or not any(math.dist(v, pt) <= 1.5 for v in q):
                continue
            for o in q:
                if math.dist(o, pt) > 5 and comp.hit(o, tol=2.0):
                    return comp_end(comp, o)
        for a, b in _RG_STUBS:                               # 핀 선이 다른 그룹(와이어 그룹 등)에 있거나, 와이어 시작점이 핀 선 끝에서 조금(<=16) 떨어져 있는 경우
            for e, o in ((a, b), (b, a)):
                if abs(e[1] - pt[1]) > 0.5 or abs(o[1] - e[1]) > 0.5:
                    continue
                dx = (e[0] - o[0])
                gap = (pt[0] - e[0]) * (1 if dx > 0 else -1)
                if -1.5 <= gap <= 16 and comp.hit(o, tol=2.0):
                    return comp_end(comp, o)
    # 접지 부품(31/xx)의 세로 핀 선: 선 끝 바로 위/옆의 글자(A, B, C)가 핀 이름. 마스터: 31/501 + A -> 31/501.A, 핀 1, 설명 A
    if re.match(r"^31/", comp.wdid or ""):
        for p in comp.g.prims:
            if p.tag != "path":
                continue
            q = _pts(p.attrs.get("d", ""))
            if len(q) != 2 or abs(q[0][0] - q[1][0]) > 0.2:
                continue
            if not any(math.dist(e, pt) <= 1.5 for e in q):
                continue
            cand = [t for t in loose if re.match(r"^[A-Z]$", t[3]) and pt[0] - 4 <= t[0] <= pt[0] + 14 and pt[1] - 14 <= t[1] <= pt[1] + 2]
            if cand:
                t = min(cand, key=lambda t: abs(t[0] - pt[0]) + abs(t[1] - pt[1]))
                return dict(kind="comp", wdid=comp.wdid, conn="%s.%s" % (comp.wdid, t[3]), port="1", des=t[3], term="", letter=t[3], ok=True)
    return None


def comp_end(comp, pt):
    hit = comp.hit(pt)
    if not hit:
        return stub_end(comp, pt)
    rect, side = hit
    x0, y0, w, h = rect
    x, y = pt
    out = dict(kind="comp", wdid=comp.wdid, conn=comp.wdid, port="", des="", term="", letter="", ok=False)
    if side in ("L", "R", "T", "B"):
        allr = comp.rects + comp.small
        xlo = min([r[0] for r in allr] or [x0]) - 4
        xhi = max([r[0] + r[2] for r in allr] or [x0 + w]) + 4
        names = [u for u in comp.texts if _is_name(u) and xlo <= u[0] and u[0] + u[2] <= xhi]

        body = rect in comp.rects

        def wrong_side(t):
            """본체 상자의 왼쪽 가장자리에 닿았는데 핀이 오른쪽 절반에 있으면(또는 반대) 다른 쪽 핀"""
            if not body or side not in ("L", "R"):
                return 0
            cx = t[0] + t[2] / 2
            return 1000 if (side == "L" and cx > x0 + w / 2) or (side == "R" and cx < x0 + w / 2) else 0

        def aligned(u, t):
            return min(abs(u[0] - t[0]), abs((u[0] + u[2]) - (t[0] + t[2])), abs((u[0] + u[2] / 2) - (t[0] + t[2] / 2))) < 11.0

        # 1) 이름(선 위쪽) 과 핀(선 아래쪽) 이 와이어를 사이에 두고 있는 쌍을 우선 찾는다
        best = None
        for t, m in comp.pins:
            if not (xlo <= t[0] <= xhi) or t[1] < y + 0.5:
                continue
            for u in names:
                if u is t or not (0 < t[1] - u[1] <= 24) or not aligned(u, t):
                    continue
                if u[1] - 1.5 <= y <= t[1] + 2:
                    sc = abs(y - (u[1] + t[1]) / 2) + 0.02 * abs(t[0] + t[2] / 2 - x) + wrong_side(t)
                    if best is None or sc < best[0]:
                        best = (sc, t, m, u)
        if not best:
            for t, m in comp.pins:
                if not (xlo <= t[0] <= xhi):
                    continue
                for u in names:
                    if u is t or not (0 < u[1] - t[1] <= 24) or not aligned(u, t):
                        continue
                    if y - 3 <= t[1] <= y + 0.5 and y <= u[1] - 1:
                        sc = abs(y - t[1]) + 0.02 * abs(t[0] + t[2] / 2 - x) + wrong_side(t)
                        if best is None or sc < best[0]:
                            best = (sc, t, m, u)
        if best:
            _, t, m, u = best
            out["port"] = m.group(2); out["letter"] = m.group(1); out["ok"] = True
            out["des"] = u[3]
        else:
            cand = []
            for t, m in comp.pins:
                d = t[1] - y
                if -3 <= d <= 13 and xlo <= t[0] <= xhi:
                    cand.append((abs(d - 5) + 0.02 * abs(t[0] + t[2] / 2 - x) + wrong_side(t), d, t, m))
            if cand:
                _, d, t, m = min(cand, key=lambda c: c[0])
                out["port"] = m.group(2); out["letter"] = m.group(1); out["ok"] = True
                nm = []
                for u in names:
                    dy = y - u[1]
                    if -2 <= dy <= 16 and u[1] < t[1] and u is not t:
                        nm.append((0 if aligned(u, t) else 1, abs(dy - 5), u))
                if nm:
                    out["des"] = min(nm, key=lambda c: (c[0], c[1]))[2][3]
        # 단자(terminal): 상자 바깥쪽 가까이 있는 짧은 글자
        for u in comp.texts:
            if _is_name(u) and len(u[3]) <= 4 and abs(u[1] - y) <= 8 and not (xlo <= u[0] and u[0] + u[2] <= xhi):
                if side == "L" and x0 - 30 <= u[0] + u[2] <= x0 + 1:
                    out["term"] = u[3]; break
                if side == "R" and x0 + w - 1 <= u[0] <= x0 + w + 30:
                    out["term"] = u[3]; break
    if out["letter"]:
        out["conn"] = _connector_text(comp, out["letter"])
    return out


RE_INLTXT = re.compile(r"^\d+/\d+(?:\.\w+)*:\d+S?$")


class Inline:
    def __init__(self, g):
        self.g = g
        self.ref = g.get("ref") or ""
        self.ends = []
        self.arc = None
        for p in g.prims:
            if p.tag == "path":
                d = p.attrs.get("d", "")
                if " A" in d or "A" in d.split(" ")[0:2][-1:][0:1]:
                    pass
                q = _pts(d)
                if "A" in d:
                    self.arc = d
                elif len(q) == 2:
                    self.ends.extend(q)
        self.text = next((_text(p).strip() for p in g.prims if p.tag == "text"), self.ref)
        self.xs = [e[0] for e in self.ends]

    def hit(self, pt, tol=3.0):
        if not self.ends:
            return None
        best = min(self.ends, key=lambda e: math.dist(e, pt))
        if math.dist(best, pt) <= tol:
            mid = sum(self.xs) / len(self.xs)
            return "L" if pt[0] < mid else "R"
        return None


class Ref:
    def __init__(self, g):
        self.g = g
        self.pt = None
        for p in g.prims:
            if p.tag == "path":
                q = _pts(p.attrs.get("d", ""))
                if q:
                    self.pt = q[0]            # 와이어와 만나는 쪽
                    self.pt2 = q[-1]
                    break
        self.texts = [_text(p).strip() for p in g.prims if p.tag == "text"]

    def hit(self, pt, tol=3.0):
        return self.pt is not None and (math.dist(self.pt, pt) <= tol or math.dist(self.pt2, pt) <= tol)


def inline_end(il, pt, side):
    m = re.match(r"^(\d+/\d+(?:\.\w+)?):(\d+)$", il.text)
    if not m:
        m2 = re.match(r"^(\d+/\d+(?:\.\w+)?)", il.text)
        wdid, port = (m2.group(1), "") if m2 else (il.text, "")
    else:
        wdid, port = m.group(1), m.group(2)
    # 소켓/플러그: 반원 방향 + 와이어가 닿은 쪽(마스터 테이블 대조로 확인)
    des = ""
    if il.arc:
        a = _pts(il.arc)
        if len(a) >= 2:
            down = a[0][1] < a[-1][1]
            des = "socket" if (side == "L") == down else "plug"
            # 세로로 놓인 인라인(호의 현이 가로)은 좌/우 대신 호가 불룩한 쪽과 와이어가 닿은 쪽을 비교: 같은 쪽이면 socket, 반대쪽이면 plug
            if abs(a[0][1] - a[-1][1]) < 0.5 and abs(a[0][0] - a[-1][0]) > 1 and il.ends:
                mm = re.search(r"A\s*[\d.]+[ ,]+[\d.]+\s+[\d.]+\s+[01][ ,]+([01])", il.arc)
                if mm:
                    vx, vy = a[-1][0] - a[0][0], a[-1][1] - a[0][1]
                    bx, by = (-vy, vx) if mm.group(1) == "0" else (vy, -vx)
                    cx = sum(e[0] for e in il.ends) / len(il.ends); cy = sum(e[1] for e in il.ends) / len(il.ends)
                    des = "socket" if (pt[0] - cx) * bx + (pt[1] - cy) * by > 0 else "plug"
    return dict(kind="inline", wdid=wdid, conn=wdid, port=port, des=des, term="", side=side, ok=bool(port))


def _split_wdid(wdid, suf):
    """WDID 접미사 해석: 숫자/영문+숫자(.1, .L2) = WDID 일부, 영문 한 글자(.A) = 커넥터 문자, 그 외 = 핀 이름"""
    if not suf:
        return wdid, None, None
    if re.match(r"^\d+$", suf) or re.match(r"^[A-Z]\d$", suf):
        return "%s.%s" % (wdid, suf), None, None
    if re.match(r"^[A-Z]$", suf):
        return wdid, suf, None
    return wdid, None, suf


def ref_end(rf):
    if getattr(rf, "rg", False):                                  # RG4F1 레퍼런스 (rg4f1.py)
        import rg4f1
        return rg4f1.ref_end(rf)
    s = (rf.texts[0] if rf.texts else "").strip()
    body = (s.split(":", 1)[1] if ":" in s else s).strip()
    sp = re.match(r"^(SP\d+[A-Z]*)", body)
    if sp:
        return dict(kind="ref", wdid=sp.group(1), conn=sp.group(1), port="junction", des="junction", term="", ok=True)
    mn = re.match(r"^(N_[A-Za-z0-9_]+?)\.([A-Z])$", body)          # 예외 WDID (N_DIODE1.A): WDID 는 그대로, 핀 번호 1, 설명은 글자
    if mn:
        return dict(kind="ref", wdid=mn.group(1), conn=mn.group(1), port="1", des=mn.group(2), term="", ok=True, guess=True)
    m = re.match(r"^(\d+/\d+)(?:\.([A-Z]?\d+))?(?:\.([^:]+?))?(?::(\d+))?\s*$", body)
    if not m:
        return dict(kind="ref", wdid=body, conn=body, port="", des="", term="", ok=False)
    wdid, num, suf, port = m.group(1), m.group(2), m.group(3), m.group(4)
    if suf and "." in suf:                                    # 4/496.PAS3.GND_KL31 -> WDID 4/496.PAS3, 핀 이름 GND_KL31
        head, suf = suf.rsplit(".", 1)
        wdid = "%s.%s" % (wdid, head)
    if num:
        wdid = "%s.%s" % (wdid, num)
    w, letter, name = _split_wdid(wdid, suf)
    if letter and port:                                       # 시트:WDID.글자:핀 (예 15/49.B:1) -> 마스터는 WDID 에 글자 포함, socket
        wl = "%s.%s" % (w, letter)
        return dict(kind="ref", wdid=wl, conn=wl, port=port, des="socket", term="", ok=True)
    if letter:
        return dict(kind="ref", wdid=w, conn="%s.%s" % (w, letter), port=port or "1", des=letter, term="", ok=True)
    if name and not port and name.upper() == "GND":
        return dict(kind="ref", wdid=w, conn=w, port="1", des=name, term="", ok=True, guess=True)
    if name:
        return dict(kind="ref", wdid=w, conn=None if not port else w, port=port or None, des=name, term=None, ok=bool(port), needs_dir=not port)
    return dict(kind="ref", wdid=w, conn=w, port=port or "", des="socket", term="", ok=bool(port))


# ---------------------------------------------------------------- 추출
def vehicle_profile(doc, profile=None):
    """'AR' | 'RG4F1'.  profile 이 None/'auto' 면 도면에서 자동 판별."""
    if profile in ("AR", "RG4F1"):
        return profile
    import rg4f1
    return "RG4F1" if rg4f1.detect(doc) else "AR"


def extract_doc(doc, profile=None):
    """Doc -> [row dict] (물리 wire 만).  wire 가 없으면 []
    profile: 'AR'(기본 규칙) / 'RG4F1'(rg4f1.py 규칙) / None(자동)"""
    global RE_SPNAME
    prof = vehicle_profile(doc, profile)
    RE_SPNAME = RE_SPNAME_RG if prof == "RG4F1" else RE_SPNAME_AR
    comps, inls, refs, wires = [], [], [], []
    hdrs = _doc_headers(doc)
    alltexts = _loose_texts(doc)
    loose = []
    for g in doc.groups:
        if g.cls == "text":
            for p in g.prims:
                if p.tag == "text":
                    loose.append((_num(p.attrs.get("x")), _num(p.attrs.get("y")), _num(p.attrs.get("textLength"), 20.0), _text(p).strip()))
    for g in doc.groups:
        ty = g.get("type")
        if g.cls == "wire" and ty == "physical_wire":
            wires.append(g)
        elif ty == "component" and g.get("tag") != "AUTO_GENERATED":
            c = Comp(g)
            c.loose = loose
            c.rg = prof == "RG4F1"
            if c.rg and not c.wdid:                                # RG4F1 퓨즈/릴레이 상자: meta ref 가 비어 있고 머리글이 'B005:1:' 형태
                hh = sorted((t_ for t_ in c.texts if re.match(r"^[A-Z]\d{3}:[^\s:]*:$", t_[3])), key=lambda t_: (t_[1], t_[0]))
                if hh:
                    c.wdid = hh[0][3]
            fix_wdid_by_position(c, hdrs)
            add_header_letters(c, alltexts)
            if c.rects:
                comps.append(c)
        elif ty == "inline_connector":
            inls.append(Inline(g))
        elif ty == "reference_connector":
            refs.append(Ref(g))
            for p in g.prims:
                if p.tag == "text":
                    loose.append((_num(p.attrs.get("x")), _num(p.attrs.get("y")), _num(p.attrs.get("textLength"), 20.0), _text(p).strip()))
    # 레퍼런스 글자는 그룹 안/밖 어디에 들어 있든 점(●) 바로 옆에 놓인 글자를 그 레퍼런스의 글자로 본다 (편집 중 글자와 점이 다른 그룹에 섞이는 경우 대비)
    rg_gl = rg_dl = rg_rings = rg_dots = None
    if prof == "RG4F1":
        import rg4f1
        refs = rg4f1.build_refs(doc)
        rg_gl, rg_dl = rg4f1.label_ends(doc)
        rg_rings, rg_dots, rg_segs = rg4f1.rings(doc), rg4f1.dots(doc), rg4f1.stub_segments(doc)
    _RG_STUBS[:] = []
    if prof == "RG4F1":
        for g_ in doc.groups:
            for p_ in g_.prims:
                if p_.tag == "path" and "A" not in p_.attrs.get("d", ""):
                    q_ = _pts(p_.attrs.get("d", ""))
                    if 2 <= len(q_) <= 3 and abs(q_[0][1] - q_[1][1]) < 0.3 and 5 <= abs(q_[0][0] - q_[1][0]) <= 40:
                        _RG_STUBS.append((q_[0], q_[1]))
    for rf in refs:
        if getattr(rf, "g", None) is None:
            continue
        dot = None
        for p in rf.g.prims:
            if p.tag == "ellipse":
                dot = (float(p.attrs["cx"]), float(p.attrs["cy"]))
        if not dot:
            continue
        c1 = [t for t in loose if ":" in t[3] and -16 <= t[1] - dot[1] <= 8 and 3 <= t[0] - dot[0] <= 40]
        c2 = [t for t in loose if ":" in t[3] and -16 <= t[1] - dot[1] <= 8 and -3 <= dot[0] - (t[0] + t[2]) <= 40]
        c3 = [t for t in loose if ":" in t[3] and 8 < t[1] - dot[1] <= 28 and t[0] - 8 <= dot[0] <= t[0] + t[2] + 8]   # 점 바로 아래에 놓인 글자 (7A1: 7A2_Infotainment:4/185.RL+)
        cc = c1 or c2 or c3
        if cc:
            rf.texts = [min(cc, key=lambda t: abs(t[1] - dot[1] - 3) + 0.05 * abs((t[0] + t[2] / 2) - dot[0]))[3]]
    for il in inls:                                           # 글자 없는 인라인(반쪽 기호)은 겹쳐 있는 글자 있는 인라인의 글자를 쓴다 (4B: 94/309:1)
        if not RE_INLTXT.match(il.text or "") and il.ends:
            for ot in inls:
                if ot is not il and RE_INLTXT.match(ot.text or ""):
                    bx = ot.g.bbox()
                    if bx and all(bx[0] - 3 <= e[0] <= bx[2] + 3 and bx[1] - 3 <= e[1] <= bx[3] + 3 for e in il.ends):
                        il.text = ot.text
                        break
    sp_pts = []
    for g in doc.groups:
        spn = next((_text(p).strip() for p in g.prims if p.tag == "text" and RE_SPNAME.match(_text(p).strip())), None)
        if spn and g.cls == "wire":
            for p in g.prims:
                if p.tag == "ellipse":
                    sp_pts.append((float(p.attrs["cx"]), float(p.attrs["cy"]), spn))
    # SP 이름이 와이어 그룹 밖의 낱개 글자이고, 점(●, 반지름 약 5)은 와이어 그룹 안에 있는 경우: 글자 오른쪽 끝에 가장 가까운 점과 짝짓는다
    # SP 이름 글자와 접합점을 글자 상자에서 가장 가까운 것끼리 전체적으로 다시 짝짓는다
    # (그룹 안에 들어 있는 이름이 옆 와이어의 접합점 이름인 경우가 있어서 -- 마스터 SP8348A). 후보: 원(반지름 3.5~7) + 선 끝점이 모이는 별 모양 접합점
    all_ends = []
    for g in wires:
        pa = next((p for p in g.prims if p.tag == "path"), None)
        if pa is not None and (g.get("ref") or any(p.tag == "text" for p in g.prims)):
            qq = _pts(pa.attrs.get("d", ""))
            if len(qq) >= 2:
                all_ends.extend([qq[0], qq[-1]])
    cdots = []
    for g in doc.groups:
        if g.cls == "wire":
            for p in g.prims:
                if p.tag == "ellipse":
                    try:
                        if 3.5 <= float(p.attrs.get("rx", 0)) <= 7:
                            cdots.append((float(p.attrs["cx"]), float(p.attrs["cy"])))
                    except (KeyError, ValueError):
                        pass
    circ_dots = list(cdots)
    for p_ in all_ends:
        if sum(1 for o in all_ends if math.dist(o, p_) < 1.2) >= 3:
            cdots.append(p_)
    cdots = [d_ for i_, d_ in enumerate(cdots) if not any(math.dist(d_, o) < 2 for o in cdots[:i_])]
    sp_texts = []
    for g in doc.groups:
        for p in g.prims:
            if p.tag == "text" and RE_SPNAME.match(_text(p).strip()):
                sp_texts.append((_num(p.attrs.get("x")), _num(p.attrs.get("y")), _num(p.attrs.get("textLength"), 30.0), _text(p).strip()))
    pairs = []
    for x, y, L, t in sp_texts:
        for dx_, dy_ in cdots:
            dd = math.hypot(max(x - dx_, 0, dx_ - (x + L)), max((y - 9) - dy_, 0, dy_ - y))
            if dd <= 26:
                if any(math.dist((dx_, dy_), (ox_, oy_)) < 2 and on_ == t for ox_, oy_, on_ in sp_pts):
                    dd -= 4                                     # 같은 그룹 안에 있던 짝(이름+접합 원)에 가산점
                if (dx_, dy_) not in circ_dots and not any(math.dist((dx_, dy_), c_) < 2 for c_ in circ_dots):
                    dd += 12                                    # 선 끝이 모인 점보다 실제 접합 원(●)을 우선 (7A1: 옆 와이어 기호 끝점과 혼동 방지)
                pairs.append((dd, t, dx_, dy_))
    pairs.sort()
    new_sp, used_t, used_d = [], set(), set()
    for dd, t, dx_, dy_ in pairs:
        if (t, ) in used_t or (dx_, dy_) in used_d or t in used_t:
            continue
        used_t.add(t); used_d.add((dx_, dy_)); new_sp.append((dx_, dy_, t))
    for ox, oy, on in sp_pts:                                   # 새 짝짓기에서 빠진 이름은 예전(같은 그룹 안) 짝짓기를 유지
        if on not in used_t and not any(math.dist((ox, oy), d_) < 2 for d_ in used_d):
            new_sp.append((ox, oy, on))
    sp_pts = new_sp
    named = {n for _, _, n in sp_pts}
    dots = []
    for g in doc.groups:
        if g.cls == "wire":
            for p in g.prims:
                if p.tag == "ellipse":
                    try:
                        if 3.5 <= float(p.attrs.get("rx", 0)) <= 7:
                            dots.append((float(p.attrs["cx"]), float(p.attrs["cy"])))
                    except (KeyError, ValueError):
                        pass
    # 점(원)이 없고 선 여러 개가 한 점에서 만나는 접합(별 모양 그림 등)도 후보: 이름 있는 와이어 끝점이 2개 이상 모이는 곳
    ep = []
    for g in wires:
        pa = next((p for p in g.prims if p.tag == "path"), None)
        if pa is not None and (g.get("ref") or any(p.tag == "text" for p in g.prims)):
            qq = _pts(pa.attrs.get("d", ""))
            if len(qq) >= 2:
                ep.extend([qq[0], qq[-1]])
    for i_, p_ in enumerate(ep):
        if sum(1 for o in ep if math.dist(o, p_) < 1.2) >= 2 and not any(math.dist(p_, d_) < 2 for d_ in dots):
            dots.append(p_)
    cand = []
    for x, y, L, t in loose:
        if RE_SPNAME.match(t) and t not in named:
            for dx_, dy_ in set(dots):
                if any(math.dist((dx_, dy_), (a, b)) < 2 for a, b, _ in sp_pts):
                    continue
                ddx = max(x - dx_, 0, dx_ - (x + L)); ddy = max((y - 9) - dy_, 0, dy_ - y)   # 글자 상자와 점 사이 거리
                dd = math.hypot(ddx, ddy)
                if dd <= 26:
                    cand.append((dd, t, dx_, dy_))
    cand.sort()
    used_t, used_d = set(), set()
    for dd, t, dx_, dy_ in cand:
        if t in used_t or (dx_, dy_) in used_d:
            continue
        used_t.add(t); used_d.add((dx_, dy_))
        sp_pts.append((dx_, dy_, t))
    labels = []
    for g in doc.groups:
        if g.cls == "wire" or g.get("tag") == "AUTO_GENERATED":
            continue
        for p in g.prims:
            if p.tag == "text":
                mm = RE_LABEL.match(_text(p).strip())
                if mm:
                    labels.append((_num(p.attrs.get("x")), _num(p.attrs.get("y")), _num(p.attrs.get("textLength"), 30.0), mm.group(1), mm.group(2)))
    ground_polys = []                                           # 이름 없는 선(접지 기호의 세로선/가로 막대)
    for g in wires:
        pa = next((p for p in g.prims if p.tag == "path"), None)
        if pa is not None and not g.get("ref") and not any(p.tag == "text" for p in g.prims):
            qq = _pts(pa.attrs.get("d", ""))
            if len(qq) >= 2:
                ground_polys.append(qq)
    ground_groups = _ground_groups(ground_polys)
    rows = []
    for g in wires:
        paths_ = [p for p in g.prims if p.tag == "path"]
        path = paths_[0] if paths_ else None
        if path is None:
            continue
        if len(paths_) > 1:                                    # twist/기호 조각이 와이어 그룹에 섞여 첫 path 가 와이어가 아닌 경우: 가장 긴 path 를 와이어로 본다
            def _plen(pp):
                if "A" in pp.attrs.get("d", ""):
                    return 0
                qq = _pts(pp.attrs.get("d", ""))
                return sum(math.dist(qq[i], qq[i + 1]) for i in range(len(qq) - 1)) if len(qq) >= 2 else 0
            lens = [_plen(pp) for pp in paths_]
            if lens[0] < 40 and max(lens) > 3 * max(lens[0], 1):
                path = paths_[lens.index(max(lens))]
        q = _pts(path.attrs.get("d", ""))
        if len(q) < 2:
            continue
        lbl = [_text(p) for p in g.prims if p.tag == "text"]
        m = RE_WIRELBL.match(lbl[0].strip()) if lbl else None
        ends = [_end_of(q[0], comps, inls, refs), _end_of(q[-1], comps, inls, refs)]
        epts = [q[0], q[-1]]
        chained = [False, False]
        if len(paths_) > 1 and (ends[0] is None or ends[1] is None):   # 와이어 그룹 안에 인라인 기호 조각(짧은 선들)이 이어져 있으면 그 끝까지 따라가 본다
            segs = []
            for pp in paths_:
                if pp is path or "A" in pp.attrs.get("d", ""):
                    continue
                qq = _pts(pp.attrs.get("d", ""))
                if len(qq) == 2:
                    segs.append(qq)
            for i in (0, 1):
                if ends[i] is not None:
                    continue
                cur = q[0] if i == 0 else q[-1]
                used_ = set()
                for _ in range(8):
                    nxt = None
                    for k, sg in enumerate(segs):
                        if k in used_:
                            continue
                        for a_, b_ in ((sg[0], sg[1]), (sg[1], sg[0])):
                            dd_ = math.dist(a_, cur)
                            if dd_ <= 3.0 and (nxt is None or dd_ < nxt[0]):
                                nxt = (dd_, k, b_)
                    if not nxt:
                        break
                    used_.add(nxt[1]); cur = nxt[2]
                if used_:
                    epts[i] = cur; chained[i] = True
                    e2 = _end_of(cur, comps, inls, refs)
                    if e2:
                        ends[i] = e2
        for i, pt in enumerate(epts):
            if ends[i] is None:
                for cx, cy, spn in sp_pts:
                    if math.dist(pt, (cx, cy)) < 4:
                        ends[i] = dict(kind="sp", wdid=spn, conn=spn, port="junction", des="junction", term="", ok=True)
                        break
        for i, pt in enumerate(epts):                     # 끝이 비었으면: 선 끝 바로 위의 "WDID[.글자]:핀" 글자 (예 15/49:12, 15/49.B:1)
            if ends[i] is None:
                e = _label_end(pt, labels)
                if e:
                    if chained[i] and e.get("des") == "socket":      # 와이어 그룹 안의 인라인 반쪽 기호 끝 = 마스터 plug
                        e["des"] = "plug"
                    ends[i] = e
        for i, pt in enumerate(epts):                     # 실드선: 인라인 옆 낱개 글자 '94/417:1S' (선 끝 바로 위) -> 핀 1S
            e = ends[i]
            if e and e.get("kind") == "inline":
                for lx, ly, lL, lw, lp in labels:
                    if lp.endswith("S") and pt[1] - 14 <= ly <= pt[1] - 4 and lx - 8 <= pt[0] <= lx + lL + 40 and \
                            (not e.get("wdid") or e.get("wdid") == lw):
                        e.update(wdid=lw, conn=lw, port=lp, ok=True)
                        break
        for i, pt in enumerate(epts):                     # 끝이 접지 기호(이름 없는 선 + 막대)로 끝나면: 기호 아래 31/xx 글자 + 선 끝 옆 글자(A / GND)
            if ends[i] is None:
                e = _ground_end(pt, ground_groups, loose)
                if e:
                    ends[i] = e
        if prof == "RG4F1":                                     # RG4F1: 이중 원 접지 + 단자 글자(31/43.X1) / 점 아래 글자(31/HV001 ...)
            for i, pt in enumerate(epts):
                if ends[i] is None:
                    pt2_ = rg4f1.follow_stub(pt, rg_segs)
                    e = rg4f1.circle_ground_end(pt2_, rg_rings, rg_gl) or rg4f1.dot_label_end(pt, rg_dots, rg_dl)
                    if e:
                        ends[i] = e
        if not (g.get("ref") or (m and m.group(1))):            # 이름 없는 선(접지 기호의 짧은 선 등)은 와이어가 아님
            continue
        rows.append(dict(
            wire=(g.get("ref") or (m.group(1) if m else "") or "").replace("\u00a0", " ").strip(), type=m.group(2) if m else "", area=g.get("area") or (m.group(3) if m else ""),
            color=g.get("color") or (m.group(4) if m else ""), pummel=g.get("option_description") or "", pummelvdn=g.get("option") or "",
            variant=g.get("variant") or "", harness=g.get("harness") or "", gid=g.gid, frm=ends[0], to=ends[1]))
    return rows


class _FakeRef:
    def __init__(self, t):
        self.texts = [t]


def _seg_dist(p, a, b):
    ax, ay, bx, by = a[0], a[1], b[0], b[1]
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    t = 0.0 if L2 == 0 else max(0.0, min(1.0, ((p[0] - ax) * dx + (p[1] - ay) * dy) / L2))
    return math.dist(p, (ax + t * dx, ay + t * dy))


def _touch(a, b, tol=1.5):
    for pa in (a[0], a[-1]):
        for i in range(len(b) - 1):
            if _seg_dist(pa, b[i], b[i + 1]) < tol:
                return True
    for pb in (b[0], b[-1]):
        for i in range(len(a) - 1):
            if _seg_dist(pb, a[i], a[i + 1]) < tol:
                return True
    return False


def _ground_groups(polys):
    """이름 없는 선들과 각 bbox (접지 기호 탐색용). 묶기는 끝점에서 필요할 때만 한다."""
    bb = []
    for p in polys:
        xs = [v[0] for v in p]; ys = [v[1] for v in p]
        bb.append((min(xs) - 2, min(ys) - 2, max(xs) + 2, max(ys) + 2))
    return (polys, bb)


def _ground_end(pt, groups, loose):
    """와이어 끝이 접지 기호(이름 없는 선들)에 닿아 있으면, 기호 바로 아래의 WDID 글자(31/2, 31/4.1)와
    선 끝 옆의 글자(A, GND)로 레퍼런스 끝을 만든다. 마스터: 31/2 + A -> 31/2.A, 핀 1, 설명 A / 31/4.1 + GND -> 31/4.1, 핀 1, GND."""
    polys, bb = groups
    if not polys:
        return None
    start = [i for i, p in enumerate(polys)
             if bb[i][0] <= pt[0] <= bb[i][2] and bb[i][1] <= pt[1] <= bb[i][3]
             and any(_seg_dist(pt, p[k], p[k + 1]) < 1.5 for k in range(len(p) - 1))]
    if not start:
        return None
    grp = [start[0]]
    seen = {start[0]}
    qi = 0
    while qi < len(grp):                                       # 접지 기호는 선이 몇 개 안 됨 -> 많이 묶이면 표/격자선이라 포기
        c = grp[qi]; qi += 1
        cb = bb[c]
        for j in range(len(polys)):
            if j in seen:
                continue
            jb = bb[j]
            if jb[2] < cb[0] or jb[0] > cb[2] or jb[3] < cb[1] or jb[1] > cb[3]:
                continue
            if _touch(polys[c], polys[j]):
                seen.add(j); grp.append(j)
                if len(grp) > 30:
                    return None
    xs = [v[0] for i in grp for v in polys[i]]; ys = [v[1] for i in grp for v in polys[i]]
    hit = (min(xs), max(xs), max(ys))
    x0, x1, y1 = hit
    best, bd = None, 1e9
    for x, y, L, t in loose:
        if not re.match(r"^\d+/\d+(\.\d+)?$", t):
            continue
        top = y - 9
        if top < y1 - 3 or top > y1 + 30 or x > x1 + 40 or x + L < x0 - 40:
            continue
        d = abs(top - y1) + abs((x + L / 2) - (x0 + x1) / 2)
        if d < bd:
            best, bd = t, d
    if not best:
        return None
    letter = None
    for x, y, L, t in loose:
        if (re.match(r"^[A-Z]$", t) or t == "GND") and pt[0] - 4 <= x <= pt[0] + 30 and pt[1] - 22 <= y <= pt[1] + 4:
            letter = t
            break
    e = ref_end(_FakeRef("%s.%s" % (best, letter or "GND")))
    e["ground"] = True
    return e


RE_LABEL = re.compile(r"^(\d+/\d+(?:\.[A-Za-z0-9]+)?):(\d+S?)$")


def _label_end(pt, labels):
    """선 끝(pt) 바로 위에 놓인 '15/49:12' 형태의 글자 -> 그 부품의 핀. 마스터는 socket 으로 표기."""
    best, bd = None, 1e9
    for x, y, L, wdid, port in labels:
        if not (pt[1] - 16 <= y <= pt[1] + 4):
            continue
        if not (x - 8 <= pt[0] <= x + L + 40):
            continue
        d = abs(pt[1] - y) + abs(pt[0] - (x + L))
        if d < bd:
            best, bd = (wdid, port), d
    des = "socket"
    if not best:                                              # 선 끝 바로 아래에 놓인 글자 (피그테일 끝의 커넥터 반쪽이 부품 그룹 안에 있는 경우, 마스터는 plug)
        for x, y, L, wdid, port in labels:
            if pt[1] + 4 < y <= pt[1] + 22 and x - 2 <= pt[0] <= x + L + 4 and not port.endswith("S"):
                d = abs(y - pt[1])
                if best is None or d < bd:
                    best, bd = (wdid, port), d
        des = "plug"
    if not best:
        return None
    return dict(kind="label", wdid=best[0], conn=best[0], port=best[1], des=des, term="", ok=True)


def _end_of(pt, comps, inls, refs):
    for c in comps:
        e = comp_end(c, pt)
        if e:
            return e
    for rf in refs:
        if rf.hit(pt):
            return ref_end(rf)
    for il in inls:
        s = il.hit(pt)
        if s:
            return inline_end(il, pt, s)
    return None


# ---------------------------------------------------------------- 다른 시트의 부품 핀 찾기 (레퍼런스 "시트:WDID.핀이름")
def _loose_texts(doc):
    out = []
    for g in doc.groups:
        if g.cls != "wire":
            for p in g.prims:
                if p.tag == "text":
                    out.append((_num(p.attrs.get("x")), _num(p.attrs.get("y")), _num(p.attrs.get("textLength"), 20.0), _text(p).strip()))
    return out


def pin_directory(docs):
    """모든 문서의 부품에서 (WDID, 핀이름) -> dict(port, conn, letter) 사전"""
    D = {}
    for doc in docs:
        hdrs = _doc_headers(doc)
        for g in doc.groups:
            if g.get("type") != "component" or g.get("tag") == "AUTO_GENERATED":
                continue
            c = Comp(g)
            if not c.rects and not c.small:
                continue
            fix_wdid_by_position(c, hdrs)
            add_header_letters(c, _loose_texts(doc))
            names = [u for u in c.texts if _is_name(u)]
            for t, m in c.pins:
                best = None
                for u in names:
                    dy = t[1] - u[1]
                    al = min(abs(u[0] - t[0]), abs((u[0] + u[2]) - (t[0] + t[2])), abs((u[0] + u[2] / 2) - (t[0] + t[2] / 2))) < 11.0
                    for d in (dy, -dy):
                        if 0 < d <= 24 and al and (best is None or d < best[0]):
                            best = (d, u)
                if best:
                    ent = dict(port=m.group(2), letter=m.group(1), conn=_connector_text(c, m.group(1)))
                    D.setdefault((c.wdid, best[1][3]), ent)
                    D.setdefault((c.wdid.split(".")[0], best[1][3]), ent)
    return D


def resolve_refs(rows, pindir):
    for r in rows:
        for k in ("frm", "to"):
            e = r.get(k)
            if e and e.get("kind") == "ref" and e.get("needs_dir") and pindir:
                ent = pindir.get((e["wdid"], e["des"])) or pindir.get((e["wdid"].split(".")[0], e["des"]))
                if ent:
                    e.update(port=ent["port"], conn=ent["conn"], ok=True, needs_dir=False)
    return rows


def merge_sheets(rows_by_sheet):
    """여러 시트(SVG)의 행을 와이어 이름으로 합친다. 같은 와이어가 두 시트에 나오면
    한쪽 끝의 레퍼런스(다른 시트 표시)를 상대 시트의 실제 끝점으로 대체한다.
    rows_by_sheet: [(sheet_name, [row...]), ...] -> [row...] (각 row 에 sheets 목록)"""
    byw = {}
    order = []
    for sheet, rows in rows_by_sheet:
        for r in rows:
            r = dict(r); r["sheets"] = [sheet]
            if r["wire"] not in byw:
                byw[r["wire"]] = r; order.append(r["wire"])
            else:
                _merge_two(byw[r["wire"]], r)
    return [byw[w] for w in order]


def _is_concrete(e):
    return bool(e) and e.get("kind") in ("comp", "inline", "sp")


def _same_end(a, b):
    return bool(a) and bool(b) and a.get("wdid") == b.get("wdid") and a.get("port") == b.get("port")


def _merge_two(a, b):
    a["sheets"].extend(b["sheets"])
    for k in ("type", "area", "color", "pummel", "pummelvdn", "variant", "harness"):
        if not a.get(k) and b.get(k):
            a[k] = b[k]
    cands = [e for e in (b.get("frm"), b.get("to")) if _is_concrete(e)]
    for k in ("frm", "to"):
        e = a.get(k)
        if e is None or e.get("kind") == "ref":
            other = a.get("to" if k == "frm" else "frm")
            for c in cands:
                if not _same_end(c, other) and not (other and c.get("wdid") and c.get("wdid") == other.get("wdid")):
                    a[k] = c
                    break
    # 아직 비어 있는 끝: 상대 도면의 레퍼런스(시트:WDID.핀:번호)가 알려 주는 끝으로 채운다
    # (이 도면에서는 부품 머리글이 없어 끝을 못 읽는 경우 등). 이미 정해진 반대쪽 끝과 같은 부품이면 건너뜀.
    for k in ("frm", "to"):
        if a.get(k) is None:
            other = a.get("to" if k == "frm" else "frm")
            for c in (b.get("frm"), b.get("to")):
                if not c or c.get("kind") != "ref" or not c.get("ok"):
                    continue
                if other and (_same_end(c, other) or c.get("wdid") == other.get("wdid")):
                    continue
                a[k] = c
                break


# ---------------------------------------------------------------- 문서 수집 / 표 만들기
def doc_sheet_name(doc, label=""):
    t = getattr(doc, "title", None) or ""
    return t or os.path.splitext(os.path.basename(label or ""))[0]


def has_wires(doc):
    return any(g.cls == "wire" and g.get("type") == "physical_wire" for g in doc.groups)


def collect(sources, log=None, profile=None):
    """sources: [(label, Doc)] -> (rows, info)
    wire 가 없는 도면은 제외한다.  info = dict(used=[(label, n)], skipped=[label], pindir_size=int)"""
    def L(m):
        if log:
            log(m)
    used, skipped, parts, docs = [], [], [], []
    for label, doc in sources:
        if not has_wires(doc):
            skipped.append(label); L("제외(와이어 없음): %s" % label); continue
        docs.append((label, doc))
    pd = pin_directory([d for _, d in docs])
    for label, doc in docs:
        L("추출 중: %s ..." % label)
        rows = extract_doc(doc, profile)
        if "Tadapter" in doc_sheet_name(doc, label):             # ETC T-adapter 하네스: 마스터는 인라인 WDID 를 94/404.1_socket / 94/404.1_plug 로 나눠 적는다
            for r_ in rows:
                for k_ in ("frm", "to"):
                    e_ = r_.get(k_)
                    if e_ and e_.get("kind") == "inline" and re.search(r"\.\d+$", e_.get("wdid") or "") and e_.get("des") in ("socket", "plug"):
                        e_["wdid"] = "%s_%s" % (e_["wdid"], e_["des"]); e_["conn"] = e_["wdid"]
        resolve_refs(rows, pd)
        for r in rows:
            r["sheet_label"] = label
        parts.append((doc_sheet_name(doc, label), rows))
        used.append((label, len(rows))); L("추출: %s  (와이어 %d개)" % (label, len(rows)))
    merged = merge_sheets(parts)
    return merged, dict(used=used, skipped=skipped, pindir=len(pd))


def _v(x):
    return "" if x is None else str(x)


def end_cells(e):
    if not e:
        return ["", "", "", "", ""]
    t = _v(e.get("term")).strip()
    return [_v(e.get("wdid")), _v(e.get("conn")), _v(e.get("port")), _v(e.get("des")), (t + " ") if t else ""]


def row_to_cells(r):
    f, t = end_cells(r.get("frm")), end_cells(r.get("to"))
    return [(r["wire"] or "").replace("\u00a0", " ").strip(), "", f[0], f[1], f[2], f[3], f[4], t[0], t[1], t[2], t[3], t[4],
            r["type"], r["area"], r["color"], "", r["pummel"], r["pummelvdn"], r["variant"], r["variant"], r["harness"],
            ", ".join(dict.fromkeys(x for x in (r.get("sheets") or []) if x))]


def export_xlsx(path, rows):
    import openpyxl
    from openpyxl.styles import Font, PatternFill
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Sheet1"
    ws.append(HEADERS)
    for r in rows:
        ws.append(row_to_cells(r))
    for c in ws[1]:
        c.font = Font(bold=True)
        c.fill = PatternFill("solid", fgColor="DDEBF7")
    ws.freeze_panes = "B2"
    for i, w in enumerate([12, 14, 10, 12, 8, 34, 9, 10, 12, 8, 34, 9, 7, 6, 6, 6, 30, 16, 9, 9, 8, 30], 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w
    ws.auto_filter.ref = ws.dimensions
    wb.save(path)
    return len(rows)


# ---------------------------------------------------------------- 도면 기준으로 엑셀 수정
_ATTR_COLS = [("Type", 12, "type"), ("Area", 13, "area"), ("Color", 14, "color"), ("Pummel", 16, "pummel"),
              ("PummelVdn", 17, "pummelvdn"), ("Variant", 18, "variant"), ("VariantVdn", 19, "variant"), ("harness", 20, "harness")]
_END_FIELDS = [("WDID", 0), ("Connector", 1), ("Port", 2), ("Port Des", 3), ("Terminal", 4)]


def _norm(x):
    return _v(x).strip()


def update_xlsx(master, out, rows, log=None):
    """도면(rows)을 기준으로 마스터 시그널 테이블을 수정해 out 에 저장.  변경 내역 시트 추가.
    반환: dict(changed_cells, changed_rows, added, candidates, report=[...])"""
    import openpyxl
    from openpyxl.styles import PatternFill, Font
    wb = openpyxl.load_workbook(master)
    ws = wb.worksheets[0]
    hdr = [str(c.value or "").strip() for c in ws[1]]
    if hdr[:3] != HEADERS[:3] or "To WDID" not in hdr:
        raise ValueError("시그널 테이블 형식이 아닙니다 (1행 머리글: Wire, Wireinfo, From WDID, …).")
    ncol = len(HEADERS)
    VCOL = ncol                                           # V열 (wiring diagram name)
    if len(hdr) < VCOL or hdr[VCOL - 1] == "":
        ws.cell(1, VCOL).value = HEADERS[-1]
        h0 = ws.cell(1, VCOL - 1)
        if h0.has_style:
            from copy import copy
            c = ws.cell(1, VCOL); c.font = copy(h0.font); c.fill = copy(h0.fill); c.alignment = copy(h0.alignment); c.border = copy(h0.border)
    index = {}
    for r in range(2, ws.max_row + 1):
        w = ws.cell(r, 1).value
        if w not in (None, ""):
            index[str(w).strip()] = r
    Y = PatternFill("solid", fgColor="FFF2CC")
    G = PatternFill("solid", fgColor="E2EFDA")
    R = PatternFill("solid", fgColor="F8CBAD")
    report = []
    changed_rows = set()
    n_cells = 0
    added = 0

    def put(r, col, new, wire, label, sheet):
        nonlocal n_cells
        old = ws.cell(r, col + 1 if False else col).value
        ws.cell(r, col).value = new
        ws.cell(r, col).fill = Y
        report.append(("수정", wire, label, _v(old), _v(new), sheet))
        n_cells += 1
        changed_rows.add(r)

    for row in rows:
        wire = row["wire"]
        sheet = ", ".join(row.get("sheets", [])) if row.get("sheets") else ""
        r = index.get(wire)
        cells = row_to_cells(row)
        if r is None:                                     # 새 와이어 -> 행 추가
            r = ws.max_row + 1
            for c, v in enumerate(cells, 1):
                ws.cell(r, c).value = v
                ws.cell(r, c).fill = G
            index[wire] = r
            report.append(("추가", wire, "(행 전체)", "", "%s → %s" % (cells[2] + ":" + cells[4], cells[7] + ":" + cells[9]), sheet))
            added += 1
            continue
        # 속성 열
        for label, col, key in _ATTR_COLS:
            new = _v(row.get(key))
            old = ws.cell(r, col + 1).value
            if new != "" and _norm(old) != _norm(new):
                put(r, col + 1, new, wire, label, sheet)
        # V열: 도면 이름 (엑셀에 이미 적힌 도면 이름은 유지하고, 이번에 확인된 도면을 추가)
        have = [x.strip() for x in _v(ws.cell(r, VCOL).value).split(",") if x.strip()]
        add = [x for x in dict.fromkeys(row.get("sheets") or []) if x and x not in have]
        if add:
            put(r, VCOL, ", ".join(have + add), wire, HEADERS[-1], sheet)
        # 양끝 (방향은 엑셀 기준을 유지)
        xa = [_norm(ws.cell(r, 3 + k).value) for k in range(5)]
        xb = [_norm(ws.cell(r, 8 + k).value) for k in range(5)]
        ea, eb = row.get("frm"), row.get("to")

        def score(e, x):
            return 0 if not e else (2 if _norm(e.get("wdid")) == x[0] else 0) + (1 if _norm(e.get("port")) == x[2] else 0)
        if score(ea, xb) + score(eb, xa) > score(ea, xa) + score(eb, xb):
            ea, eb = eb, ea
        for e, base, label in ((ea, 3, "From"), (eb, 8, "To")):
            if not e or e.get("kind") is None:
                continue
            old = [_norm(ws.cell(r, base + k).value) for k in range(5)]
            new = end_cells(e)
            newn = [_norm(x) for x in new]
            moved = bool(newn[0]) and newn[0] != old[0]
            raw = [e.get("wdid"), e.get("conn"), e.get("port"), e.get("des"), e.get("term")]
            for (fname, k) in _END_FIELDS:
                val, ov = newn[k], old[k]
                if raw[k] is None:                            # 도면만으로 알 수 없는 값 (다른 도면 필요)
                    if moved:
                        report.append(("확인 필요", wire, "%s %s" % (label, fname), ov, "도면만으로 알 수 없음 (해당 부품이 있는 도면을 함께 선택하세요)", sheet))
                    continue
                if e.get("kind") == "ref" and k == 3 and val == "socket" and ov in ("plug", "socket"):
                    continue                                  # 레퍼런스 plug/socket 은 추정값
                if k >= 1 and val == "" and not moved:
                    continue                                  # 도면에서 알 수 없는 값은 지우지 않음
                if e.get("kind") == "ref" and k in (1, 2, 4) and (e.get(("conn", "", "port", "", "term")[k]) is None) and not moved:
                    continue
                if k == 1 and not moved and e.get("kind") == "comp" and ov and val and (val.startswith(ov + ".") or ov.startswith(val + ".")):
                    continue                                  # 커넥터의 ".A/.B/.POWER" 같은 접미사 유무는 마스터에서도 일정하지 않아 도면만으로 판별할 수 없음 -> 엑셀 값을 존중
                if e.get("guess") and not moved and k in (2, 3) and ov:
                    continue                                  # 이름만 있는 레퍼런스(.GND 등)의 핀 번호/설명은 추정값 -> 엑셀 값을 존중
                if val != ov:
                    put(r, base + k, new[k], wire, "%s %s" % (label, fname), sheet)

    # 참고: 도면에서 삭제되었을 수 있는 와이어(수정하지 않고 변경 내역에만 표시): 엑셀 행의 양끝 부품이 같은 도면에 모두 그려져 있는데 그 도면에 그 와이어가 없는 경우
    sheet_comps = {}
    for row in rows:
        for e in (row.get("frm"), row.get("to")):
            if e and e.get("kind") == "comp" and e.get("wdid"):
                for sh in row.get("sheets", []):
                    sheet_comps.setdefault(sh, set()).add(e["wdid"])
    names = {row["wire"] for row in rows}
    cands = []
    for w, r in index.items():
        if w in names:
            continue
        a, b = _norm(ws.cell(r, 3).value), _norm(ws.cell(r, 8).value)
        sh = next((k for k, v in sheet_comps.items() if a in v and b in v), None)
        if sh:
            cands.append((w, r))
            report.append(("참고(엑셀에만 있음)", w, "(행 전체)", "%s → %s" % (a, b), "같은 도면에 두 부품이 있으나 해당 와이어 없음 (다른 도면의 와이어일 수 있음, 수정 안 함)", sh))
    # 변경 내역 시트
    if "변경 내역" in wb.sheetnames:
        del wb["변경 내역"]
    lg = wb.create_sheet("변경 내역")
    lg.append(["구분", "Wire", "열", "엑셀 기존값", "도면 값", "도면(시트)"])
    for c in lg[1]:
        c.font = Font(bold=True)
    for x in report:
        lg.append(list(x))
    for i, w in enumerate([10, 12, 18, 34, 40, 30], 1):
        lg.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w
    lg.freeze_panes = "A2"
    wb.save(out)
    return dict(changed_cells=n_cells, changed_rows=len(changed_rows), added=added, candidates=len(cands), report=report)


def load_doc(path):
    from export import load_any
    doc, _ = load_any(path)
    return doc
