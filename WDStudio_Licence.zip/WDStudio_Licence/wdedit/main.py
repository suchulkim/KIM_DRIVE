#!/usr/bin/env python3
"""배선도 편집기.

GUI :  python main.py [file.pdf|file.svg]
CLI :  python main.py --split in.pdf out_dir [--no-pdf] [--no-svg] [--no-fix] [--no-auto]
CLI :  python main.py --convert in.pdf out.svg [--pdf out.pdf] [--check] [--fix] [--auto] [--image image|ocr]
CLI :  python main.py --sigtable out.xlsx a.svg b.svg ...          (시그널 테이블 내보내기, wire 없는 도면 제외)
CLI :  python main.py --sigupdate master.xlsx out.xlsx a.svg ...   (도면 기준으로 엑셀 수정)
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def cli(args):
    import rules
    from export import load_any, export_pdf, export_svg
    src, dst = args[0], args[1]
    doc, imp = load_any(src)
    if "--image" in args and imp is not None and not (imp.stats["wire"] or imp.stats["component"] or imp.stats["inline"] or imp.stats["reference"]):
        import imgimport
        doc, warn = imgimport.build(src, args[args.index("--image") + 1])
        for w in warn:
            print("warn:", w)
        imp = None
    if "--fix" in args:
        print("auto-fix:", rules.fix(doc))
    if "--auto" in args:
        print("AUTO_GENERATED:", rules.regenerate_auto_symbols(doc))
    if imp is not None:
        print(imp.stats)
        for w in imp.warn:
            print("warn:", w)
    export_svg(doc, dst)
    if "--pdf" in args:
        export_pdf(doc, args[args.index("--pdf") + 1])
    if "--check" in args:
        for i in rules.check(doc):
            print("[%s] id-%d %s" % (i.level, i.gid, i.msg))


def cli_split(args):
    import splitpdf
    src, out = args[0], args[1]
    for n, msgs in splitpdf.run(src, out, make_pdf="--no-pdf" not in args, make_svg="--no-svg" not in args,
                                fix="--no-fix" not in args, auto="--no-auto" not in args,
                                progress=lambda i, t, nm, m: print("[%d/%d] %s" % (i + 1, t, nm)) if nm else None):
        if msgs:
            print("  !", n, "; ".join(msgs))


def cli_sig(update, args):
    import sigtable
    if update:
        master, out, files = args[0], args[1], args[2:]
    else:
        master, out, files = None, args[0], args[1:]
    import glob
    paths = []
    for f in files:
        paths.extend(sorted(glob.glob(os.path.join(f, "*.svg"))) if os.path.isdir(f) else [f])
    srcs = [(os.path.basename(p), sigtable.load_doc(p)) for p in paths]
    rows, info = sigtable.collect(srcs, print)
    if not rows:
        print("와이어가 있는 도면이 없습니다."); return
    if update:
        res = sigtable.update_xlsx(master, out, rows)
        print("수정한 칸 %d, 수정한 행 %d, 추가한 행 %d (참고 %d) -> %s" % (res["changed_cells"], res["changed_rows"], res["added"], res["candidates"], out))
    else:
        print("%d행 -> %s" % (sigtable.export_xlsx(out, rows), out))


if __name__ == "__main__":
    if len(sys.argv) > 3 and sys.argv[1] in ("--split", "--sigtable", "--sigupdate", "--convert"):
        import licensing
        licensing.enforce_cli()
    if len(sys.argv) > 3 and sys.argv[1] == "--split":
        cli_split(sys.argv[2:])
    elif len(sys.argv) > 3 and sys.argv[1] in ("--sigtable", "--sigupdate"):
        cli_sig(sys.argv[1] == "--sigupdate", sys.argv[2:])
    elif len(sys.argv) > 3 and sys.argv[1] == "--convert":
        cli(sys.argv[2:])
    else:
        from gui import main
        main()
