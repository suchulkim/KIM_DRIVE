"""배선도 PDF(여러 페이지) 를 페이지별 배선도명 PDF 로 분할하고, 각 페이지를 SVG 로 변환 저장.

배선도명은 각 페이지 오른쪽 아래 표제란의 'Document title' 값 (예: 1E8_CAN_FD) 이다.
"""
import os
import re

import pymupdf

TITLE_RECT = (1125, 872, 1417, 892)          # 표제란 Document title 값 영역 (페이지 1417 x 1001 기준)
_BAD = re.compile(r'[\\/:*?"<>|\r\n\t]+')


def _title(page):
    r = page.rect
    sx, sy = r.width / 1417.0, r.height / 1001.0
    box = pymupdf.Rect(TITLE_RECT[0] * sx, TITLE_RECT[1] * sy, TITLE_RECT[2] * sx, TITLE_RECT[3] * sy)
    words = [w for w in page.get_text("words", clip=box) if w[4].strip() and w[4] != "Document"]
    words.sort(key=lambda w: (round(w[1]), w[0]))
    t = "".join(w[4] for w in words if w[4] != "title")
    return _BAD.sub("_", t).strip(" ._")


def plan(path):
    """[(페이지번호(0부터), 배선도명)] — 같은 이름은 _2, _3 을 붙여 구분한다."""
    return [(pi, n) for _, pi, n in plan_many([path])]


def plan_many(paths):
    """여러 PDF -> [(PDF 경로, 페이지번호(0부터), 배선도명)].  표제란에서 이름을 못 읽으면 (한 페이지짜리 PDF 는) 파일 이름을 쓰고,
    전체에서 같은 이름은 _2, _3 을 붙여 구분한다."""
    out, seen = [], {}
    for path in paths:
        doc = pymupdf.open(path)
        base = _BAD.sub("_", os.path.splitext(os.path.basename(path))[0]).strip(" ._")
        single = len(doc) == 1
        for i in range(len(doc)):
            n = _title(doc[i]) or (base if single else "%s_p%03d" % (base, i + 1))
            seen[n] = seen.get(n, 0) + 1
            out.append((path, i, n if seen[n] == 1 else "%s_%d" % (n, seen[n])))
        doc.close()
    return out


def run(path, outdir, make_pdf=True, make_svg=True, fix=True, auto=True, pages=None, progress=None, cancel=None):
    """분할/변환 실행(PDF 한 개). progress(i, total, name, msg) 호출. 결과 [(name, [메시지...])] 반환."""
    items = plan_many([path])
    if pages is not None:
        items = [x for x in items if x[1] in pages]
    return run_many(items, outdir, make_pdf, make_svg, fix, auto, progress, cancel)


def run_many(items, outdir, make_pdf=True, make_svg=True, fix=True, auto=True, progress=None, cancel=None):
    """items = [(PDF 경로, 페이지번호, 배선도명)] 를 차례로 PDF 저장 / SVG 변환. 결과 [(name, [메시지...])]"""
    os.makedirs(outdir, exist_ok=True)
    srcs = {}
    res = []
    for k, (path, pi, name) in enumerate(items):
        if cancel and cancel():
            break
        if progress:
            progress(k, len(items), name, "")
        if path not in srcs:
            srcs[path] = pymupdf.open(path)
        src = srcs[path]
        msgs = []
        pdf_path = os.path.join(outdir, name + ".pdf")
        made = True
        if os.path.abspath(pdf_path) == os.path.abspath(path):    # 입력 PDF 와 같은 이름/폴더면 덮어쓰지 않고 그대로 사용(삭제도 안 함)
            made = False
        else:
            try:
                one = pymupdf.open()
                one.insert_pdf(src, from_page=pi, to_page=pi)
                one.save(pdf_path, garbage=3, deflate=True)
                one.close()
            except Exception as ex:
                res.append((name, ["PDF 저장 실패: %s" % ex])); continue
        if make_svg:
            try:
                import rules
                from export import export_svg, load_any
                doc, imp = load_any(pdf_path)
                if imp is not None and not (imp.stats["wire"] or imp.stats["component"] or imp.stats["inline"] or imp.stats["reference"] or imp.stats["sp"]):
                    done_img = False
                    try:                                   # 선/글자 정보 없이 이미지(사진)만 있는 페이지 -> 자동으로 이미지 모드로 삽입
                        import imgimport
                        if imgimport.has_image_only(pdf_path):
                            doc, _w = imgimport.build(pdf_path, "image")
                            msgs.append("이미지만 있는 페이지: 이미지 모드로 변환했습니다")
                            done_img = True
                    except Exception as ex_:
                        msgs.append("이미지 모드 변환 실패: %s" % ex_)
                    if not done_img:
                        msgs.append("인식된 배선 요소가 없습니다(목록/이미지 페이지일 수 있음)")
                if fix:
                    rules.fix(doc)
                if auto:
                    rules.regenerate_auto_symbols(doc)
                export_svg(doc, os.path.join(outdir, name + ".svg"))
                nerr = sum(1 for i in rules.check(doc) if i.level == "error")
                if nerr:
                    msgs.append("규칙 오류 %d건 남음" % nerr)
            except Exception as ex:
                msgs.append("SVG 변환 실패: %s" % ex)
        if not make_pdf and made:
            try:
                os.remove(pdf_path)
            except OSError:
                pass
        res.append((name, msgs))
    for sd in srcs.values():
        sd.close()
    if progress:
        progress(len(items), len(items), "", "done")
    return res
