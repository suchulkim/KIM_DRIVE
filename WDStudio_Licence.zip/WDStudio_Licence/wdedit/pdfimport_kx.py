"""KX11 계열(지리/Geely) 시트 PDF -> 배선도 SVG 변환기.

PDF 특징 : 832x589pt 용지, 이중 프레임, wire 라벨 'CA2000C FLRY-B_0.35 VT' / 'BD OPT01',
            굵은 검은 막대 = 핀, 노란 꼬임 기호 + 'T2_0249', 검은 점 + 'SP_CA2000A_C'.
출력 구조는 프로젝트의 KX11 SVG(3B/8B2 시트) 를 따른다 :
  wire      : meta type/tag/ref/variant/pummel/harness/area/signal/color + path + 색상/굵기 글자 2개
  component : meta type/tag/ref/description/variant/pummel + rect, 핀, 내부선, 글자
  inline    : meta ... ref=94/번호:핀
  splice    : symbol(physical_splice_connector) + wire 위 점
"""
from __future__ import annotations
import math
import re

from model import Doc, Group, Prim, fmt, path_points

STROKE = "#000000"
RE_REF = re.compile(r"^[A-Z]{1,4}\d{2,5}[A-Z]{1,3}$")
RE_L2 = re.compile(r"^([A-Z]{2})\s+(\S.*)$")
RE_COMP_HDR = re.compile(r"^(\d+/\d+)\s+(.+)$")
RE_INL = re.compile(r"^(\d+/\d+)_([A-Z]{2})$")
RE_TWIST = re.compile(r"^T\d+_\d+$")
RE_SP = re.compile(r"^SP_\w+$")
RE_XREF = re.compile(r"^\d+[A-Z]\d*_\S+:\S+(\s+\S+)?$")
VARIANT = "KX11"


def is_label1(s):
    p = s.split()
    return 2 <= len(p) <= 3 and bool(RE_REF.match(p[0])) and ("_" in p[1] or p[1] in ("SL",))


def _seg_dist(p, a, b):
    ax, ay = a; bx, by = b; px, py = p
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    t = 0 if L2 == 0 else max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / L2))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def _poly_dist(p, pts):
    return min(_seg_dist(p, a, b) for a, b in zip(pts, pts[1:])) if len(pts) > 1 else 1e9


class KX:
    def __init__(self, imp):
        import pdfimport as P
        self.P = P
        self.imp = imp
        self.T = [t for t in imp.T if not (len(t.s) == 1 and t.font.startswith('Arial') and 8 <= t.size <= 10)]   # 프레임 눈금 글자
        self.T = self._merge_han(self.T)
        self.D = [d for d in imp.D]
        self.sheet = imp.sheet
        self.warn = []
        self.cnt = 0
        self.tags = 1050000

    # ------------------------------------------------------------------ 좌표
    def x(self, v): return (v - self.ox) / self.S
    def y(self, v): return (v - self.oy) / self.S

    def pt(self, p): return (self.x(p[0]), self.y(p[1]))

    def tag(self, pre, suf="_"):
        self.tags += 1
        return "%s%d%s" % (pre, self.tags, suf)

    def text(self, s, ox, oy, size, width, rot=0, anchor="start"):
        x, y = self.x(ox), self.y(oy)
        L = width / self.S
        return Prim("text", {"x": fmt(x), "y": fmt(y), "text-anchor": anchor, "fill": STROKE,
                             "transform": "rotate(%d,%s,%s)" % (rot, fmt(x), fmt(y)), "textLength": fmt(L),
                             "font-family": "OF Helvetica", "font-size": fmt(size / self.S)}, s)

    def ttext(self, t):
        rot = 0 if t.rot in (0, 360) else int(t.rot)
        return self.text(t.s, t.ox, t.oy, t.size, t.len, rot)

    def path(self, pts, w=0.75, cap="butt", join="round"):
        d = "M" + " L".join("%s,%s" % (fmt(a), fmt(b)) for a, b in (self.pt(p) for p in pts))
        return Prim("path", {"d": d, "fill": "none", "stroke": STROKE, "stroke-linecap": cap, "stroke-linejoin": join, "stroke-width": fmt(w)})

    def drawing_prims(self, d):
        """임의 드로잉 -> prim 들 (선/사각형/원)."""
        out = []
        P = self.P
        w = 0.75
        if d.pts and len(d.pts) >= 2:
            out.append(self.path(d.pts, 3 if d.w >= 2.5 else 0.75))
            return out
        for it in d.items:
            k = it[0]
            if k == "l":
                out.append(self.path([(it[1].x, it[1].y), (it[2].x, it[2].y)]))
            elif k in ("re", "qu"):
                r = it[1].rect if k == "qu" else it[1]
                if k == "qu":
                    q = it[1]
                    pts = [(q.ul.x, q.ul.y), (q.ur.x, q.ur.y), (q.lr.x, q.lr.y), (q.ll.x, q.ll.y), (q.ul.x, q.ul.y)]
                    out.append(self.path(pts))
                else:
                    x0, y0 = self.pt((r.x0, r.y0))
                    out.append(Prim("rect", {"x": fmt(x0), "y": fmt(y0), "width": fmt(r.width / self.S), "height": fmt(r.height / self.S),
                                             "stroke": STROKE if d.type != "f" else "none", "fill": "none", "stroke-width": "0.75"}))
            elif k == "c":
                r = d.rect
                cx, cy = self.pt(((r.x0 + r.x1) / 2, (r.y0 + r.y1) / 2))
                rx = r.width / 2 / self.S; ry = r.height / 2 / self.S
                out.append(Prim("ellipse", {"cx": fmt(cx), "cy": fmt(cy), "rx": fmt(rx), "ry": fmt(ry), "stroke": STROKE, "fill": "none", "stroke-width": "0.75"}))
                break
        return out

    def _comp_harness(self, c, wires):
        """부품 핀 막대에 붙은 wire 의 하네스 코드(AR1 규칙: 연결 wire 2행 라벨). 없으면 *opt*."""
        r = c["rect"]
        big = self.P.pymupdf.Rect(r.x0 - 4, r.y0 - 4, r.x1 + 4, r.y1 + 4)
        for w in wires:
            if not w["lab"]:
                continue
            if any(big.contains(self.P.pymupdf.Point(p[0], p[1])) for p in (w["pts"][0], w["pts"][-1])) or \
                    any(_poly_dist((s.rect.x1, (s.rect.y0 + s.rect.y1) / 2), w["pts"]) < 3 or _poly_dist((s.rect.x0, (s.rect.y0 + s.rect.y1) / 2), w["pts"]) < 3 for s in c["stubs"]):
                h = w["lab"][0]["harness"]
                if h:
                    return h
        return "*opt*"

    def _merge_han(self, T):
        """한자가 섞인 같은 줄의 인접 스팬('12V' + '蓄电池' 등)을 한 글자열로 합친다 (삭제/정리를 쉽게 하기 위함)."""
        from model import RE_HAN
        line = {}
        for t in T:
            if t.rot in (0, 360):
                line.setdefault(round(t.oy / 1.0), []).append(t)
        merged_ids, out_new = set(), []
        for key, ts in line.items():
            ts = sorted(ts, key=lambda t: t.ox)
            chain = [ts[0]]
            def flush(ch):
                if len(ch) > 1 and any(RE_HAN.search(x.s) for x in ch):
                    first = ch[0]
                    s = "".join(x.s for x in ch)
                    x1 = max(x.ox + x.len for x in ch)
                    bb = (min(x.bbox[0] for x in ch), min(x.bbox[1] for x in ch), max(x.bbox[2] for x in ch), max(x.bbox[3] for x in ch))
                    nt = type(first)(s, first.ox, first.oy, first.rot, first.font, first.size, bb, x1 - first.ox)
                    for x in ch:
                        merged_ids.add(id(x))
                    out_new.append(nt)
            for t in ts[1:]:
                prev = chain[-1]
                if abs(t.oy - prev.oy) < 0.8 and -1.0 <= t.ox - (prev.ox + prev.len) < 2.5 and abs(t.size - prev.size) < 0.6:
                    chain.append(t)
                else:
                    flush(chain); chain = [t]
            flush(chain)
        # 같은 위치의 중복 스팬 제거 후 병합 결과 추가
        return [t for t in T if id(t) not in merged_ids] + out_new

    def _ex(self, g, o):
        """편입된 글자/도형을 그룹에 추가."""
        for d in o.get("ld", []):
            g.prims += self.drawing_prims(d)
        for t in o.get("lt", []):
            g.prims.append(self.ttext(t))

    # ------------------------------------------------------------------ 분류
    def run(self):
        P = self.P
        D = self.D
        T = self.T
        used_d, used_t = set(), set()

        # 1) 부품 사각형
        comps = []
        for i, d in enumerate(D):
            if d.type == "s" and not d.fill and d.rect.width >= 25 and d.rect.height >= 15 and (
                    d.kinds <= {"qu", "re"} or d.kinds == {"l", "re"}) and d.w <= 1.5:
                comps.append({"rect": d.rect, "i": i, "stubs": [], "inner": [], "texts": []})
                used_d.add(i)
        # 2) 핀 막대 / 내부 도형
        for i, d in enumerate(D):
            if i in used_d:
                continue
            for c in comps:
                r = c["rect"]
                big = P.pymupdf.Rect(r.x0 - 1.5, r.y0 - 1.5, r.x1 + 1.5, r.y1 + 1.5)
                if d.pts and d.w >= 2.5 and big.intersects(d.rect):
                    c["stubs"].append(d); used_d.add(i); break
                if d.rect.x0 >= r.x0 - 0.5 and d.rect.x1 <= r.x1 + 0.5 and d.rect.y0 >= r.y0 - 0.5 and d.rect.y1 <= r.y1 + 0.5:
                    c["inner"].append(d); used_d.add(i); break

        # 3) 스플라이스(검은 원), 꼬임(노란), inline(흰 사각형)
        sps, twists, inls = [], [], []
        for i, d in enumerate(D):
            if i in used_d:
                continue
            if d.type == "fs" and "c" in d.kinds and d.rect.width < 8 and d.fill and sum(d.fill) < 0.3:
                c = ((d.rect.x0 + d.rect.x1) / 2, (d.rect.y0 + d.rect.y1) / 2)
                if not any(math.dist(c, s["c"]) < 1.5 for s in sps):
                    sps.append({"c": c})
                used_d.add(i)
            elif d.color == (1, 1, 0) and d.type == "s":
                twists.append({"d": d}); used_d.add(i)
        for i, d in enumerate(D):
            if i in used_d:
                continue
            if d.type == "f" and "re" in d.kinds and d.rect.width < 30 and d.rect.height < 14 and d.fill and sum(d.fill) > 2.9:
                inls.append({"rect": d.rect, "ds": [d]}); used_d.add(i)
        for i, d in enumerate(D):
            if i in used_d:
                continue
            for n in inls:
                r = n["rect"]
                if d.rect.x0 >= r.x0 - 1 and d.rect.x1 <= r.x1 + 1 and d.rect.y0 >= r.y0 - 1 and d.rect.y1 <= r.y1 + 1:
                    n["ds"].append(d); used_d.add(i); break

        # 4) 선 = wire
        wires = []
        for i, d in enumerate(D):
            if i in used_d:
                continue
            if d.pts and len(d.pts) >= 2 and d.w <= 1.5 and not d.fill and d.color == (0, 0, 0):
                L = sum(math.dist(a, b) for a, b in zip(d.pts, d.pts[1:]))
                if L >= 6:
                    wires.append({"pts": d.pts, "d": d, "lab": [], "extra": [], "sp": []}); used_d.add(i)

        # 5) 텍스트: 라벨 / 부품 / 기타
        lab1 = [t for t in T if is_label1(t.s)]
        for t in lab1:
            used_t.add(id(t))
            l2 = None; l2d = 1e9
            for u in T:
                if id(u) in used_t:
                    continue
                m = RE_L2.match(u.s)
                if m and 2 <= u.oy - t.oy <= 12 and abs(u.ox - t.ox) < 30:
                    dd = abs(u.ox - t.ox) + (u.oy - t.oy)
                    if dd < l2d:
                        l2, l2d = u, dd
            if l2:
                used_t.add(id(l2))
            p = t.s.split()
            ref = p[0]
            cable = p[1] if len(p) > 1 else ""
            color = p[2] if len(p) > 2 else ""
            area = cable.split("_", 1)[1] if "_" in cable else ""
            harness, option = "", ""
            if l2:
                m = RE_L2.match(l2.s); harness, option = m.group(1), m.group(2).strip()
            best, bd = None, 1e9
            mid = (t.ox + 20, t.oy + 1)
            for w in wires:
                dd = _poly_dist(mid, w["pts"])
                if dd < bd:
                    best, bd = w, dd
            info = dict(ref=ref, cable=cable, color=color, area=area, harness=harness, option=option, t=t, l2t=l2)
            if best is not None and bd < 12:
                best["lab"].append(info)
            else:
                self.warn.append("라벨 '%s' 에 해당하는 선을 찾지 못했습니다." % t.s)
                used_t.discard(id(t))

        # 6) 스플라이스 라벨, 꼬임 라벨, inline 텍스트
        for s in sps:
            c = s["c"]; best, bd = None, 25
            for t in T:
                if id(t) not in used_t and RE_SP.match(t.s):
                    dd = math.hypot(t.ox + t.len / 2 - c[0], t.oy - c[1])
                    if dd < bd:
                        best, bd = t, dd
            s["t"] = best
            if best:
                used_t.add(id(best))
        for tw in twists:
            r = tw["d"].rect; c = ((r.x0 + r.x1) / 2, r.y0); best, bd = None, 15
            for t in T:
                if id(t) not in used_t and RE_TWIST.match(t.s):
                    dd = math.hypot(t.ox + t.len / 2 - c[0], t.oy - c[1])
                    if dd < bd:
                        best, bd = t, dd
            tw["t"] = best
            if best:
                used_t.add(id(best))
        for n in inls:
            r = n["rect"]; cx = (r.x0 + r.x1) / 2; cy = (r.y0 + r.y1) / 2
            near = [t for t in T if id(t) not in used_t and abs(t.ox + t.len / 2 - cx) < 45 and abs(t.oy - cy) < 11 and t.size <= 3.1]
            ref = pin = None
            for t in near:
                m = RE_INL.match(t.s)
                if m:
                    ref = m.group(1)
                elif re.fullmatch(r"\d{1,3}", t.s):
                    pin = t.s
            n["ref"] = (ref + (":" + pin if pin else "")) if ref else ""
            n["xt"] = []
            for t in near:
                if RE_INL.match(t.s):
                    n["xt"].append(t)                       # 94/305_BD 같은 하네스 구분 글자는 inline 그룹에 그대로 보존
                if RE_INL.match(t.s) or re.fullmatch(r"\d{1,3}", t.s):
                    used_t.add(id(t))

        # 7) 부품에 글자 배정
        for t in T:
            if id(t) in used_t:
                continue
            best, bd = None, 1e9
            for c in comps:
                r = c["rect"]
                dx = max(r.x0 - t.ox, 0, t.ox - r.x1)
                if t.oy < r.y0:
                    dy = r.y0 - t.oy; lim = 40
                else:
                    dy = max(0, t.oy - r.y1); lim = 25
                if dx <= 32 and dy <= lim:
                    dd = dx + dy
                    if dd < bd:
                        best, bd = c, dd
            if best is not None:
                best["texts"].append(t); used_t.add(id(t))
        refs = []
        for t in T:
            if id(t) in used_t or not RE_XREF.match(t.s):
                continue
            cy = t.oy - t.size * 0.3
            arr = []
            for i, d in enumerate(D):
                if i in used_d or d.color != (0, 1, 1):
                    continue
                if d.rect.x1 <= t.ox + 2 and d.rect.x0 >= t.ox - 25 and abs((d.rect.y0 + d.rect.y1) / 2 - cy) < 8:
                    arr.append(d); used_d.add(i)
            refs.append({"t": t, "arr": arr}); used_t.add(id(t))
        # 8) 분류되지 않은 글자/도형 -> 가장 가까운 기존 id(부품/inline/reference/splice/wire)에 편입
        def rdist(r, x, y):
            return math.hypot(max(r.x0 - x, 0, x - r.x1), max(r.y0 - y, 0, y - r.y1))
        owners = []
        for c in comps:
            c["lt"], c["ld"] = [], []
            owners.append((c, 0.0, lambda x, y, c=c: rdist(c["rect"], x, y)))
        for n in inls:
            n["lt"], n["ld"] = [], []
            owners.append((n, 0.0, lambda x, y, n=n: rdist(n["rect"], x, y)))
        for rf in refs:
            rf["lt"], rf["ld"] = [], []
            def rfd(x, y, rf=rf):
                t = rf["t"]; m = math.hypot(t.ox + t.len / 2 - x, t.oy - y)
                for a in rf["arr"]:
                    m = min(m, rdist(a.rect, x, y))
                return m
            owners.append((rf, 0.0, rfd))
        for s in sps:
            s["lt"], s["ld"] = [], []
            owners.append((s, 0.0, lambda x, y, s=s: math.hypot(s["c"][0] - x, s["c"][1] - y)))
        for w in wires:
            w["lt"], w["ld"] = [], []
            owners.append((w, 4.0, lambda x, y, w=w: _poly_dist((x, y), w["pts"])))

        def nearest(x, y, lim):
            best, bd = None, lim
            for o, pen, fn in owners:
                dd = fn(x, y) + pen
                if dd < bd:
                    best, bd = o, dd
            return best
        for t in T:
            if id(t) in used_t:
                continue
            o = nearest(t.ox + t.len / 2, t.oy - t.size * 0.3, 40)
            if o is not None:
                if "pts" in o and RE_L2.match(t.s):        # 'BD ALL' 같은 하네스/옵션 글자 -> wire meta 로 흡수(화면 표시 안 함)
                    o.setdefault("l2x", []).append(t)
                else:
                    o["lt"].append(t)
                used_t.add(id(t))
        for i, d in enumerate(D):
            if i in used_d:
                continue
            o = nearest((d.rect.x0 + d.rect.x1) / 2, (d.rect.y0 + d.rect.y1) / 2, 22)
            if o is not None:
                o["ld"].append(d); used_d.add(i)
        leftover_t = [t for t in T if id(t) not in used_t]
        leftover_d = [d for i, d in enumerate(D) if i not in used_d]

        # ---------------------------------------------------------------- 원점/크기
        xs, ys = [], []
        def grow(a, b): xs.append(a); ys.append(b)
        for d in D:
            grow(d.rect.x0, d.rect.y0); grow(d.rect.x1, d.rect.y1)
        for t in T:
            grow(t.bbox[0], t.bbox[1]); grow(t.bbox[2], t.bbox[3])
        if not xs:
            xs, ys = [0, 100], [0, 100]
        S = self.P.S
        self.S = S
        self.ox = min(xs) - 40 * S
        self.oy = min(ys) - 70 * S
        W = (max(xs) - self.ox) / S + 40
        H = (max(ys) - self.oy) / S + 12

        doc = Doc()
        doc.header = ('<?xml version="1.0" encoding="UTF-8"?>\r\n'
                      '<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.0//EN" "http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd">\r\n'
                      '<!--Created with PDF2WD converter-->\r\n'
                      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %s %s">' % (fmt(W), fmt(H)))
        doc.viewbox = [0, 0, round(W, 2), round(H, 2)]
        doc.title = self.sheet
        bg = Group(gid=2, cls="rectangle", has_meta_block=False)
        bg.prims.append(Prim("rect", {"x": "-0.15", "y": "-0.0345", "width": fmt(W - 0.2325), "height": fmt(H - 0.3765), "stroke": "#ffffff", "fill": "#ffffff", "stroke-width": "0.75"}))
        gr = Group(gid=3, cls="xygrid", has_meta_block=False)
        gr.prims.append(Prim("rect", {"x": "-0.15", "y": "-0.0345", "width": fmt(W - 0.2325), "height": fmt(H - 0.3765), "stroke": "none", "fill": "none", "stroke-width": "0.75"}))
        doc.add(bg); doc.add(gr)
        gid = [4]
        def nid():
            gid[0] += 1
            return gid[0]

        # 시트 이름
        if self.sheet:
            g = Group(gid=nid(), cls="text")
            g.meta = [("type", "textvar {Sheet Name}", True), ("tag", self.tag("gr_"), True)]
            tt = getattr(self.imp, "title_t", None)
            L = (tt.len / self.S) if tt is not None and tt.len else len(self.sheet) * 40.4662 * 0.55
            g.prims.append(Prim("text", {"x": fmt(W - L - 20), "y": "33.8645", "text-anchor": "start", "fill": STROKE,
                                         "transform": "rotate(0,%s,33.8645)" % fmt(W - L - 20), "textLength": fmt(L),
                                         "font-family": "OF Helvetica", "font-size": "40.4662"}, self.sheet))
            doc.add(g)

        # 부품
        stats = {"wire": len(wires), "wire_labeled": sum(1 for w in wires if w["lab"]), "component": len(comps), "inline": len(inls),
                 "reference": 0, "sp": len(sps), "twist": len(twists), "unshielded": 0}
        for c in comps:
            r = c["rect"]
            hdr = [t for t in c["texts"] if RE_COMP_HDR.match(t.s) and t.size >= 4.5]
            ref = desc = ""
            if hdr:
                h = min(hdr, key=lambda t: abs(t.oy - (r.y0 - 10)))
                m = RE_COMP_HDR.match(h.s); ref, desc = m.group(1), m.group(2)
            else:                                   # 퓨즈 등 'n/n 설명' 머리글이 없는 부품
                above = sorted([t for t in c["texts"] if t.oy < r.y0 and t.size >= 4.5], key=lambda t: (t.oy, t.ox))
                desc = " ".join(t.s for t in above)
            g = Group(gid=nid(), cls="symbol")
            m = re.match(r"(\d+)/(\d+)", ref)
            pre = "_%02d_%03d_" % (int(m.group(1)), int(m.group(2))) if m else "_"
            g.meta = [("type", "component", True),
                      ("tag", self.tag(pre + re.sub(r"[^A-Za-z0-9]+", "_", desc).strip("_") + "_" + VARIANT + "_"), True),
                      ("ref", ref, True), ("description", desc, True), ("harness", self._comp_harness(c, wires), True), ("variant", "*opt*", True)]
            x0, y0 = self.pt((r.x0, r.y0))
            g.prims.append(Prim("rect", {"x": fmt(x0), "y": fmt(y0), "width": fmt(r.width / self.S), "height": fmt(r.height / self.S),
                                         "stroke": STROKE, "fill": "none", "stroke-width": "3"}))
            for d in c["inner"] + c["stubs"]:
                g.prims += self.drawing_prims(d)
            for t in sorted(c["texts"], key=lambda t: (t.oy, t.ox)):
                g.prims.append(self.ttext(t))
            self._ex(g, c)
            doc.add(g)

        # reference connector (다른 시트로 이어지는 화살표 + 'sheet:SPxxx' 글자)
        for rf in refs:
            t = rf["t"]
            g = Group(gid=nid(), cls="symbol")
            g.meta = [("type", "reference_connector", True), ("tag", self.tag("_reference__"), True)]
            for d in rf["arr"]:
                g.prims += self.drawing_prims(d)
            g.prims.append(self.ttext(t))
            self._ex(g, rf)
            doc.add(g)
        stats["reference"] = len(refs)

        # inline
        for n in inls:
            r = n["rect"]; cy = (r.y0 + r.y1) / 2
            g = Group(gid=nid(), cls="symbol")
            g.meta = [("type", "inline_connector", True), ("tag", self.tag("_inline25__"), True), ("ref", n["ref"], True),
                      ("variant", "*opt*", True), ("option", "", True), ("harness", "", False), ("area", "", False),
                      ("signal", "", False), ("color", "", False), ("option_description", "", True)]
            xa, xb = r.x0, r.x1
            L = xb - xa
            mid = (xa + xb) / 2
            g.prims.append(self.path([(xa, cy), (xa + L * 0.35, cy)], 0.75, "butt", "miter"))
            g.prims.append(self.path([(xa + L * 0.54, cy), (xa + L * 0.35, cy)], 0.75, "round", "miter"))
            g.prims.append(self.path([(xa + L * 0.62, cy), (xb, cy)], 0.75, "butt", "miter"))
            ax, ay = self.pt((xa + L * 0.49, cy))
            rr = 3.6456
            g.prims.append(Prim("path", {"d": "M%s,%s A%s,%s 0 1,0, %s,%s " % (fmt(ax), fmt(ay + rr), fmt(rr), fmt(rr), fmt(ax), fmt(ay - rr)),
                                         "stroke": STROKE, "fill": "none", "stroke-width": "0.75"}))
            if n["ref"]:
                tx, ty = self.pt((xb + 2, cy - 4))
                g.prims.append(Prim("text", {"x": fmt(tx), "y": fmt(ty), "text-anchor": "end", "fill": STROKE,
                                             "transform": "rotate(0,%s,%s)" % (fmt(tx), fmt(ty)), "textLength": fmt(len(n["ref"]) * 5.9),
                                             "font-family": "OF Helvetica", "font-size": "12.1398"}, n["ref"]))
            for t in n.get("xt", []):
                g.prims.append(self.ttext(t))
            self._ex(g, n)
            doc.add(g)

        # splice : AR1 규칙 - 별도 id 가 아니라 물리적으로 연결된 wire 그룹 하위에 SP 기호 + 접속점
        import elements as E
        for w in wires:
            w["spp"] = []
        for s in sps:
            cx, cy = self.pt(s["c"])
            touch = [w for w in wires if min(math.dist(w["pts"][0], s["c"]), math.dist(w["pts"][-1], s["c"])) < 2.5]
            if not touch:
                near = min(wires, key=lambda w: _poly_dist(s["c"], w["pts"])) if wires else None
                touch = [near] if near is not None else []
            if not touch:
                continue
            for w in touch:
                for p in (w["pts"][0], w["pts"][-1]):
                    if math.dist(p, s["c"]) < 2.5:
                        dx, dy = self.pt(p); w["spp"].append(E.dot_prim(dx, dy))
            own = touch[0]
            sp = E.sp_prims(cx, cy, "")
            for p in sp:
                p._obst = True
            own["spp"] += sp
            if s.get("t"):
                tp = self.ttext(s["t"]); tp._fixed = True; own["spp"].append(tp)
            for d in s.get("ld", []):
                own["spp"] += self.drawing_prims(d)
            for t in s.get("lt", []):
                own["spp"].append(self.ttext(t))

        # wire (+ 가까운 꼬임)
        for tw in twists:
            r = tw["d"].rect; c = ((r.x0 + r.x1) / 2, (r.y0 + r.y1) / 2)
            best, bd = None, 1e9
            for w in wires:
                dd = _poly_dist(c, w["pts"])
                if dd < bd:
                    best, bd = w, dd
            x0, y0 = self.pt((r.x0, r.y0)); x1, y1 = self.pt((r.x1, r.y1))
            R = (x1 - x0) / 2
            pr = [Prim("path", {"d": "M%s,%s A%s,%s 0 1,0, %s,%s " % (fmt(x1), fmt(y0 + .254), fmt(R), fmt(R), fmt(x0), fmt(y0 + .127)), "stroke": STROKE, "fill": "none", "stroke-width": "0.75"}),
                  Prim("path", {"d": "M%s,%s A%s,%s 0 0,0, %s,%s " % (fmt(x0), fmt(y1 + .127), fmt(R), fmt(R), fmt(x1), fmt(y1 - .127)), "stroke": STROKE, "fill": "none", "stroke-width": "0.75"}),
                  Prim("path", {"d": "M%s,%s L%s,%s", "fill": "none", "stroke": STROKE, "stroke-linecap": "butt", "stroke-linejoin": "miter", "stroke-width": "0.75"}),
                  Prim("path", {"d": "M%s,%s L%s,%s", "fill": "none", "stroke": STROKE, "stroke-linecap": "butt", "stroke-linejoin": "miter", "stroke-width": "0.75"})]
            pr[2].attrs["d"] = "M%s,%s L%s,%s" % (fmt(x0), fmt(y0 + R), fmt(x1), fmt(y1 - R))
            pr[3].attrs["d"] = "M%s,%s L%s,%s" % (fmt(x1), fmt(y0 + R), fmt(x0), fmt(y1 - R))
            if tw.get("t"):
                pr.append(self.ttext(tw["t"]))
            if best is not None and bd < 40:
                best["extra"] += pr
            else:
                leftover_d.append(tw["d"])
        for w in wires:
            g = Group(gid=nid(), cls="wire")
            lab = w["lab"][0] if w["lab"] else None
            if lab:
                ref = lab["ref"]
                m = re.match(r"^(.*\d)([A-Z]+)$", ref)
                g.meta = [("type", "physical_wire", True), ("tag", self.tag("w_"), True), ("ref", ref, True), ("variant", VARIANT, True),
                          ("option", lab["option"], True), ("harness", lab["harness"], False), ("area", lab["area"], False),
                          ("signal", m.group(1) if m else "", False), ("color", lab["color"], False),
                          ("option_description", "STD" if lab["option"] == "ALL" else "", True)]
            else:
                g.meta = [("type", "physical_wire", True), ("tag", self.tag("w_"), True), ("ref", "", True), ("variant", VARIANT, True),
                          ("option", "", True), ("harness", "", False), ("area", "", False), ("signal", "", False), ("color", "", False),
                          ("option_description", "", True)]
            if lab and w.get("l2x") and not lab["harness"]:
                m2 = RE_L2.match(w["l2x"][0].s)
                g.set("harness", m2.group(1), False); g.set("option", m2.group(2).strip(), True)
                g.set("option_description", "STD" if m2.group(2).strip() == "ALL" else "", True)
            g.prims.append(self.path(w["pts"]))
            for lb in w["lab"]:                       # PDF 와 같은 표시: 1행 'ref 케이블 색상' / 2행 '하네스 옵션'
                p1 = self.ttext(lb["t"]); g.prims.append(p1)
                if lb.get("l2t") is not None:
                    p2 = self.ttext(lb["l2t"]); g.prims.append(p2)
                    p1._follow = p2; p2._is_follower = True        # 겹침 정리 때 2행 글자는 1행과 함께 이동
            g.prims += w["extra"]
            g.prims += w.get("spp", [])
            self._ex(g, w)
            doc.add(g)

        # 남은 글자 / 도형
        for t in leftover_t:
            g = Group(gid=nid(), cls="text")
            g.meta = [("type", "text", True), ("tag", self.tag("gr_"), True)]
            g.prims.append(self.ttext(t))
            doc.add(g)
        if leftover_d:
            g = Group(gid=nid(), cls="symbol")
            g.meta = [("type", "drawing", True), ("tag", "UNCLASSIFIED_SHAPES", True)]
            for d in leftover_d:
                g.prims += self.drawing_prims(d)
            doc.add(g)
            self.warn.append("분류되지 않은 도형 %d개를 'UNCLASSIFIED_SHAPES' 그룹으로 보존했습니다." % len(leftover_d))
        stats["leftover_text"] = len(leftover_t); stats["leftover_shapes"] = len(leftover_d)
        self.stats = stats
        stats["moved_text"] = self.declutter(doc)
        return doc

    # ------------------------------------------------------------------ 겹치는 글자 정리
    def declutter(self, doc):
        """글자끼리 / 글자와 inline·splice 기호가 겹치면 wire 라벨 -> inline 글자 순으로 옮겨 겹침을 없앤다."""
        def ov(a, b, m=2.5):
            return a[0] < b[2] + m and b[0] < a[2] + m and a[1] < b[3] + m and b[1] < a[3] + m
        fixed, soft1, soft2, obst = [], [], [], []
        for g in doc.groups:
            ty = g.type
            if g.cls == "text" and ty.startswith("textvar"):
                continue
            wb = None
            if g.cls == "wire":
                xs = [q[0] for p in g.prims if p.tag == "path" for q in path_points(p.attrs["d"])]
                wb = (min(xs), max(xs)) if xs else None
            for p in g.prims:
                if p.tag == "text":
                    if not p.text:
                        continue
                    bb = p.bbox()
                    if getattr(p, "_is_follower", False):
                        continue
                    if getattr(p, "_fixed", False):
                        fixed.append([p, bb, None]); continue
                    f = getattr(p, "_follow", None)
                    if f is not None:
                        b2 = f.bbox(); bb = (min(bb[0], b2[0]), min(bb[1], b2[1]), max(bb[2], b2[2]), max(bb[3], b2[3]))
                    if g.cls == "wire":
                        soft2.append([p, bb, wb])
                    elif ty == "inline_connector":
                        soft1.append([p, bb, None])
                    else:
                        fixed.append([p, bb, None])
                elif ty in ("inline_connector", "physical_splice_connector") or getattr(p, "_obst", False):
                    bb = p.bbox()
                    if bb:
                        obst.append(bb)
        placed = [e[1] for e in fixed] + obst
        moved = 0
        for lst, horiz in ((soft1, False), (soft2, True)):
            for e in lst:
                p, bb, wb = e
                w = bb[2] - bb[0]; h = bb[3] - bb[1]
                if not any(ov(bb, o) for o in placed):
                    placed.append(bb); continue
                cands = []
                for i in range(1, 90):
                    s = 3.0 * i
                    cands += [(s, 0), (-s, 0)] if horiz else [(0, -s), (0, s)]
                if not horiz:
                    for i in range(1, 60):
                        s = 4.0 * i; cands += [(s, 0), (-s, 0)]
                else:
                    for i in range(1, 8):
                        s = h * 0.9 * i; cands += [(0, -s), (0, s)]
                best = None
                for dx, dy in cands:
                    nb = (bb[0] + dx, bb[1] + dy, bb[2] + dx, bb[3] + dy)
                    if wb is not None and horiz and dy == 0 and (nb[0] < wb[0] - 2 or nb[2] > wb[1] + 2):
                        continue
                    if not any(ov(nb, o) for o in placed):
                        best = (dx, dy, nb); break
                if best:
                    p.translate(best[0], best[1]); placed.append(best[2]); moved += 1
                    if getattr(p, "_follow", None) is not None:
                        p._follow.translate(best[0], best[1])
                else:
                    placed.append(bb)
        for g in doc.groups:
            g.dirty()
        return moved


def build(imp):
    k = KX(imp)
    doc = k.run()
    imp.warn += k.warn
    imp.stats = k.stats
    imp.kx = True
    return doc


def looks_like_kx(texts):
    n1 = sum(1 for t in texts if is_label1(t.s))
    return n1 >= 2
