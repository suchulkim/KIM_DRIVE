"""PDF / SVG 내보내기."""
import pymupdf
from model import Doc


def export_svg(doc: Doc, path: str):
    doc.save(path)


def export_pdf(doc: Doc, path: str):
    """SVG(AIM) -> PDF. 벡터와 텍스트를 유지한다."""
    data = doc.to_xml().encode("utf-8")
    svg = pymupdf.open(stream=data, filetype="svg")
    pdf_bytes = svg.convert_to_pdf()
    with open(path, "wb") as f:
        f.write(pdf_bytes)


def load_any(path: str):
    """(Doc, importer|None, warnings) 반환."""
    p = path.lower()
    if p.endswith(".pdf"):
        from pdfimport import import_pdf
        doc, imp = import_pdf(path)
        doc.path = None
        try:
            import i18n
            auto = i18n.get_setting("strip_cjk", True)
        except Exception:
            auto = True
        if auto:
            from model import strip_cjk
            n = strip_cjk(doc)
            if n:
                imp.warn.append("중국어 글자 %d개를 삭제했습니다. (설정 > PDF 변환 시 중국어 자동 삭제)" % n)
        return doc, imp
    doc = Doc.load(path)
    import optionmap
    optionmap.learn(doc)          # 열린 AIM SVG 에서 option 설명 사전 학습
    return doc, None
