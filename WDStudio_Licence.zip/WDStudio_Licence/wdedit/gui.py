"""WD Studio GUI (PyQt6)."""
from __future__ import annotations
import html as _html
import math
import os
import re
import sys

from PyQt6.QtGui import QDesktopServices
from PyQt6.QtCore import Qt, QDir, QFile, QMimeData, QByteArray, QModelIndex, QThread, QPointF, QRectF, QSize, QTimer, QUrl, pyqtSignal
from PyQt6.QtGui import (QPolygonF, QFileSystemModel, QAction, QActionGroup, QBrush, QColor, QFont, QFontMetricsF, QKeySequence, QPainter, QPainterPath,
                         QPainterPathStroker, QPen, QTextDocument, QTransform, QFontDatabase, QPixmap)
from PyQt6.QtWidgets import (QColorDialog, QComboBox, QDoubleSpinBox, QSpinBox, QAbstractItemView, QApplication, QCheckBox, QTabBar, QTreeView, QProgressBar, QDialog, QDialogButtonBox, QDockWidget, QFileDialog,
                             QFormLayout, QInputDialog, QGraphicsEllipseItem, QGraphicsItem, QGraphicsItemGroup, QGraphicsPathItem,
                             QGraphicsPixmapItem, QGraphicsRectItem, QGraphicsScene, QGraphicsSimpleTextItem, QGraphicsView, QHBoxLayout,
                             QHeaderView, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMenu, QMessageBox,
                             QPlainTextEdit, QPushButton, QStyle, QStyledItemDelegate, QTableWidget, QTableWidgetItem,
                             QTabWidget, QToolBar, QToolButton, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

import elements as E
import i18n
import rules
from export import export_pdf, export_svg, load_any
from i18n import tr
from icons import icon
from model import Doc, Group, Prim, fmt, parse_group_xml, parse_path, path_points, has_xf, local_rect, xf_get
import shapes as SH
from version import APP_NAME, BUILD_DATE, DEVELOPER, VERSION

MONO = "Consolas"


# ============================================================================ 그리기 보조
def svg_arc_to_path(path: QPainterPath, x1, y1, rx, ry, phi, fa, fs, x2, y2):
    """SVG 호(endpoint) -> QPainterPath.arcTo (W3C 부록 F.6)."""
    if rx == 0 or ry == 0 or (x1 == x2 and y1 == y2):
        path.lineTo(x2, y2); return
    rx, ry = abs(rx), abs(ry)
    ph = math.radians(phi)
    c, s = math.cos(ph), math.sin(ph)
    dx, dy = (x1 - x2) / 2, (y1 - y2) / 2
    x1p, y1p = c * dx + s * dy, -s * dx + c * dy
    lam = x1p ** 2 / rx ** 2 + y1p ** 2 / ry ** 2
    if lam > 1:
        rx *= math.sqrt(lam); ry *= math.sqrt(lam)
    num = rx ** 2 * ry ** 2 - rx ** 2 * y1p ** 2 - ry ** 2 * x1p ** 2
    den = rx ** 2 * y1p ** 2 + ry ** 2 * x1p ** 2
    co = math.sqrt(max(0, num / den)) if den else 0
    if fa == fs:
        co = -co
    cxp, cyp = co * rx * y1p / ry, -co * ry * x1p / rx
    cx = c * cxp - s * cyp + (x1 + x2) / 2
    cy = s * cxp + c * cyp + (y1 + y2) / 2

    def ang(ux, uy, vx, vy):
        return math.atan2(ux * vy - uy * vx, ux * vx + uy * vy)
    th1 = ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry)
    dth = ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry)
    if not fs and dth > 0:
        dth -= 2 * math.pi
    elif fs and dth < 0:
        dth += 2 * math.pi
    path.arcTo(QRectF(cx - rx, cy - ry, 2 * rx, 2 * ry), -math.degrees(th1), -math.degrees(dth))


def prim_path(p: Prim) -> QPainterPath:
    qp = QPainterPath()
    cx = cy = 0.0
    for cmd, a in parse_path(p.attrs.get("d", "")):
        if cmd == "M":
            qp.moveTo(a[0], a[1]); cx, cy = a[0], a[1]
        elif cmd == "L":
            qp.lineTo(a[0], a[1]); cx, cy = a[0], a[1]
        elif cmd == "H":
            qp.lineTo(a[0], cy); cx = a[0]
        elif cmd == "V":
            qp.lineTo(cx, a[0]); cy = a[0]
        elif cmd == "C":
            qp.cubicTo(a[0], a[1], a[2], a[3], a[4], a[5]); cx, cy = a[4], a[5]
        elif cmd == "A":
            svg_arc_to_path(qp, cx, cy, a[0], a[1], a[2], int(a[3]), int(a[4]), a[5], a[6]); cx, cy = a[5], a[6]
        elif cmd == "Z":
            qp.closeSubpath()
    return qp


def col(s, default="#000000"):
    return QColor(default if s in (None, "none") else s)


def _f(a, k, d=0.0):
    try:
        return float(a.get(k, d))
    except Exception:
        return d


_PM_CACHE = {}


def _obj_qxf(p):
    """그림/도형의 회전·대칭 transform -> QTransform (없으면 None)."""
    if not has_xf(p):
        return None
    r = local_rect(p)
    if r is None:
        return None
    a, sx, sy = xf_get(p); cx, cy = r[0] + r[2] / 2, r[1] + r[3] / 2
    t = QTransform(); t.translate(cx, cy); t.rotate(a); t.scale(sx, sy); t.translate(-cx, -cy)
    return t


class GroupItem(QGraphicsItemGroup):
    def __init__(self, grp: Group, window):
        super().__init__()
        self.grp = grp
        self.win = window
        self.prim_items = []
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, True)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, True)
        for p in self.grp.prims:
            it = self._prim_item(p)
            self.prim_items.append(it)
            if it is not None:
                self.addToGroup(it)

    def _prim_item(self, p: Prim):
        a = p.attrs
        try:
            pen = QPen(col(a.get("stroke"), "#000000"), _f(a, "stroke-width", 0.75))
            pen.setCapStyle(Qt.PenCapStyle.RoundCap if a.get("stroke-linecap") == "round" else Qt.PenCapStyle.FlatCap)
            pen.setJoinStyle(Qt.PenJoinStyle.MiterJoin if a.get("stroke-linejoin") == "miter" else Qt.PenJoinStyle.RoundJoin)
            if a.get("stroke-dasharray"):
                sw_ = _f(a, "stroke-width", 0.75) or 0.75
                dv = [float(v) / sw_ for v in re.split(r"[ ,]+", a["stroke-dasharray"].strip()) if v]
                if dv:
                    pen.setDashPattern(dv if len(dv) % 2 == 0 else dv * 2)
            brush = QBrush(col(a["fill"])) if a.get("fill") not in (None, "none") else QBrush(Qt.BrushStyle.NoBrush)
            if a.get("stroke") in (None, "none"):
                pen = QPen(Qt.PenStyle.NoPen)
            if p.tag == "path":
                it = QGraphicsPathItem(prim_path(p))
            elif p.tag == "rect":
                it = QGraphicsRectItem(_f(a, "x"), _f(a, "y"), _f(a, "width"), _f(a, "height"))
            elif p.tag == "image":
                import base64
                href = a.get("xlink:href", "") or a.get("href", "")
                pm = _PM_CACHE.get(hash(href))
                if pm is None:
                    pm = QPixmap()
                    if "base64," in href:
                        pm.loadFromData(base64.b64decode(href.split("base64,", 1)[1]))
                    if len(_PM_CACHE) > 24:
                        _PM_CACHE.clear()
                    _PM_CACHE[hash(href)] = pm
                if pm.isNull():
                    return None
                w_, h_ = _f(a, "width"), _f(a, "height")
                it = QGraphicsPixmapItem(pm.scaled(max(1, int(w_ * 2)), max(1, int(h_ * 2)), Qt.AspectRatioMode.IgnoreAspectRatio,
                                                   Qt.TransformationMode.SmoothTransformation))
                it.setTransformationMode(Qt.TransformationMode.SmoothTransformation)
                base = QTransform().translate(_f(a, "x"), _f(a, "y")).scale(0.5, 0.5)
                xf = _obj_qxf(p)
                it.setTransform(base * xf if xf is not None else base)
                if a.get("opacity"):
                    it.setOpacity(max(0.0, min(1.0, float(a["opacity"]))))
                return it
            elif p.tag == "ellipse":
                cx, cy, rx, ry = (_f(a, k) for k in ("cx", "cy", "rx", "ry"))
                it = QGraphicsEllipseItem(cx - rx, cy - ry, 2 * rx, 2 * ry)
            elif p.tag == "text":
                it = QGraphicsSimpleTextItem(p.text)
                f = QFont(a.get("font-family", "Helvetica"))
                f.setStyleHint(QFont.StyleHint.SansSerif)
                f.setPixelSize(max(1, int(round(_f(a, "font-size", 8)))))
                it.setFont(f)
                it.setBrush(QBrush(col(a.get("fill"))))
                it.setPen(QPen(Qt.PenStyle.NoPen))
                fm = QFontMetricsF(f)
                nat = max(1.0, fm.horizontalAdvance(p.text))
                L = _f(a, "textLength", nat) or nat
                m = re.match(r"rotate\(([-\d.]+),", a.get("transform", ""))
                ang = float(m.group(1)) if m else 0
                tr_ = QTransform().translate(_f(a, "x"), _f(a, "y")).rotate(ang).scale(L / nat, 1)
                tr_.translate(-nat if a.get("text-anchor") == "end" else 0, -fm.ascent())
                it.setTransform(tr_)
                return it
            else:
                return None
            it.setPen(pen)
            it.setBrush(brush)
            xf = _obj_qxf(p)
            if xf is not None:
                it.setTransform(xf)
            if a.get("opacity"):
                it.setOpacity(max(0.0, min(1.0, float(a["opacity"]))))
            return it
        except Exception:
            return None

    def shape(self):
        path = QPainterPath()
        st = QPainterPathStroker()
        st.setWidth(6)
        for ch in self.childItems():
            if isinstance(ch, QGraphicsSimpleTextItem):
                path.addRect(ch.mapToParent(ch.boundingRect()).boundingRect())
            elif isinstance(ch, QGraphicsPathItem):
                path.addPath(st.createStroke(ch.mapToParent(ch.path())))
            elif isinstance(ch, QGraphicsRectItem):
                rp = QPainterPath(); rp.addRect(ch.rect())
                path.addPath(st.createStroke(ch.mapToParent(rp)))
            else:
                path.addRect(ch.mapToParent(ch.boundingRect()).boundingRect())
        return path

    def prim_at(self, scene_pos):
        """scene 좌표 아래의 prim 번호(없으면 -1). 위에 그려진 것(뒤쪽 prim)부터 검사."""
        st = QPainterPathStroker(); st.setWidth(5)
        for k in range(len(self.prim_items) - 1, -1, -1):
            it = self.prim_items[k]
            if it is None:
                continue
            lp = it.mapFromScene(scene_pos)
            pa = self.grp.prims[k].attrs
            if "data-shape" in pa and pa.get("fill", "none") != "none" and isinstance(it, (QGraphicsPathItem, QGraphicsRectItem, QGraphicsEllipseItem)):
                if it.shape().contains(lp):                       # 채워진 도형: 안쪽 클릭으로도 선택
                    return k
            if isinstance(it, QGraphicsSimpleTextItem):
                if it.boundingRect().adjusted(-1, -1, 1, 1).contains(lp):
                    return k
            elif isinstance(it, QGraphicsPathItem):
                if st.createStroke(it.path()).contains(lp):
                    return k
            elif isinstance(it, QGraphicsRectItem):
                rp = QPainterPath(); rp.addRect(it.rect())
                if st.createStroke(rp).contains(lp):
                    return k
            elif it.boundingRect().adjusted(-2, -2, 2, 2).contains(lp):
                return k
        return -1

    def mousePressEvent(self, ev):
        """prim(글자/선 등)을 따로 선택해 둔 상태에서 그 prim 을 끌면 선택한 prim 만 이동 (id 전체 이동 X)."""
        self._pd = None
        if ev.button() == Qt.MouseButton.LeftButton and self.win.tool == "select":
            sel = [k for gid, k in self.win.sel_prims if gid == self.grp.gid]
            if sel and self.prim_at(ev.scenePos()) in sel:
                self._pd = (ev.scenePos(), sel, self.flags())
                self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, False)
                ev.accept(); return
        super().mousePressEvent(ev)

    def mouseMoveEvent(self, ev):
        pd = getattr(self, "_pd", None)
        if pd:
            d = ev.scenePos() - pd[0]
            for k in pd[1]:
                if k < len(self.prim_items) and self.prim_items[k] is not None:
                    self.prim_items[k].setPos(d)
            self.win.refresh_overlays(); ev.accept(); return
        super().mouseMoveEvent(ev)
        self.win.refresh_overlays()

    def mouseReleaseEvent(self, ev):
        pd = getattr(self, "_pd", None)
        if pd:
            self._pd = None
            d = ev.scenePos() - pd[0]
            self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, True)
            for k in pd[1]:
                if k < len(self.prim_items) and self.prim_items[k] is not None:
                    self.prim_items[k].setPos(0, 0)
            if abs(d.x()) > 1e-6 or abs(d.y()) > 1e-6:
                gid, ks = self.grp.gid, list(pd[1])
                QTimer.singleShot(0, lambda: self.win.move_prims(gid, ks, d.x(), d.y()))
            ev.accept(); return
        super().mouseReleaseEvent(ev)
        if abs(self.pos().x()) > 1e-6 or abs(self.pos().y()) > 1e-6:
            QTimer.singleShot(0, self.win.move_selected)


class PageHandle(QGraphicsRectItem):
    """캔버스(용지) 크기 조절점 - 모서리 4개 + 변 가운데 4개 (PowerPoint 방식)."""
    CUR = {"nw": Qt.CursorShape.SizeFDiagCursor, "se": Qt.CursorShape.SizeFDiagCursor,
           "ne": Qt.CursorShape.SizeBDiagCursor, "sw": Qt.CursorShape.SizeBDiagCursor,
           "n": Qt.CursorShape.SizeVerCursor, "s": Qt.CursorShape.SizeVerCursor,
           "e": Qt.CursorShape.SizeHorCursor, "w": Qt.CursorShape.SizeHorCursor}

    def __init__(self, win, kind):
        super().__init__(-5, -5, 10, 10)
        self.win, self.kind = win, kind
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations, True)
        self.setBrush(QBrush(QColor("white"))); pen = QPen(QColor("#1a73e8"), 1.5); pen.setCosmetic(True); self.setPen(pen)
        self.setCursor(self.CUR[kind]); self.setZValue(3000); self.setAcceptHoverEvents(True)
        self.setAcceptedMouseButtons(Qt.MouseButton.LeftButton)

    def mousePressEvent(self, ev):
        self.win.canvas_drag_start(self.kind); ev.accept()

    def mouseMoveEvent(self, ev):
        self.win.canvas_drag_move(ev.scenePos()); ev.accept()

    def mouseReleaseEvent(self, ev):
        p = ev.scenePos(); ev.accept()
        QTimer.singleShot(0, lambda: self.win.canvas_drag_end(p))


class TextHandle(QGraphicsRectItem):
    """선택한 글자(text)의 길이/글자 크기 조절점.  e = 길이(textLength), s = 글자 크기, se = 비율 유지."""
    CUR = {"e": Qt.CursorShape.SizeHorCursor, "s": Qt.CursorShape.SizeVerCursor, "se": Qt.CursorShape.SizeFDiagCursor}

    def __init__(self, win, kind):
        super().__init__(-5, -5, 10, 10)
        self.win, self.kind = win, kind
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations, True)
        self.setBrush(QBrush(QColor("#ff9800"))); pen = QPen(QColor("white"), 1.5); pen.setCosmetic(True); self.setPen(pen)
        self.setCursor(self.CUR[kind]); self.setZValue(3100); self.setAcceptedMouseButtons(Qt.MouseButton.LeftButton)

    def mousePressEvent(self, ev):
        self.win.text_drag_start(self.kind, ev.scenePos()); ev.accept()

    def mouseMoveEvent(self, ev):
        self.win.text_drag_move(ev.scenePos()); ev.accept()

    def mouseReleaseEvent(self, ev):
        p = ev.scenePos(); ev.accept()
        QTimer.singleShot(0, lambda: self.win.text_drag_end(p))


class ObjHandle(QGraphicsRectItem):
    """그림/도형 크기 조절(8방향) 및 회전(rot) 핸들."""
    CUR = {"n": Qt.CursorShape.SizeVerCursor, "s": Qt.CursorShape.SizeVerCursor, "e": Qt.CursorShape.SizeHorCursor, "w": Qt.CursorShape.SizeHorCursor,
           "ne": Qt.CursorShape.SizeBDiagCursor, "sw": Qt.CursorShape.SizeBDiagCursor, "nw": Qt.CursorShape.SizeFDiagCursor,
           "se": Qt.CursorShape.SizeFDiagCursor, "rot": Qt.CursorShape.PointingHandCursor}

    def __init__(self, win, kind):
        super().__init__(-5, -5, 10, 10)
        self.win, self.kind = win, kind
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations, True)
        pen = QPen(QColor("#1a73e8") if kind != "rot" else QColor("#2e8b57"), 1.5); pen.setCosmetic(True); self.setPen(pen)
        self.setBrush(QBrush(QColor("white") if kind != "rot" else QColor("#c8f0d8")))
        self.setCursor(self.CUR[kind]); self.setZValue(3100); self.setAcceptedMouseButtons(Qt.MouseButton.LeftButton)

    def paint(self, painter, option, widget=None):
        painter.setPen(self.pen()); painter.setBrush(self.brush())
        if self.kind == "rot":
            painter.drawEllipse(self.rect())
        else:
            painter.drawRect(self.rect())

    def mousePressEvent(self, ev):
        self.win.obj_drag_start(self.kind, ev.scenePos()); ev.accept()

    def mouseMoveEvent(self, ev):
        self.win.obj_drag_move(ev.scenePos()); ev.accept()

    def mouseReleaseEvent(self, ev):
        p = ev.scenePos(); ev.accept()
        QTimer.singleShot(0, lambda: self.win.obj_drag_end(p))


def _color_button(color):
    b = QPushButton(); b.setFixedWidth(60); b._color = color

    def paint():
        b.setStyleSheet("background:%s;border:1px solid #666;min-height:18px" % b._color)

    def pick():
        c = QColorDialog.getColor(QColor(b._color), b)
        if c.isValid():
            b._color = c.name(); paint()
    b.clicked.connect(pick); paint()
    return b


class CropPreview(QWidget):
    """그림 미리보기 + 자를 영역을 마우스로 지정 (바깥은 어둡게). 모서리/변을 끌면 크기, 안쪽을 끌면 이동, 바깥에서 끌면 새로 지정."""
    changed = pyqtSignal()

    def __init__(self, pix):
        super().__init__()
        self.pix = pix; self.setMinimumSize(420, 320); self.setMouseTracking(True)
        self.f = [0.0, 0.0, 1.0, 1.0]                    # 남길 영역 (left, top, right, bottom) 비율
        self._mode = None; self._anchor = None

    def _img_rect(self):
        w, h = self.width() - 16, self.height() - 16
        k = min(w / self.pix.width(), h / self.pix.height())
        iw, ih = self.pix.width() * k, self.pix.height() * k
        return QRectF((self.width() - iw) / 2, (self.height() - ih) / 2, iw, ih)

    def _crop_rect(self):
        r = self._img_rect()
        return QRectF(r.x() + self.f[0] * r.width(), r.y() + self.f[1] * r.height(),
                      (self.f[2] - self.f[0]) * r.width(), (self.f[3] - self.f[1]) * r.height())

    def set_f(self, f):
        self.f = list(f); self.update(); self.changed.emit()

    def paintEvent(self, ev):
        p = QPainter(self); r = self._img_rect()
        p.fillRect(self.rect(), QColor("#d8d8d8"))
        p.drawPixmap(r.toRect(), self.pix)
        c = self._crop_rect(); dim = QColor(0, 0, 0, 130)
        for q in (QRectF(r.left(), r.top(), r.width(), c.top() - r.top()), QRectF(r.left(), c.bottom(), r.width(), r.bottom() - c.bottom()),
                  QRectF(r.left(), c.top(), c.left() - r.left(), c.height()), QRectF(c.right(), c.top(), r.right() - c.right(), c.height())):
            p.fillRect(q, dim)
        p.setPen(QPen(QColor("#ffffff"), 1.5)); p.setBrush(Qt.BrushStyle.NoBrush); p.drawRect(c)
        p.setPen(QPen(QColor("#1a73e8"), 1, Qt.PenStyle.DashLine)); p.drawRect(c)
        p.setPen(QPen(QColor("#1a73e8"), 1)); p.setBrush(QColor("#ffffff"))
        for hx, hy in self._handles(c).values():
            p.drawRect(QRectF(hx - 4, hy - 4, 8, 8))

    @staticmethod
    def _handles(c):
        xm, ym = c.center().x(), c.center().y()
        return {"tl": (c.left(), c.top()), "t": (xm, c.top()), "tr": (c.right(), c.top()), "r": (c.right(), ym),
                "br": (c.right(), c.bottom()), "b": (xm, c.bottom()), "bl": (c.left(), c.bottom()), "l": (c.left(), ym)}

    def _hit(self, pt):
        c = self._crop_rect()
        for n, (hx, hy) in self._handles(c).items():
            if abs(pt.x() - hx) <= 7 and abs(pt.y() - hy) <= 7:
                return n
        return "move" if c.contains(pt) else None

    def _to_f(self, pt):
        r = self._img_rect()
        return (min(1, max(0, (pt.x() - r.x()) / r.width())), min(1, max(0, (pt.y() - r.y()) / r.height())))

    def mousePressEvent(self, ev):
        pt = ev.position(); h = self._hit(pt)
        if h is None:
            self._mode = "new"; self._anchor = self._to_f(pt); self.f = [self._anchor[0], self._anchor[1], self._anchor[0], self._anchor[1]]
        else:
            self._mode = h; self._anchor = (self._to_f(pt), list(self.f))

    def mouseMoveEvent(self, ev):
        pt = ev.position()
        if self._mode is None:
            h = self._hit(pt)
            cur = {"tl": Qt.CursorShape.SizeFDiagCursor, "br": Qt.CursorShape.SizeFDiagCursor, "tr": Qt.CursorShape.SizeBDiagCursor,
                   "bl": Qt.CursorShape.SizeBDiagCursor, "t": Qt.CursorShape.SizeVerCursor, "b": Qt.CursorShape.SizeVerCursor,
                   "l": Qt.CursorShape.SizeHorCursor, "r": Qt.CursorShape.SizeHorCursor, "move": Qt.CursorShape.SizeAllCursor}.get(h, Qt.CursorShape.CrossCursor)
            self.setCursor(cur); return
        x, y = self._to_f(pt); m = 0.02
        if self._mode == "new":
            ax, ay = self._anchor; self.f = [min(ax, x), min(ay, y), max(ax, x), max(ay, y)]
        elif self._mode == "move":
            (px, py), f0 = self._anchor; dx, dy = x - px, y - py
            w, h = f0[2] - f0[0], f0[3] - f0[1]
            nx = min(1 - w, max(0, f0[0] + dx)); ny = min(1 - h, max(0, f0[1] + dy))
            self.f = [nx, ny, nx + w, ny + h]
        else:
            f = self.f
            if "l" in self._mode: f[0] = min(x, f[2] - m)
            if "r" in self._mode: f[2] = max(x, f[0] + m)
            if "t" in self._mode: f[1] = min(y, f[3] - m)
            if "b" in self._mode: f[3] = max(y, f[1] + m)
        self.update(); self.changed.emit()

    def mouseReleaseEvent(self, ev):
        if self._mode == "new" and (self.f[2] - self.f[0] < 0.02 or self.f[3] - self.f[1] < 0.02):
            self.f = [0.0, 0.0, 1.0, 1.0]; self.update(); self.changed.emit()
        self._mode = None


class CropDialog(QDialog):
    """그림 자르기: 미리보기에서 영역을 끌거나, 아래 숫자(자를 비율 %)로 지정."""

    def __init__(self, parent, pix):
        super().__init__(parent); self.setWindowTitle(tr("그림 자르기"))
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel(tr("남길 영역을 끌어서 지정하세요. 모서리/변: 크기, 안쪽: 이동, 바깥에서 끌기: 새로 지정")))
        self.prev = CropPreview(pix); lay.addWidget(self.prev, 1)
        self.px, self.py = pix.width(), pix.height()
        row = QHBoxLayout(); self.sp = []
        for name in ("왼쪽", "위쪽", "오른쪽", "아래쪽"):
            row.addWidget(QLabel(tr(name)))
            s = QDoubleSpinBox(); s.setRange(0, 95); s.setDecimals(1); s.setSuffix(" %"); s.setSingleStep(1)
            s.valueChanged.connect(self._from_spin); row.addWidget(s); self.sp.append(s)
        lay.addLayout(row)
        self.info = QLabel(""); lay.addWidget(self.info)
        b0 = QPushButton(tr("초기화")); b0.clicked.connect(lambda: self.prev.set_f([0, 0, 1, 1]))
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        hb = QHBoxLayout(); hb.addWidget(b0); hb.addStretch(1); hb.addWidget(bb); lay.addLayout(hb)
        self.prev.changed.connect(self._to_spin)
        self.resize(640, 560); self._to_spin()

    def _to_spin(self):
        f = self.prev.f; v = (f[0], f[1], 1 - f[2], 1 - f[3])
        for s, x in zip(self.sp, v):
            s.blockSignals(True); s.setValue(round(x * 100, 1)); s.blockSignals(False)
        self.info.setText(tr("남는 크기: %d × %d px") % (max(1, round((f[2] - f[0]) * self.px)), max(1, round((f[3] - f[1]) * self.py))))

    def _from_spin(self):
        l, t, r, b = (s.value() / 100 for s in self.sp)
        if l + r > 0.97: r = 0.97 - l
        if t + b > 0.97: b = 0.97 - t
        self.prev.f = [l, t, 1 - r, 1 - b]; self.prev.update(); self._to_spin()

    def margins(self):
        f = self.prev.f
        return f[0], f[1], 1 - f[2], 1 - f[3]


class ShapeStyleDialog(QDialog):
    """도형 서식: 채우기/선 색, 선 굵기, 선 종류, 투명도."""

    def __init__(self, win, prim):
        super().__init__(win)
        self.setWindowTitle(tr("도형 서식"))
        a = prim.attrs; self.is_img = prim.tag == "image"
        lay = QFormLayout(self)
        fl = a.get("fill", "none"); st = a.get("stroke", "#000000")
        if not self.is_img:
            r1 = QHBoxLayout(); self.c_fill = QCheckBox(tr("채우기")); self.c_fill.setChecked(fl != "none"); self.b_fill = _color_button(fl if fl != "none" else "#ffffff")
            r1.addWidget(self.c_fill); r1.addWidget(self.b_fill); r1.addStretch(1); lay.addRow(r1)
            r2 = QHBoxLayout(); self.c_line = QCheckBox(tr("선")); self.c_line.setChecked(st != "none"); self.b_line = _color_button(st if st != "none" else "#000000")
            r2.addWidget(self.c_line); r2.addWidget(self.b_line); r2.addStretch(1); lay.addRow(r2)
            self.sp_w = QDoubleSpinBox(); self.sp_w.setRange(0.1, 50); self.sp_w.setSingleStep(0.5); self.sp_w.setValue(float(a.get("stroke-width", 1.5)))
            lay.addRow(tr("선 굵기"), self.sp_w)
            self.cb_dash = QComboBox(); self.cb_dash.addItems([tr("실선"), tr("파선"), tr("점선")])
            da = a.get("stroke-dasharray", "")
            self.cb_dash.setCurrentIndex(0 if not da else (2 if float(re.split(r"[ ,]+", da)[0]) <= float(a.get("stroke-width", 1.5)) * 1.2 else 1))
            lay.addRow(tr("선 종류"), self.cb_dash)
        self.sp_op = QSpinBox(); self.sp_op.setRange(0, 100); self.sp_op.setSuffix(" %"); self.sp_op.setValue(int(round(float(a.get("opacity", 1)) * 100)))
        lay.addRow(tr("불투명도"), self.sp_op)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject); lay.addRow(bb)

    def apply(self, prim):
        a = prim.attrs
        if not self.is_img:
            a["fill"] = self.b_fill._color if self.c_fill.isChecked() else "none"
            a["stroke"] = self.b_line._color if self.c_line.isChecked() else "none"
            sw = self.sp_w.value(); a["stroke-width"] = fmt(sw)
            di = self.cb_dash.currentIndex()
            if di == 0:
                a.pop("stroke-dasharray", None)
            elif di == 1:
                a["stroke-dasharray"] = "%s,%s" % (fmt(4 * sw), fmt(2 * sw))
            else:
                a["stroke-dasharray"] = "%s,%s" % (fmt(sw), fmt(2 * sw))
            if a.get("data-shape") == "arrow":
                a["fill"] = a["stroke"]
                SH.regen(prim)
        op = self.sp_op.value()
        if op >= 100:
            a.pop("opacity", None)
        else:
            a["opacity"] = fmt(op / 100.0)

    def style(self):
        return {"stroke": self.b_line._color if self.c_line.isChecked() else "none", "fill": self.b_fill._color if self.c_fill.isChecked() else "none",
                "sw": self.sp_w.value()} if not self.is_img else None


class ObjSizeDialog(QDialog):
    """크기 및 위치(회전·대칭 포함) 숫자 입력."""

    def __init__(self, win, prim):
        super().__init__(win)
        self.setWindowTitle(tr("크기 및 위치"))
        x, y, w, h = local_rect(prim); ang, sx, sy = xf_get(prim)
        lay = QFormLayout(self)
        self.sp = {}
        for key, label, val, lo, hi in (("x", "X", x, -1e5, 1e5), ("y", "Y", y, -1e5, 1e5), ("w", "너비", w, 0, 1e5), ("h", "높이", h, 0, 1e5), ("a", "회전 (°)", ang, -360, 360)):
            s = QDoubleSpinBox(); s.setRange(lo, hi); s.setDecimals(2); s.setSingleStep(1); s.setValue(val); self.sp[key] = s; lay.addRow(tr(label), s)
        self.c_h = QCheckBox(tr("좌우 반전")); self.c_h.setChecked(sx < 0)
        self.c_v = QCheckBox(tr("상하 반전")); self.c_v.setChecked(sy < 0)
        self.c_ar = QCheckBox(tr("가로세로 비율 유지")); self.ratio = (w / h) if h else None
        lay.addRow(self.c_h); lay.addRow(self.c_v); lay.addRow(self.c_ar)
        self.sp["w"].valueChanged.connect(lambda v: self._ar("w"))
        self.sp["h"].valueChanged.connect(lambda v: self._ar("h")); self._busy = False
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject); lay.addRow(bb)

    def _ar(self, src):
        if self._busy or not self.c_ar.isChecked() or not self.ratio:
            return
        self._busy = True
        if src == "w":
            self.sp["h"].setValue(self.sp["w"].value() / self.ratio)
        else:
            self.sp["w"].setValue(self.sp["h"].value() * self.ratio)
        self._busy = False

    def values(self):
        v = {k: s.value() for k, s in self.sp.items()}
        v["sx"] = -1.0 if self.c_h.isChecked() else 1.0; v["sy"] = -1.0 if self.c_v.isChecked() else 1.0
        return v


class TableDialog(QDialog):
    """표 삽입/편집: 행·열 수, 칸 크기, 글자 크기, 머리글 행, 칸 내용."""

    def __init__(self, win, spec=None):
        super().__init__(win)
        self.setWindowTitle(tr("표 편집") if spec else tr("표 삽입")); self.resize(640, 460)
        rows, cols, cw, ch, fs, header, texts = (3, 3, 80.0, 24.0, 10.0, True, []) if spec is None else (spec[0], spec[1], spec[4], spec[5], spec[6], spec[7], spec[8])
        lay = QVBoxLayout(self)
        r = QHBoxLayout()
        self.sp_r = QSpinBox(); self.sp_r.setRange(1, 60); self.sp_r.setValue(rows)
        self.sp_c = QSpinBox(); self.sp_c.setRange(1, 30); self.sp_c.setValue(cols)
        self.sp_cw = QDoubleSpinBox(); self.sp_cw.setRange(5, 2000); self.sp_cw.setValue(cw)
        self.sp_ch = QDoubleSpinBox(); self.sp_ch.setRange(5, 500); self.sp_ch.setValue(ch)
        self.sp_fs = QDoubleSpinBox(); self.sp_fs.setRange(3, 80); self.sp_fs.setValue(fs)
        for lab, w in (("행", self.sp_r), ("열", self.sp_c), ("칸 너비", self.sp_cw), ("칸 높이", self.sp_ch), ("글자 크기", self.sp_fs)):
            r.addWidget(QLabel(tr(lab))); r.addWidget(w)
        lay.addLayout(r)
        self.c_head = QCheckBox(tr("첫 행을 머리글로 (회색 배경)")); self.c_head.setChecked(header); lay.addWidget(self.c_head)
        self.tbl = QTableWidget(rows, cols); lay.addWidget(self.tbl, 1)
        for rr in range(rows):
            for cc in range(cols):
                self.tbl.setItem(rr, cc, QTableWidgetItem(texts[rr][cc] if rr < len(texts) and cc < len(texts[rr]) else ""))
        self.sp_r.valueChanged.connect(self.tbl.setRowCount); self.sp_c.valueChanged.connect(self.tbl.setColumnCount)
        lay.addWidget(QLabel(tr("칸을 더블클릭해 내용을 입력하세요. 빈 칸은 글자가 만들어지지 않습니다.")))
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject); lay.addWidget(bb)

    def values(self):
        rows, cols = self.sp_r.value(), self.sp_c.value()
        texts = [[(self.tbl.item(r, c).text() if self.tbl.item(r, c) else "") for c in range(cols)] for r in range(rows)]
        return rows, cols, self.sp_cw.value(), self.sp_ch.value(), self.sp_fs.value(), self.c_head.isChecked(), texts


class View(QGraphicsView):
    def __init__(self, scene, window):
        super().__init__(scene)
        self.win = window
        self.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.setDragMode(QGraphicsView.DragMode.RubberBandDrag)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setAcceptDrops(True); self.viewport().setAcceptDrops(True)
        self.setBackgroundBrush(QBrush(QColor("#c9ccd1")))          # 캔버스(작업영역) 바탕 : 용지보다 어두운 회색
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self._pan = None

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        if getattr(self.win, 'auto_fit', False):
            self.win.fit(True)

    def wheelEvent(self, ev):
        self.win.auto_fit = False
        f = 1.15 if ev.angleDelta().y() > 0 else 1 / 1.15
        self.scale(f, f)

    def mousePressEvent(self, ev):
        if ev.button() == Qt.MouseButton.RightButton:
            if self.win.tool in ("select", "pan"):
                self.win.right_click_select(self.mapToScene(ev.position().toPoint())); ev.accept(); return
            if self.win.tool == "wire":
                self.win.finish_wire(); ev.accept(); return
            if self.win.tool in ("fmt", "shape"):
                self.win.tool_actions["select"].trigger(); ev.accept(); return
            ev.accept(); return
        if ev.button() == Qt.MouseButton.MiddleButton:
            self.win.auto_fit = False
            self._pan = ev.position(); self.setCursor(Qt.CursorShape.ClosedHandCursor); return
        if ev.button() == Qt.MouseButton.LeftButton:
            tool = self.win.tool
            if tool not in ("select", "pan"):
                self.win.tool_press(self.mapToScene(ev.position().toPoint()), ev); return
            if tool == "select" and (ev.modifiers() & Qt.KeyboardModifier.AltModifier):
                self.win.pick_prim(self.mapToScene(ev.position().toPoint())); return
        super().mousePressEvent(ev)

    def mouseMoveEvent(self, ev):
        if self._pan is not None:
            d = ev.position() - self._pan; self._pan = ev.position()
            self.horizontalScrollBar().setValue(int(self.horizontalScrollBar().value() - d.x()))
            self.verticalScrollBar().setValue(int(self.verticalScrollBar().value() - d.y()))
            return
        if self.win.tool not in ("select", "pan"):
            self.win.tool_move(self.mapToScene(ev.position().toPoint()))
        super().mouseMoveEvent(ev)

    def mouseReleaseEvent(self, ev):
        if self._pan is not None:
            self._pan = None; self.win.apply_cursor(); return
        if ev.button() == Qt.MouseButton.LeftButton and self.win.tool not in ("select", "pan"):
            self.win.tool_release(self.mapToScene(ev.position().toPoint())); return
        super().mouseReleaseEvent(ev)
        if self.win.tool == "pan":
            self.setCursor(Qt.CursorShape.OpenHandCursor)

    # --- 그림 파일/캡처 그림 끌어놓기
    def dragEnterEvent(self, ev):
        md = ev.mimeData()
        if md.hasUrls() or md.hasImage():
            ev.acceptProposedAction()
        else:
            super().dragEnterEvent(ev)

    def dragMoveEvent(self, ev):
        md = ev.mimeData()
        if md.hasUrls() or md.hasImage():
            ev.acceptProposedAction()
        else:
            super().dragMoveEvent(ev)

    def dropEvent(self, ev):
        md = ev.mimeData(); pt = self.mapToScene(ev.position().toPoint())
        if md.hasUrls():
            for u in md.urls():
                self.win.drop_file(u.toLocalFile(), pt)
            ev.acceptProposedAction(); return
        if md.hasImage():
            self.win.insert_qimage(md.imageData(), pt); ev.acceptProposedAction(); return
        super().dropEvent(ev)

    def contextMenuEvent(self, ev):
        if self.win.tool in ("select", "pan"):
            self.win.canvas_menu(self.mapToScene(ev.pos()), ev.globalPos()); ev.accept(); return
        super().contextMenuEvent(ev)

    def mouseDoubleClickEvent(self, ev):
        if self.win.tool == "wire":
            self.win.finish_wire(); return
        if self.win.tool == "select":
            pt = self.mapToScene(ev.position().toPoint())
            if self.win.dbl_click_table(pt):                       # 삽입한 표 더블클릭 -> 표 편집
                ev.accept(); return
            self.win.pick_prim(pt); return
        super().mouseDoubleClickEvent(ev)

    ARROWS = {Qt.Key.Key_Left: (-1, 0), Qt.Key.Key_Right: (1, 0), Qt.Key.Key_Up: (0, -1), Qt.Key.Key_Down: (0, 1)}

    def keyPressEvent(self, ev):
        if ev.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and self.win.tool == "wire":
            self.win.finish_wire(); return
        if ev.key() in self.ARROWS and self.win.tool == "select":
            mod = ev.modifiers()
            step = 10.0 if mod & Qt.KeyboardModifier.ShiftModifier else (0.1 if mod & Qt.KeyboardModifier.ControlModifier else 1.0)
            dx, dy = self.ARROWS[ev.key()]
            if self.win.nudge(dx * step, dy * step):
                ev.accept(); return
        if ev.key() == Qt.Key.Key_Escape:
            if self.win.tool in ("fmt", "shape"):
                self.win.tool_actions["select"].trigger()
            self.win.cancel_tool(); return
        super().keyPressEvent(ev)


class FindDialog(QDialog):
    """찾기 (Ctrl+F): 글자 / id / meta 검색. 결과 목록 더블클릭 또는 다음/이전으로 이동."""

    def __init__(self, win):
        super().__init__(win)
        self.win = win; self.res = []; self.pos = -1
        self.setWindowTitle(tr("찾기")); self.setModal(False); self.resize(460, 380)
        lay = QVBoxLayout(self)
        row = QHBoxLayout(); self.edit = QLineEdit(); self.edit.setPlaceholderText(tr("찾을 내용 (글자, id-번호, meta 값)"))
        self.btn_prev = QPushButton(tr("이전")); self.btn_next = QPushButton(tr("다음"))
        row.addWidget(self.edit, 1); row.addWidget(self.btn_prev); row.addWidget(self.btn_next); lay.addLayout(row)
        from PyQt6.QtWidgets import QCheckBox, QComboBox
        row2 = QHBoxLayout()
        self.cb_case = QCheckBox(tr("대/소문자 구분")); self.cmb = QComboBox()
        for k, lab in (("all", "전체 (글자+id+meta)"), ("text", "글자만"), ("meta", "id/meta 만")):
            self.cmb.addItem(tr(lab), k)
        row2.addWidget(self.cb_case); row2.addWidget(self.cmb, 1); lay.addLayout(row2)
        self.lst = QListWidget(); lay.addWidget(self.lst, 1)
        self.lbl = QLabel(""); lay.addWidget(self.lbl)
        self.edit.returnPressed.connect(lambda: self.step(1, True))
        self.btn_next.clicked.connect(lambda: self.step(1))
        self.btn_prev.clicked.connect(lambda: self.step(-1))
        self.lst.currentRowChanged.connect(self._row)
        self.cb_case.toggled.connect(self.search); self.cmb.currentIndexChanged.connect(self.search)
        self.edit.textChanged.connect(self.search)

    def search(self, *_):
        self.res = self.win.find_all(self.edit.text(), self.cb_case.isChecked(), self.cmb.currentData())
        self.lst.blockSignals(True); self.lst.clear()
        for gid, k, lab in self.res:
            self.lst.addItem(lab)
        self.lst.blockSignals(False)
        self.pos = -1
        self.lbl.setText(tr("%d건") % len(self.res) if self.edit.text() else "")

    def step(self, d, first=False):
        if not self.res:
            self.search()
        if not self.res:
            return
        self.pos = (self.pos + d) % len(self.res) if self.pos >= 0 else (0 if d > 0 else len(self.res) - 1)
        self.lst.setCurrentRow(self.pos)

    def _row(self, r):
        if 0 <= r < len(self.res):
            self.pos = r
            gid, k, _ = self.res[r]
            self.win.find_select(gid, k)
            self.lbl.setText("%d / %d" % (r + 1, len(self.res)))


class FormatCopyDialog(QDialog):
    """서식 복사: 복사할 속성을 체크해서 선택."""

    def __init__(self, win, prim, names, keys):
        super().__init__(win)
        self.setWindowTitle(tr("서식 복사 항목 선택")); self.resize(520, 420)
        self.names = names; self.is_text = prim.tag == "text"
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel(tr("복사할 속성을 선택하세요. 위치(x, y 등) 속성은 목록에서 제외됩니다.")))
        self.lst = QListWidget(); lay.addWidget(self.lst, 1)
        for k in names:
            it = QListWidgetItem("%s = %s" % (k, prim.attrs[k])); it.setData(Qt.ItemDataRole.UserRole, k)
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Checked if k in keys else Qt.CheckState.Unchecked); self.lst.addItem(it)
        r = QHBoxLayout()
        b_text = QPushButton(tr("글자 서식 (폰트·크기·길이)")); b_all = QPushButton(tr("모두 선택")); b_none = QPushButton(tr("모두 해제"))
        if self.is_text:
            r.addWidget(b_text)
        r.addWidget(b_all); r.addWidget(b_none); r.addStretch(1); lay.addLayout(r)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject); lay.addWidget(bb)
        b_text.clicked.connect(lambda: self.set_only(MainWindow.FMT_TEXT))
        b_all.clicked.connect(lambda: self.set_only(self.names)); b_none.clicked.connect(lambda: self.set_only(()))

    def set_only(self, keys):
        for i in range(self.lst.count()):
            it = self.lst.item(i)
            it.setCheckState(Qt.CheckState.Checked if it.data(Qt.ItemDataRole.UserRole) in keys else Qt.CheckState.Unchecked)

    def checked(self):
        return [self.lst.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.lst.count()) if self.lst.item(i).checkState() == Qt.CheckState.Checked]


class SplitWorker(QThread):
    prog = pyqtSignal(int, int, str)
    done = pyqtSignal(list)

    def __init__(self, items, outdir, mk_pdf, mk_svg, fix, auto):
        super().__init__()
        self.a = (items, outdir, mk_pdf, mk_svg, fix, auto); self.stop = False

    def run(self):
        import splitpdf
        items, o, mp, ms, fx, au = self.a
        try:
            r = splitpdf.run_many(items, o, mp, ms, fx, au, progress=lambda i, n, nm, m: self.prog.emit(i, n, nm), cancel=lambda: self.stop)
        except Exception as ex:
            r = [("(오류)", [str(ex)])]
        self.done.emit(r)


class SplitDialog(QDialog):
    """배선도 PDF 페이지별 분할 + SVG 변환."""

    def __init__(self, win, path=None):
        super().__init__(win)
        self.win = win; self.worker = None
        self.setWindowTitle(tr("PDF 분할 / SVG 일괄 변환")); self.resize(760, 560)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel(tr("배선도 PDF(여러 개 선택 또는 폴더 전체, 다중 페이지 포함)를 페이지별 배선도명(표제란 Document title)으로 PDF 저장하고 SVG 로 변환합니다.")))
        self.srcs = []
        r1 = QHBoxLayout(); self.e_src = QLineEdit(path or ""); self.e_src.setReadOnly(True); b1 = QPushButton(tr("PDF 선택…")); b1f = QPushButton(tr("폴더의 PDF 전체…"))
        r1.addWidget(QLabel(tr("입력 PDF"))); r1.addWidget(self.e_src, 1); r1.addWidget(b1); r1.addWidget(b1f); lay.addLayout(r1)
        r2 = QHBoxLayout(); self.e_out = QLineEdit(); b2 = QPushButton(tr("폴더 선택…")); r2.addWidget(QLabel(tr("저장 폴더"))); r2.addWidget(self.e_out, 1); r2.addWidget(b2); lay.addLayout(r2)
        r3 = QHBoxLayout()
        self.c_pdf = QCheckBox(tr("페이지별 PDF 저장")); self.c_pdf.setChecked(True)
        self.c_svg = QCheckBox(tr("SVG 변환 저장")); self.c_svg.setChecked(True)
        self.c_fix = QCheckBox(tr("자동 수정 적용")); self.c_fix.setChecked(True)
        self.c_auto = QCheckBox(tr("이미지 네비게이션 ID 생성")); self.c_auto.setChecked(True)
        for c in (self.c_pdf, self.c_svg, self.c_fix, self.c_auto):
            r3.addWidget(c)
        lay.addLayout(r3)
        self.lst = QListWidget(); lay.addWidget(self.lst, 1)
        self.lbl = QLabel(""); lay.addWidget(self.lbl)
        self.bar = QProgressBar(); lay.addWidget(self.bar)
        r4 = QHBoxLayout(); r4.addStretch(1)
        self.b_run = QPushButton(tr("실행")); self.b_stop = QPushButton(tr("중지")); self.b_stop.setEnabled(False); b_close = QPushButton(tr("닫기"))
        for b in (self.b_run, self.b_stop, b_close):
            r4.addWidget(b)
        lay.addLayout(r4)
        b1.clicked.connect(self.pick_src); b1f.clicked.connect(self.pick_folder); b2.clicked.connect(self.pick_out); b_close.clicked.connect(self.close)
        self.b_run.clicked.connect(self.start); self.b_stop.clicked.connect(self.stop)
        self.e_out.setText(win.last_dir())
        if path:
            self.set_sources([path])

    def pick_src(self):
        ps, _ = QFileDialog.getOpenFileNames(self, tr("열기"), self.win.last_dir(), "PDF (*.pdf)")
        if ps:
            self.win.remember_dir(ps[0]); self.set_sources(ps)

    def pick_folder(self):
        d = QFileDialog.getExistingDirectory(self, tr("폴더의 PDF 전체…"), self.win.last_dir())
        if d:
            ps = sorted(os.path.join(d, f) for f in os.listdir(d) if f.lower().endswith(".pdf"))
            if not ps:
                QMessageBox.information(self, tr("PDF 분할 / SVG 일괄 변환"), tr("폴더에 PDF 파일이 없습니다.")); return
            self.win.remember_dir(ps[0]); self.set_sources(ps)

    def set_sources(self, ps):
        self.srcs = [p for p in ps if os.path.isfile(p)]
        self.e_src.setText(self.srcs[0] if len(self.srcs) == 1 else "%s  (%d%s)" % (os.path.dirname(self.srcs[0]) if self.srcs else "", len(self.srcs), tr("개 PDF")))
        if self.srcs:
            base = os.path.dirname(self.srcs[0])
            self.e_out.setText(os.path.join(base, os.path.splitext(os.path.basename(self.srcs[0]))[0] + "_split") if len(self.srcs) == 1 else os.path.join(base, "svg_out"))
        self.load_plan()

    def pick_out(self):
        d = QFileDialog.getExistingDirectory(self, tr("저장 폴더"), self.e_out.text() or self.win.last_dir())
        if d:
            self.e_out.setText(d)

    def load_plan(self):
        import splitpdf
        self.lst.clear(); self.plan = []
        if not self.srcs:
            return
        try:
            self.plan = splitpdf.plan_many(self.srcs)
        except Exception as ex:
            self.lbl.setText(str(ex)); return
        multi = len(self.srcs) > 1
        for k, (p, i, n) in enumerate(self.plan):
            it = QListWidgetItem("%3d  %s%s" % (k + 1, n, ("    [%s p.%d]" % (os.path.basename(p), i + 1)) if multi else ""))
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable); it.setCheckState(Qt.CheckState.Checked); it.setData(Qt.ItemDataRole.UserRole, k)
            self.lst.addItem(it)
        self.lbl.setText(tr("페이지 수: ") + str(len(self.plan)))

    def start(self):
        o = self.e_out.text().strip()
        if not self.srcs or not o:
            QMessageBox.warning(self, tr("PDF 분할 / SVG 일괄 변환"), tr("입력 PDF 와 저장 폴더를 지정하세요.")); return
        sel = {self.lst.item(k).data(Qt.ItemDataRole.UserRole) for k in range(self.lst.count()) if self.lst.item(k).checkState() == Qt.CheckState.Checked}
        items = [x for k, x in enumerate(self.plan) if k in sel]
        if not items:
            return
        self.b_run.setEnabled(False); self.b_stop.setEnabled(True); self.bar.setValue(0)
        w = SplitWorker(items, o, self.c_pdf.isChecked(), self.c_svg.isChecked(), self.c_fix.isChecked(), self.c_auto.isChecked())
        w.prog.connect(self.on_prog); w.done.connect(self.on_done); self.worker = w; w.start()

    def stop(self):
        if self.worker:
            self.worker.stop = True

    def on_prog(self, i, n, name):
        self.bar.setMaximum(max(1, n)); self.bar.setValue(i); self.lbl.setText("%d / %d  %s" % (i, n, name))

    def on_done(self, res):
        self.b_run.setEnabled(True); self.b_stop.setEnabled(False)
        self.lst.clear()
        bad = 0
        for n, m in res:
            self.lst.addItem("%s%s" % (n, ("   ⚠ " + " / ".join(m)) if m else "   ✔")); bad += 1 if m else 0
        self.bar.setValue(self.bar.maximum())
        self.lbl.setText(tr("완료: ") + "%d  (%s %d)  → %s" % (len(res), tr("확인 필요"), bad, self.e_out.text()))

    def closeEvent(self, e):
        if self.worker and self.worker.isRunning():
            self.worker.stop = True; self.worker.wait(5000)
        super().closeEvent(e)


class FormDialog(QDialog):
    def __init__(self, parent, title, fields):
        super().__init__(parent)
        self.setWindowTitle(title)
        lay = QFormLayout(self)
        self.edits = {}
        for name, default in fields:
            e = QLineEdit(default)
            self.edits[name] = e
            lay.addRow(tr(name), e)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        lay.addRow(bb)

    def values(self):
        return {k: e.text().strip() for k, e in self.edits.items()}


# ============================================================================ DevTools 형 코드 트리
_TOK = re.compile(r'<!\[CDATA\[.*?\]\]>|</?[\w-]+|[\w:-]+="[^"]*"|/?>|\s+|[^<>\s]+', re.S)


def code_html(s: str) -> str:
    out = []
    for m in _TOK.finditer(s):
        t = m.group(0); e = _html.escape(t)
        if t.startswith("<![CDATA["):
            out.append('<span style="color:#c41a16">%s</span>' % e)
        elif t.startswith("<") and re.match(r"</?[\w-]+$", t):
            out.append('<span style="color:#881280">%s</span>' % e)
        elif t in ("/>", ">"):
            out.append('<span style="color:#881280">%s</span>' % e)
        elif re.match(r'[\w:-]+="', t):
            k, v = t.split("=", 1)
            out.append('<span style="color:#994500">%s</span>=<span style="color:#1a1aa6">%s</span>' % (_html.escape(k), _html.escape(v)))
        else:
            out.append(e.replace(" ", "&nbsp;"))
    return "".join(out)


class CodeDelegate(QStyledItemDelegate):
    def _doc(self, index, w=None):
        d = QTextDocument()
        d.setDefaultFont(self.parent().font())
        d.setDocumentMargin(1)
        d.setHtml('<span style="white-space:pre">%s</span>' % index.data(Qt.ItemDataRole.UserRole + 1))
        return d

    def paint(self, painter, option, index):
        painter.save()
        sel = bool(option.state & QStyle.StateFlag.State_Selected)
        if sel:
            painter.fillRect(option.rect, QColor("#1a73e8"))
        d = self._doc(index)
        if sel:
            d.setHtml('<span style="white-space:pre;color:white">%s</span>' % _html.escape(index.data(Qt.ItemDataRole.DisplayRole)).replace(" ", "&nbsp;"))
        painter.translate(option.rect.left(), option.rect.top())
        d.drawContents(painter)
        painter.restore()

    def sizeHint(self, option, index):
        fm = QFontMetricsF(self.parent().font())
        return QSize(int(fm.horizontalAdvance(index.data(Qt.ItemDataRole.DisplayRole) or "")) + 8, int(fm.height()) + 5)


class CodeTree(QTreeWidget):
    dropped = pyqtSignal(list, object)           # [token...], target token

    def __init__(self):
        super().__init__()
        self.setHeaderHidden(True)
        self.setUniformRowHeights(True)
        self.setItemDelegate(CodeDelegate(self))
        self.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.setDragEnabled(True); self.setAcceptDrops(True); self.setDropIndicatorShown(True)
        self.setDragDropMode(QAbstractItemView.DragDropMode.DragDrop)
        self.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.setIndentation(14)
        self.header().setStretchLastSection(False)
        self.header().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.set_code_font(10)

    def set_code_font(self, pt):
        f = QFont(MONO, pt); f.setStyleHint(QFont.StyleHint.Monospace); self.setFont(f); self.doItemsLayout()

    def dropEvent(self, ev):
        tgt = self.itemAt(ev.position().toPoint())
        toks = [i.data(0, Qt.ItemDataRole.UserRole) for i in self.selectedItems()]
        ev.ignore()                                  # 트리 자체는 Qt 가 바꾸지 않고, 모델(Doc)을 고친 뒤 다시 그린다
        if tgt is not None and toks:
            self.dropped.emit(toks, tgt.data(0, Qt.ItemDataRole.UserRole))


def _grp_open(g: Group) -> str:
    return '<g id="id-%d" class="%s">' % (g.gid, g.cls)


# ============================================================================ 메인 윈도우
class SigTableDialog(QDialog):
    """시그널 테이블: 도면(SVG)에서 엑셀로 내보내기 / 도면 기준으로 기존 엑셀 수정.
    wire 정보가 없는 도면은 자동으로 제외한다."""

    def __init__(self, win, mode="export"):
        super().__init__(win)
        self.win = win; self.mode = mode; self.out_path = ""
        self.setWindowTitle(tr("시그널 테이블 내보내기") if mode == "export" else tr("시그널 테이블 대조 / 도면 기준 엑셀 수정"))
        self.resize(820, 640)
        lay = QVBoxLayout(self)
        if mode == "export":
            lay.addWidget(QLabel(tr("배선도 SVG 의 wire / 부품 / 커넥터 정보에서 시그널 테이블(엑셀)을 만듭니다. wire 가 없는 도면은 제외됩니다.")))
        else:
            lay.addWidget(QLabel(tr("도면을 기준으로 기존 시그널 테이블(엑셀)의 값을 수정합니다. 수정한 칸은 노란색, 추가한 행은 녹색으로 표시하고 '변경 내역' 시트를 만듭니다. 원본 파일은 바꾸지 않고 새 파일로 저장합니다.")))
        lay.itemAt(0).widget().setWordWrap(True)
        lay.addWidget(QLabel(tr("도면(SVG) 목록")))
        self.lst = QListWidget(); self.lst.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection); lay.addWidget(self.lst, 1)
        r = QHBoxLayout()
        b_tabs = QPushButton(tr("열린 문서 추가")); b_files = QPushButton(tr("파일 추가…")); b_dir = QPushButton(tr("폴더 추가…"))
        b_del = QPushButton(tr("선택 삭제")); b_clr = QPushButton(tr("목록 비우기"))
        for b in (b_tabs, b_files, b_dir, b_del, b_clr):
            r.addWidget(b)
        r.addStretch(1); lay.addLayout(r)
        if mode == "update":
            r2 = QHBoxLayout(); self.e_master = QLineEdit(); b_m = QPushButton(tr("엑셀 선택…"))
            r2.addWidget(QLabel(tr("기존 시그널 테이블(엑셀)"))); r2.addWidget(self.e_master, 1); r2.addWidget(b_m); lay.addLayout(r2)
            b_m.clicked.connect(self.pick_master)
        rp = QHBoxLayout(); self.cb_prof = QComboBox(); self.cb_prof.addItems([tr("자동 판별"), "AR", "RG4F1"])
        rp.addWidget(QLabel(tr("차량 규칙"))); rp.addWidget(self.cb_prof); rp.addStretch(1); lay.addLayout(rp)
        r3 = QHBoxLayout(); self.e_out = QLineEdit(); b_o = QPushButton(tr("저장 위치…"))
        r3.addWidget(QLabel(tr("저장할 엑셀"))); r3.addWidget(self.e_out, 1); r3.addWidget(b_o); lay.addLayout(r3)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True); lay.addWidget(self.log, 1)
        r4 = QHBoxLayout(); r4.addStretch(1)
        self.b_run = QPushButton(tr("실행")); self.b_open = QPushButton(tr("결과 폴더 열기")); self.b_open.setEnabled(False); b_close = QPushButton(tr("닫기"))
        for b in (self.b_run, self.b_open, b_close):
            r4.addWidget(b)
        lay.addLayout(r4)
        b_tabs.clicked.connect(self.add_tabs); b_files.clicked.connect(self.add_files); b_dir.clicked.connect(self.add_dir)
        b_del.clicked.connect(self.del_sel); b_clr.clicked.connect(self.lst.clear); b_o.clicked.connect(self.pick_out)
        self.b_run.clicked.connect(self.run); self.b_open.clicked.connect(self.open_dir); b_close.clicked.connect(self.close)
        self.add_tabs()
        _d = i18n.get_setting("sig_out_dir", "") or ""
        if not os.path.isdir(_d):
            _d = win.last_dir()
        self.e_out.setText(os.path.join(_d, "SignalTable.xlsx" if mode == "export" else "SignalTable_도면반영.xlsx"))

    # ---- 목록
    def _add(self, label, path=None, doc=None):
        for i in range(self.lst.count()):
            d = self.lst.item(i).data(Qt.ItemDataRole.UserRole)
            if (path and d.get("path") == path) or (doc is not None and d.get("doc") is doc):
                return
        it = QListWidgetItem(label); it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable); it.setCheckState(Qt.CheckState.Checked)
        it.setData(Qt.ItemDataRole.UserRole, {"path": path, "doc": doc}); self.lst.addItem(it)

    def add_tabs(self):
        w = self.win
        try:
            w._tab_save(w.cur)
        except Exception:
            pass
        import sigtable
        for t in w.tabs:
            d = t.get("doc")
            if d is not None and sigtable.has_wires(d):
                self._add("[%s] %s" % (tr("열림"), t.get("full") or t.get("name", "")), path=t.get("full"), doc=d)

    def add_files(self):
        ps, _ = QFileDialog.getOpenFileNames(self, tr("도면(SVG) 선택"), self.win.last_dir(), "SVG (*.svg)")
        for p in ps:
            self._add(p, path=p); self.win.remember_dir(p)

    def add_dir(self):
        d = QFileDialog.getExistingDirectory(self, tr("폴더 선택"), self.win.last_dir())
        if d:
            self.win.remember_dir(os.path.join(d, "x"))
            for f in sorted(os.listdir(d)):
                if f.lower().endswith(".svg"):
                    self._add(os.path.join(d, f), path=os.path.join(d, f))

    def del_sel(self):
        for it in self.lst.selectedItems():
            self.lst.takeItem(self.lst.row(it))

    def pick_master(self):
        p, _ = QFileDialog.getOpenFileName(self, tr("기존 시그널 테이블(엑셀)"), self.win.last_dir(), "Excel (*.xlsx)")
        if p:
            self.e_master.setText(p); self.win.remember_dir(p)
            self.e_out.setText(os.path.join(os.path.dirname(p), os.path.splitext(os.path.basename(p))[0] + "_도면반영.xlsx"))

    def pick_out(self):
        p, _ = QFileDialog.getSaveFileName(self, tr("저장할 엑셀"), self.e_out.text() or self.win.last_dir(), "Excel (*.xlsx)")
        if p:
            self.e_out.setText(p); self._remember_out(p)

    def _remember_out(self, p):
        try:
            d = os.path.dirname(os.path.abspath(p))
            if os.path.isdir(d):
                i18n.set_setting("sig_out_dir", d)
        except Exception:
            pass

    def say(self, m):
        self.log.appendPlainText(m); QApplication.processEvents()

    def open_dir(self):
        if self.out_path:
            QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.dirname(os.path.abspath(self.out_path))))

    # ---- 실행
    def run(self):
        import sigtable
        self.log.clear(); self.b_open.setEnabled(False)
        out = self.e_out.text().strip()
        if not out:
            QMessageBox.warning(self, tr("시그널 테이블"), tr("저장할 엑셀 파일을 지정하세요.")); return
        master = ""
        if self.mode == "update":
            master = self.e_master.text().strip()
            if not os.path.isfile(master):
                QMessageBox.warning(self, tr("시그널 테이블"), tr("기존 시그널 테이블(엑셀)을 선택하세요.")); return
            if os.path.abspath(master) == os.path.abspath(out):
                QMessageBox.warning(self, tr("시그널 테이블"), tr("원본을 덮어쓰지 않도록 다른 이름으로 저장하세요.")); return
        srcs = []
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            for i in range(self.lst.count()):
                it = self.lst.item(i)
                if it.checkState() != Qt.CheckState.Checked:
                    continue
                d = it.data(Qt.ItemDataRole.UserRole)
                label = it.text()
                if d.get("doc") is not None:
                    srcs.append((label, d["doc"])); continue
                try:
                    self.say(tr("읽는 중: ") + os.path.basename(d["path"]))
                    srcs.append((os.path.basename(d["path"]), sigtable.load_doc(d["path"])))
                except Exception as ex:
                    self.say("%s: %s (%s)" % (tr("읽기 실패"), os.path.basename(d["path"]), ex))
            if not srcs:
                self.say(tr("선택된 도면이 없습니다.")); return
            rows, info = sigtable.collect(srcs, self.say, (None, "AR", "RG4F1")[self.cb_prof.currentIndex()])
            if not rows:
                self.say(tr("와이어가 있는 도면이 없어 만들 내용이 없습니다.")); return
            if self.mode == "export":
                n = sigtable.export_xlsx(out, rows)
                self.say("%s: %d %s → %s" % (tr("완료"), n, tr("행"), out))
                msg = "%s\n%d %s" % (out, n, tr("행"))
            else:
                res = sigtable.update_xlsx(master, out, rows)
                kinds = {}
                for x in res["report"]:
                    kinds[x[0]] = kinds.get(x[0], 0) + 1
                self.say("%s: %s %d, %s %d, %s %d" % (tr("완료"), tr("수정한 칸"), res["changed_cells"], tr("수정한 행"), res["changed_rows"], tr("추가한 행"), res["added"]))
                for k, v in kinds.items():
                    if k not in ("수정", "추가"):
                        self.say("  %s: %d (%s)" % (k, v, tr("변경 내역 시트 참조")))
                msg = "%s\n%s %d / %s %d" % (out, tr("수정한 칸"), res["changed_cells"], tr("추가한 행"), res["added"])
            if info["skipped"]:
                self.say("%s: %d" % (tr("제외된 도면(와이어 없음)"), len(info["skipped"])))
            self.out_path = out; self.b_open.setEnabled(True); self._remember_out(out)
            self.win.statusBar().showMessage(tr("시그널 테이블 저장: ") + out)
        except ImportError as ex:
            QMessageBox.critical(self, tr("시그널 테이블"), "%s\n\npip install openpyxl" % ex); return
        except Exception as ex:
            import traceback
            self.say(traceback.format_exc())
            QMessageBox.critical(self, tr("시그널 테이블"), str(ex)); return
        finally:
            QApplication.restoreOverrideCursor()
        QMessageBox.information(self, tr("시그널 테이블"), msg)


class MainWindow(QMainWindow):
    @property
    def MAX_TABS(self):
        """동시에 열 수 있는 문서 수 (설정 > 최대 문서 수, 기본 5)"""
        try:
            return max(1, min(50, int(i18n.get_setting("max_tabs", 5) or 5)))
        except Exception:
            return 5

    @property
    def modified(self):
        return self._modified

    @modified.setter
    def modified(self, v):
        self._modified = bool(v)
        if getattr(self, "tabbar", None) is not None:
            self._tab_label(self.cur)

    def __init__(self):
        super().__init__()
        self.resize(1600, 980)
        self.doc = self.blank_doc(*self.default_canvas())
        self.scene = QGraphicsScene()
        self.view = View(self.scene, self)
        self.tabbar = None; self._modified = False
        self.items = []
        self.by_gid = {}
        self.overlays = []
        self.page_rect = QRectF(0, 0, 1200, 800)
        self.tool = "select"
        self.sel_prims = []
        self.thandles = []
        self._pts = []; self._rubber = None; self._drag0 = None
        self.undo_stack, self.redo_stack = [], []
        self.modified = False
        self._busy = False; self._loading = False
        self.clip = None
        self.auto_fit = True
        self.extra_gids = set()
        self._tr = []
        self._make_actions()
        self._make_docks()
        self._make_tabs()
        self._make_explorer()
        self._setup_view_panels()
        self.retranslate()
        self.statusBar().showMessage(tr("PDF 또는 SVG 파일을 여세요 (Ctrl+O)"))
        self.rebuild()
        QTimer.singleShot(0, self.fit)


    # ------------------------------------------------------------------ 문서 탭 (최대 5개 동시 열람)
    def _make_tabs(self):
        self.tabbar = QTabBar(); self.tabbar.setTabsClosable(True); self.tabbar.setExpanding(False); self.tabbar.setDocumentMode(True)
        self.tabbar.setElideMode(Qt.TextElideMode.ElideMiddle); self.tabbar.setUsesScrollButtons(True)
        self.tabs = [{"name": self.doc.title or tr("새 도면")}]; self.cur = 0
        self.tabbar.addTab(""); self._tab_label(0)
        cw = QWidget(); lay = QVBoxLayout(cw); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(0)
        th = QHBoxLayout(); th.setContentsMargins(0, 0, 0, 0); th.setSpacing(0)
        self.b_tcloseall = QToolButton(); self.b_tcloseall.setText("✕"); self.b_tcloseall.setAutoRaise(True)
        self.b_tcloseall.setFixedSize(30, 28); self.b_tcloseall.clicked.connect(lambda _=False: self.tab_close_all())
        self.reg(lambda: self.b_tcloseall.setToolTip(tr("전체 탭 닫기")))
        th.addWidget(self.tabbar, 1); th.addWidget(self.b_tcloseall)
        self.tabbar.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tabbar.customContextMenuRequested.connect(self._tab_menu)
        lay.addLayout(th); lay.addWidget(self.view)
        self.setCentralWidget(cw)
        self.tabbar.currentChanged.connect(self.tab_switch)
        self.tabbar.tabCloseRequested.connect(self.tab_close)

    def _tab_label(self, i):
        if self.tabbar is None or not (0 <= i < len(self.tabs)):
            return
        mod = self._modified if i == self.cur else self.tabs[i].get("modified", False)
        self.tabbar.setTabText(i, self.tabs[i]["name"] + (" *" if mod else ""))
        self.tabbar.setTabToolTip(i, self.tabs[i].get("full", self.tabs[i]["name"]))

    def _set_name(self, name, full=None):
        """현재 문서의 표시 이름(탭/제목줄) 설정."""
        self.tabs[self.cur]["name"] = name; self.tabs[self.cur]["full"] = full or name
        self._tab_label(self.cur)
        self.setWindowTitle("%s v%s - %s" % (APP_NAME, VERSION, name))

    def _tab_save(self, i):
        t = self.tabs[i]
        t.update(doc=self.doc, undo=self.undo_stack, redo=self.redo_stack, modified=self._modified, extra=self.extra_gids,
                 tf=self.view.transform(), h=self.view.horizontalScrollBar().value(), v=self.view.verticalScrollBar().value(), af=self.auto_fit)

    def _tab_load(self, i):
        t = self.tabs[i]; self.cur = i
        self.doc = t["doc"]; self.undo_stack = t["undo"]; self.redo_stack = t["redo"]
        self._modified = t.get("modified", False); self.extra_gids = t.get("extra", set()); self.sel_prims = []
        self.rebuild()
        if t.get("af", True) or "tf" not in t:
            self.fit(); QTimer.singleShot(0, self.fit)
        else:
            self.auto_fit = False; self.view.setTransform(t["tf"])
            self.view.horizontalScrollBar().setValue(t["h"]); self.view.verticalScrollBar().setValue(t["v"])
        self.setWindowTitle("%s v%s - %s" % (APP_NAME, VERSION, t["name"]))
        self._tab_label(i); self.run_check()

    def tab_switch(self, i):
        if i < 0 or i == self.cur or i >= len(self.tabs) or getattr(self, "_tab_busy", False):
            return
        self._tab_save(self.cur); self._tab_load(i)

    def _blank_reusable(self):
        """처음 상태 그대로인 빈 문서 탭이면 그 탭을 재사용."""
        return len(self.tabs) == 1 and not self._modified and not self.tabs[0].get("full") and not self.undo_stack

    def tab_new(self):
        """새 탭 확보. 가득 차면 False. True 이면 현재 탭이 새 문서용으로 비어 있다."""
        if self._blank_reusable():
            return True
        if len(self.tabs) >= self.MAX_TABS:
            QMessageBox.information(self, tr("탭"), tr("문서는 최대 %d개까지 동시에 열 수 있습니다. 탭을 닫은 후 다시 시도하세요.") % self.MAX_TABS)
            return False
        self._tab_save(self.cur)
        self.tabs.append({"name": ""})
        self._tab_busy = True
        self.tabbar.addTab(""); self.tabbar.setCurrentIndex(len(self.tabs) - 1)
        self._tab_busy = False
        self.cur = len(self.tabs) - 1
        self.tabs[self.cur].update(doc=self.doc)          # 호출한 쪽에서 곧 self.doc 등을 새 문서로 교체
        self.undo_stack, self.redo_stack = [], []; self._modified = False
        return True

    def find_tab(self, path):
        ap = os.path.normcase(os.path.abspath(path))
        for i, t in enumerate(self.tabs):
            if t.get("full") and os.path.normcase(os.path.abspath(t["full"])) == ap:
                return i
        return -1

    def goto_tab(self, i):
        if i != self.cur:
            self.tabbar.setCurrentIndex(i)

    def tab_close(self, i=None):
        i = self.cur if i is None or i is False else i
        if i == self.cur:
            self._tab_save(i)
        t = self.tabs[i]
        if t.get("modified", False):
            r = QMessageBox.question(self, tr("탭 닫기"), tr("저장하지 않은 변경 내용이 있습니다. 이 탭을 닫을까요?") + "\n" + t["name"])
            if r != QMessageBox.StandardButton.Yes:
                return
        if len(self.tabs) == 1:                           # 마지막 탭 : 빈 도면으로 교체
            d = self.blank_doc(*self.default_canvas())
            self.tabs[0] = {"name": tr("새 도면"), "doc": d, "undo": [], "redo": [], "modified": False}
            self._tab_load(0); return
        self.tabs.pop(i)
        self._tab_busy = True
        self.tabbar.removeTab(i)
        if i < self.cur:
            self.cur -= 1
            self.tabbar.setCurrentIndex(self.cur); self._tab_busy = False
        elif i == self.cur:
            n = min(i, len(self.tabs) - 1)
            self.tabbar.setCurrentIndex(n); self._tab_busy = False
            self._tab_load(n)
        else:
            self.tabbar.setCurrentIndex(self.cur); self._tab_busy = False
        for k in range(len(self.tabs)):
            self._tab_label(k)

    def _tab_menu(self, pos):
        i = self.tabbar.tabAt(pos)
        m = QMenu(self)
        if i >= 0:
            m.addAction(tr("탭 닫기"), lambda: self.tab_close(i))
        m.addAction(tr("전체 탭 닫기"), self.tab_close_all)
        m.exec(self.tabbar.mapToGlobal(pos))

    def set_max_tabs(self, n):
        i18n.set_setting("max_tabs", int(n))
        self.statusBar().showMessage(tr("동시에 열 수 있는 문서 수: %d") % n)

    def tab_close_all(self):
        """열려 있는 모든 탭을 닫고 빈 도면 하나만 남긴다 (저장 안 한 문서가 있으면 한 번 확인)."""
        self._tab_save(self.cur)
        mod = [t["name"] for t in self.tabs if t.get("modified", False)]
        if mod:
            r = QMessageBox.question(self, tr("전체 탭 닫기"), tr("저장하지 않은 변경 내용이 있는 문서가 %d개 있습니다. 모두 닫을까요?") % len(mod) + "\n" + "\n".join(mod[:10]))
            if r != QMessageBox.StandardButton.Yes:
                return
        elif len(self.tabs) == 1 and not self.tabs[0].get("full"):
            return
        d = self.blank_doc(*self.default_canvas())
        self._tab_busy = True
        while self.tabbar.count() > 1:
            self.tabbar.removeTab(self.tabbar.count() - 1)
        self.tabs = [{"name": tr("새 도면"), "doc": d, "undo": [], "redo": [], "modified": False}]
        self.cur = 0
        self.tabbar.setCurrentIndex(0); self._tab_busy = False
        self._tab_load(0)

    # ------------------------------------------------------------------ 탐색기 (폴더의 SVG/PDF 목록)
    def _setup_view_panels(self):
        self._default_dock_state = self.saveState()
        vm = self.view_menu; vm.addSeparator()
        for dk in self.findChildren(QDockWidget):
            vm.addAction(dk.toggleViewAction())   # 패널 닫았을 때 다시 표시 (제목은 패널 이름 따라감)
        vm.addSeparator()
        self.a_resetdock = QAction(self); self.a_resetdock.triggered.connect(self.reset_docks)
        self.reg(lambda: self.a_resetdock.setText(tr("패널 배치 초기화")))
        vm.addAction(self.a_resetdock)

    def _make_explorer(self):
        w = QWidget(); l = QVBoxLayout(w); l.setContentsMargins(2, 2, 2, 2)
        h = QHBoxLayout()
        self.ex_path = QLineEdit(); self.b_exup = QPushButton("↑"); self.b_exup.setMaximumWidth(36); self.b_exdir = QPushButton("…"); self.b_exdir.setMaximumWidth(36)
        h.addWidget(self.b_exup); h.addWidget(self.ex_path, 1); h.addWidget(self.b_exdir); l.addLayout(h)
        self.ex_model = QFileSystemModel(self)
        self.ex_model.setFilter(QDir.Filter.AllDirs | QDir.Filter.Files | QDir.Filter.NoDotAndDotDot)
        self.ex_model.setNameFilters(["*.svg", "*.pdf"]); self.ex_model.setNameFilterDisables(False)
        self.ex_view = QTreeView(); self.ex_view.setModel(self.ex_model)
        for c in (1, 2, 3):
            self.ex_view.setColumnHidden(c, True)
        self.ex_view.setHeaderHidden(True)
        self.ex_view.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.ex_view.doubleClicked.connect(self.ex_open_index)
        self.ex_view.activated.connect(self.ex_open_index)
        self.ex_view.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.ex_view.customContextMenuRequested.connect(self.ex_menu)
        self._ex_acts = {}
        for key, seq, fn in (("rename", "F2", self.ex_rename), ("copy", "Ctrl+C", lambda: self.ex_copy(False)), ("cut", "Ctrl+X", lambda: self.ex_copy(True)),
                             ("paste", "Ctrl+V", self.ex_paste), ("delete", "Delete", self.ex_delete), ("newdir", "Ctrl+Shift+N", self.ex_newdir)):
            a = QAction(self.ex_view); a.setShortcut(QKeySequence(seq)); a.setShortcutContext(Qt.ShortcutContext.WidgetShortcut)
            a.triggered.connect(lambda _=False, f=fn: f()); self.ex_view.addAction(a); self._ex_acts[key] = a
        l.addWidget(self.ex_view)
        self.ex_hint = QLabel(""); self.ex_hint.setWordWrap(True); l.addWidget(self.ex_hint)
        self.ex_dock = QDockWidget(self); self.ex_dock.setWidget(w); self.ex_dock.setObjectName("dock_explorer")
        self.reg(lambda: (self.ex_dock.setWindowTitle(tr("탐색기")), self.ex_hint.setText(tr("더블클릭하면 새 탭으로 엽니다 (최대 %d개 동시 열람)") % self.MAX_TABS),
                          self.b_exup.setToolTip(tr("상위 폴더")), self.b_exdir.setToolTip(tr("폴더 선택…"))))
        first = next((d for d in self.findChildren(QDockWidget) if d.objectName() == "dock_tree"), None)
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, self.ex_dock)
        if first is not None:
            self.splitDockWidget(self.ex_dock, first, Qt.Orientation.Vertical)
            self.resizeDocks([self.ex_dock, first], [260, 600], Qt.Orientation.Vertical)
        self.ex_path.editingFinished.connect(lambda: self.ex_set_root(self.ex_path.text().strip()))
        self.b_exup.clicked.connect(lambda: self.ex_set_root(os.path.dirname(self.ex_path.text().rstrip("/\\")) or self.ex_path.text()))
        self.b_exdir.clicked.connect(self.ex_pick)
        self.ex_set_root(self.last_dir())

    def ex_set_root(self, d):
        if d and os.path.isdir(d):
            d = os.path.abspath(d)
            self.ex_path.setText(d)
            self.ex_view.setRootIndex(self.ex_model.setRootPath(d))

    def ex_pick(self):
        d = QFileDialog.getExistingDirectory(self, tr("폴더 선택…"), self.ex_path.text() or self.last_dir())
        if d:
            self.ex_set_root(d)

    def ex_open_index(self, idx):
        idxs = [i for i in self.ex_view.selectionModel().selectedRows(0)] or [idx]
        for ix in idxs:
            p = self.ex_model.filePath(ix)
            if os.path.isfile(p):
                self.open_file(p)
            elif os.path.isdir(p) and len(idxs) == 1:
                self.ex_view.setExpanded(ix, not self.ex_view.isExpanded(ix))

    # ---- 탐색기 오른쪽 마우스 메뉴 (열기 / 이름 바꾸기 / 복사 / 잘라내기 / 붙여넣기 / 삭제 / 새 폴더)
    def ex_selected(self):
        out = []
        for ix in self.ex_view.selectionModel().selectedRows(0):
            p = self.ex_model.filePath(ix)
            if p and p not in out:
                out.append(p)
        return out

    def ex_target_dir(self):
        sel = self.ex_selected()
        if sel:
            return sel[0] if os.path.isdir(sel[0]) else os.path.dirname(sel[0])
        return self.ex_path.text().strip() or self.last_dir()

    def ex_open_tabs(self, paths):
        """열려 있는 탭의 파일(또는 그 폴더 안 파일)이 paths 에 들어 있으면 그 목록."""
        hit = []
        for p in paths:
            ap = os.path.normcase(os.path.abspath(p))
            for t in self.tabs:
                f = t.get("full")
                if not f:
                    continue
                af = os.path.normcase(os.path.abspath(f))
                if af == ap or af.startswith(ap + os.sep):
                    hit.append(os.path.basename(f))
        return hit

    def ex_menu(self, pos):
        ix = self.ex_view.indexAt(pos)
        if ix.isValid() and not self.ex_view.selectionModel().isSelected(ix):
            self.ex_view.setCurrentIndex(ix)
        sel = self.ex_selected()
        m = QMenu(self)
        a_open = m.addAction(tr("열기")); a_open.setEnabled(any(os.path.isfile(p) for p in sel))
        m.addSeparator()
        a_ren = m.addAction(tr("이름 바꾸기") + "\tF2"); a_ren.setEnabled(len(sel) == 1)
        a_copy = m.addAction(tr("복사") + "\tCtrl+C"); a_copy.setEnabled(bool(sel))
        a_cut = m.addAction(tr("잘라내기") + "\tCtrl+X"); a_cut.setEnabled(bool(sel))
        a_paste = m.addAction(tr("붙여넣기") + "\tCtrl+V"); a_paste.setEnabled(bool(self.ex_clip_paths()[1]))
        a_del = m.addAction(tr("삭제") + "\tDel"); a_del.setEnabled(bool(sel))
        m.addSeparator()
        a_new = m.addAction(tr("새 폴더") + "\tCtrl+Shift+N")
        a_cp = m.addAction(tr("경로 복사")); a_cp.setEnabled(bool(sel))
        a_ref = m.addAction(tr("새로 고침"))
        r = m.exec(self.ex_view.viewport().mapToGlobal(pos))
        if r is a_open:
            for p in sel:
                if os.path.isfile(p):
                    self.open_file(p)
        elif r is a_ren: self.ex_rename()
        elif r is a_copy: self.ex_copy(False)
        elif r is a_cut: self.ex_copy(True)
        elif r is a_paste: self.ex_paste()
        elif r is a_del: self.ex_delete()
        elif r is a_new: self.ex_newdir()
        elif r is a_cp: QApplication.clipboard().setText("\n".join(os.path.normpath(p) for p in sel))
        elif r is a_ref: self.ex_set_root(self.ex_path.text().strip())

    def ex_copy(self, cut):
        sel = self.ex_selected()
        if not sel:
            return
        if cut:
            hit = self.ex_open_tabs(sel)
            if hit:
                QMessageBox.information(self, tr("탐색기"), tr("열려 있는 문서는 옮길 수 없습니다. 탭을 먼저 닫으세요.") + "\n" + "\n".join(hit[:8])); return
        md = QMimeData()
        md.setUrls([QUrl.fromLocalFile(p) for p in sel])
        md.setData("Preferred DropEffect", QByteArray(b"\x02\x00\x00\x00" if cut else b"\x05\x00\x00\x00"))   # Windows 탐색기와 호환 (2=이동, 5=복사)
        QApplication.clipboard().setMimeData(md)
        self._ex_clip = ("cut" if cut else "copy", list(sel))
        self.statusBar().showMessage((tr("잘라냄 %d개") if cut else tr("복사함 %d개")) % len(sel))

    def ex_clip_paths(self):
        md = QApplication.clipboard().mimeData()
        paths, cut = [], False
        if md is not None and md.hasUrls():
            paths = [u.toLocalFile() for u in md.urls() if u.isLocalFile() and os.path.exists(u.toLocalFile())]
            if md.hasFormat("Preferred DropEffect"):
                b = bytes(md.data("Preferred DropEffect"))
                cut = bool(b and b[0] == 2)
            elif getattr(self, "_ex_clip", None) and sorted(self._ex_clip[1]) == sorted(paths):
                cut = self._ex_clip[0] == "cut"
        return cut, paths

    @staticmethod
    def _unique_path(d, name):
        base, ext = os.path.splitext(name)
        p = os.path.join(d, name); k = 1
        while os.path.exists(p):
            k += 1
            p = os.path.join(d, "%s - %s%s" % (base, tr("복사본") if k == 2 else "%s(%d)" % (tr("복사본"), k - 1), ext))
            if k > 999:
                break
        return p

    def ex_paste(self):
        import shutil
        cut, paths = self.ex_clip_paths()
        if not paths:
            return
        dst = self.ex_target_dir()
        if not os.path.isdir(dst):
            return
        errs, n = [], 0
        for p in paths:
            try:
                name = os.path.basename(p.rstrip("/\\"))
                same_dir = os.path.normcase(os.path.abspath(os.path.dirname(p))) == os.path.normcase(os.path.abspath(dst))
                if os.path.isdir(p) and os.path.normcase(os.path.abspath(dst)).startswith(os.path.normcase(os.path.abspath(p)) + os.sep):
                    errs.append("%s: %s" % (name, tr("자기 자신 안으로는 옮길 수 없습니다"))); continue
                if cut:
                    if same_dir:
                        continue
                    if self.ex_open_tabs([p]):
                        errs.append("%s: %s" % (name, tr("열려 있음"))); continue
                    tgt = os.path.join(dst, name)
                    if os.path.exists(tgt):
                        r = QMessageBox.question(self, tr("붙여넣기"), tr("같은 이름이 이미 있습니다. 덮어쓸까요?") + "\n" + name)
                        if r != QMessageBox.StandardButton.Yes:
                            continue
                        if os.path.isdir(tgt): shutil.rmtree(tgt)
                        else: os.remove(tgt)
                    shutil.move(p, tgt)
                else:
                    tgt = self._unique_path(dst, name)
                    if os.path.isdir(p): shutil.copytree(p, tgt)
                    else: shutil.copy2(p, tgt)
                n += 1
            except Exception as ex:
                errs.append("%s: %s" % (os.path.basename(p), ex))
        if cut and n:
            QApplication.clipboard().clear(); self._ex_clip = None
        self.statusBar().showMessage(tr("붙여넣기 %d개 완료") % n)
        if errs:
            QMessageBox.warning(self, tr("붙여넣기"), "\n".join(errs[:10]))

    def ex_rename(self):
        sel = self.ex_selected()
        if len(sel) != 1:
            return
        p = sel[0]
        if self.ex_open_tabs([p]):
            QMessageBox.information(self, tr("탐색기"), tr("열려 있는 문서는 이름을 바꿀 수 없습니다. 탭을 먼저 닫으세요.")); return
        old = os.path.basename(p)
        stem = os.path.splitext(old)[0] if os.path.isfile(p) else old
        new, ok = QInputDialog.getText(self, tr("이름 바꾸기"), tr("새 이름"), text=old)
        new = (new or "").strip()
        if not ok or not new or new == old:
            return
        if any(c in new for c in '\\/:*?"<>|'):
            QMessageBox.warning(self, tr("이름 바꾸기"), tr("이름에 쓸 수 없는 문자가 있습니다: ") + '\\ / : * ? " < > |'); return
        tgt = os.path.join(os.path.dirname(p), new)
        if os.path.exists(tgt):
            QMessageBox.warning(self, tr("이름 바꾸기"), tr("같은 이름이 이미 있습니다.")); return
        try:
            os.rename(p, tgt)
        except Exception as ex:
            QMessageBox.warning(self, tr("이름 바꾸기"), str(ex))

    def ex_delete(self):
        import shutil
        sel = self.ex_selected()
        if not sel:
            return
        hit = self.ex_open_tabs(sel)
        if hit:
            QMessageBox.information(self, tr("탐색기"), tr("열려 있는 문서는 삭제할 수 없습니다. 탭을 먼저 닫으세요.") + "\n" + "\n".join(hit[:8])); return
        names = "\n".join(os.path.basename(p) for p in sel[:10]) + ("\n…" if len(sel) > 10 else "")
        r = QMessageBox.question(self, tr("삭제"), (tr("%d개 항목을 휴지통으로 보낼까요?") % len(sel)) + "\n" + names)
        if r != QMessageBox.StandardButton.Yes:
            return
        errs = []
        for p in sel:
            try:
                if QFile.moveToTrash(p):
                    continue
                r2 = QMessageBox.question(self, tr("삭제"), tr("휴지통으로 보낼 수 없습니다. 완전히 삭제할까요?") + "\n" + os.path.basename(p))
                if r2 != QMessageBox.StandardButton.Yes:
                    continue
                if os.path.isdir(p): shutil.rmtree(p)
                else: os.remove(p)
            except Exception as ex:
                errs.append("%s: %s" % (os.path.basename(p), ex))
        if errs:
            QMessageBox.warning(self, tr("삭제"), "\n".join(errs[:10]))

    def ex_newdir(self):
        d = self.ex_target_dir()
        name, ok = QInputDialog.getText(self, tr("새 폴더"), tr("새 이름"), text=tr("새 폴더"))
        name = (name or "").strip()
        if not ok or not name:
            return
        try:
            os.makedirs(os.path.join(d, name), exist_ok=False)
        except Exception as ex:
            QMessageBox.warning(self, tr("새 폴더"), str(ex))

    # ------------------------------------------------------------------ 번역 등록
    def reg(self, fn):
        self._tr.append(fn); fn()

    def retranslate(self):
        for fn in self._tr:
            fn()
        nm = self.tabs[self.cur].get("full") and self.tabs[self.cur]["name"] if getattr(self, "tabs", None) else ""
        self.setWindowTitle("%s v%s%s" % (APP_NAME, VERSION, (" - " + nm) if nm else ""))
        self.ver_label.setText("%s v%s  |  %s: %s" % (APP_NAME, VERSION, tr("개발자"), DEVELOPER))

    # ------------------------------------------------------------------ 액션/메뉴/툴바
    def _act(self, name, key, fn, shortcut=None, tip=None, ico=None, checkable=False):
        a = QAction(self, checkable=checkable)
        if ico:
            a.setIcon(icon(ico))
        if shortcut:
            a.setShortcut(shortcut)

        def upd(a=a, key=key, tip=tip):
            a.setText(tr(key))
            if tip:
                a.setToolTip(tr(tip)); a.setStatusTip(tr(tip))
        self.reg(upd)
        a.triggered.connect(lambda _=False: fn())
        setattr(self, name, a)
        return a

    def _menu(self, key):
        m = self.menuBar().addMenu("")
        m.setToolTipsVisible(True)
        self.reg(lambda: m.setTitle(tr(key)))
        return m

    def _make_actions(self):
        S = QKeySequence
        self.ver_label = QLabel("")
        self.statusBar().addPermanentWidget(self.ver_label)
        # --- 파일
        a_new = self._act("a_new", "새로 만들기…", self.new_doc, S.StandardKey.New, ico="open")
        a_defsize = self._act("a_defsize", "기본 캔버스 크기…", self.set_default_canvas, None,
                              tip="새 도면의 기본 캔버스 크기를 설정합니다 (SVG 단위)")
        a_open = self._act("a_open", "열기 (PDF/SVG)…", self.open_file, S.StandardKey.Open, ico="open")
        a_save = self._act("a_save", "SVG 저장", self.save_svg, S.StandardKey.Save, ico="save")
        a_saveas = self._act("a_saveas", "다른 이름으로 SVG 저장…", self.save_svg_as, S("Ctrl+Shift+S"), ico="save")
        a_pdf = self._act("a_pdf", "PDF 내보내기…", self.export_pdf_dlg, S("Ctrl+E"), ico="pdf")
        a_split = self._act("a_split", "PDF 분할 / SVG 일괄 변환…", self.split_dlg, None, ico="pdf",
                            tip="여러 페이지 배선도 PDF 를 페이지별 배선도명으로 PDF 저장하고 SVG 로 변환합니다")
        a_sigexp = self._act("a_sigexp", "시그널 테이블 내보내기(엑셀)…", self.sig_export_dlg, None, ico="table",
                             tip="배선도 SVG 에서 시그널 테이블(엑셀)을 만듭니다. wire 가 없는 도면은 제외됩니다")
        a_sigupd = self._act("a_sigupd", "시그널 테이블 대조 / 도면 기준 엑셀 수정…", self.sig_update_dlg, None, ico="check",
                             tip="도면을 기준으로 기존 시그널 테이블(엑셀)을 수정합니다 (원본은 보존, 새 파일로 저장)")
        a_tclose = self._act("a_tclose", "탭 닫기", self.tab_close, S("Ctrl+W"),
                             tip="현재 탭(문서)을 닫습니다. 동시에 열 수 있는 문서 수는 설정에서 바꿀 수 있습니다")
        a_tcloseall = self._act("a_tcloseall", "전체 탭 닫기", self.tab_close_all, S("Ctrl+Shift+W"),
                                tip="열려 있는 모든 탭(문서)을 닫고 빈 도면 하나만 남깁니다")
        a_exit = self._act("a_exit", "종료", self.close, S.StandardKey.Quit)
        # --- 편집
        a_undo = self._act("a_undo", "실행 취소", self.undo, S.StandardKey.Undo, ico="undo")
        a_redo = self._act("a_redo", "다시 실행", self.redo, S.StandardKey.Redo, ico="redo")
        a_cut = self._act("a_cut", "잘라내기", self.cut, S.StandardKey.Cut, ico="cut")
        a_copy = self._act("a_copy", "복사", self.copy, S.StandardKey.Copy, ico="copy")
        a_paste = self._act("a_paste", "붙여넣기", self.paste, S.StandardKey.Paste, ico="paste")
        a_del = self._act("a_del", "삭제", self.delete_selected, S.StandardKey.Delete, ico="delete")
        a_cjk = self._act("a_cjk", "중국어 글자 삭제", self.delete_cjk, None,
                          tip="도면 안의 중국어(한자) 글자를 모두 삭제합니다. 한자와 영문이 섞인 글자는 한자 부분만 제거합니다")
        a_find = self._act("a_find", "찾기…", self.find_open, S.StandardKey.Find, ico="find",
                           tip="글자, id, meta 값을 검색하고 해당 객체로 이동합니다 (Ctrl+F)")
        a_fnext = self._act("a_fnext", "다음 찾기", lambda: self.find_next(1), S("F3"))
        a_fprev = self._act("a_fprev", "이전 찾기", lambda: self.find_next(-1), S("Shift+F3"))
        a_fcopy = self._act("a_fcopy", "서식 복사", lambda: self.fmt_copy(), S("Ctrl+Shift+C"), ico="brush",
                            tip="선택한 객체(글자)의 서식(폰트·크기·길이 등 선택한 속성)을 복사합니다")
        a_fpaste = self._act("a_fpaste", "서식 붙여넣기", self.fmt_paste, S("Ctrl+Shift+V"),
                             tip="복사한 서식을 선택한 객체에 적용합니다")
        a_fsel = self._act("a_fsel", "서식 복사 항목 선택…", self.fmt_select, None,
                           tip="선택한 객체의 속성 중 복사할 항목을 골라 서식을 복사합니다")
        a_img = self._act("a_img", "그림 삽입…", self.insert_image_file, None, ico="image", tip="그림 파일(PNG/JPG/BMP/GIF 등)을 도면에 삽입합니다. 파일을 도면으로 끌어놓아도 됩니다")
        a_imgclip = self._act("a_imgclip", "클립보드 그림 붙여넣기", self.insert_clipboard_image, None, ico="clip", tip="캡처하거나 복사한 그림을 도면에 붙여넣습니다 (그림이 클립보드에 있으면 Ctrl+V 로도 가능)")
        a_table = self._act("a_table", "표 삽입…", self.insert_table, None, ico="table", tip="행·열 수와 칸 내용을 지정해 표를 삽입합니다")
        a_tedit = self._act("a_tedit", "표 편집…", self.edit_table, None, ico="table", tip="선택한 표의 행·열 수, 칸 크기, 내용을 편집합니다")
        a_rotr = self._act("a_rotr", "오른쪽으로 90° 회전", lambda: self.obj_rotate(90), None, ico="rotate", tip="선택한 그림/도형을 시계 방향으로 90° 회전합니다")
        a_rotl = self._act("a_rotl", "왼쪽으로 90° 회전", lambda: self.obj_rotate(-90), None, ico="rotate", tip="선택한 그림/도형을 반시계 방향으로 90° 회전합니다")
        a_rota = self._act("a_rota", "각도 지정 회전…", self.obj_angle, None, ico="rotate", tip="회전 각도를 직접 입력합니다 (마우스: 위쪽 초록 핸들을 끌기, Shift: 15° 단위)")
        a_flh = self._act("a_flh", "좌우 대칭", lambda: self.obj_flip(True), None, ico="flip", tip="선택한 그림/도형을 좌우로 뒤집습니다")
        a_flv = self._act("a_flv", "상하 대칭", lambda: self.obj_flip(False), None, ico="flip", tip="선택한 그림/도형을 위아래로 뒤집습니다")
        a_osize = self._act("a_osize", "크기 및 위치…", self.obj_size, None, ico="size", tip="선택한 그림/도형의 위치, 크기, 회전, 대칭을 숫자로 지정합니다")
        a_ostyle = self._act("a_ostyle", "도형 서식…", self.obj_style, None, ico="style", tip="채우기/선 색, 선 굵기·종류, 불투명도를 지정합니다")
        a_crop = self._act("a_crop", "그림 자르기…", self.obj_crop, None, ico="image", tip="선택한 그림의 일부만 남기고 나머지를 잘라냅니다 (잘라낸 부분은 복원되지 않으므로 필요하면 되돌리기 Ctrl+Z)")
        a_ratio = self._act("a_ratio", "그림 원본 비율로", self.obj_ratio, None, ico="image", tip="선택한 그림의 높이를 원본 가로세로 비율에 맞춥니다")
        a_front = self._act("a_front", "맨 앞으로", lambda: self.obj_order("front"), None, ico="order", tip="선택한 개체를 맨 앞(맨 위)으로 가져옵니다")
        a_fwd = self._act("a_fwd", "앞으로", lambda: self.obj_order("fwd"), None, ico="order", tip="선택한 개체를 한 단계 앞으로 가져옵니다")
        a_bwd = self._act("a_bwd", "뒤로", lambda: self.obj_order("bwd"), None, ico="order", tip="선택한 개체를 한 단계 뒤로 보냅니다")
        a_back = self._act("a_back", "맨 뒤로", lambda: self.obj_order("back"), None, ico="order", tip="선택한 개체를 맨 뒤(맨 아래)로 보냅니다")
        self.shape_acts = []
        for kd, nm in SH.KINDS:
            sa = QAction(self)
            self.reg(lambda sa=sa, nm=nm: sa.setText(tr(nm)))
            sa.triggered.connect(lambda _=False, k=kd: self.shape_pick(k)); self.shape_acts.append(sa)
        self.shape_kind = "rect"
        a_all = self._act("a_all", "전체 선택", lambda: [i.setSelected(True) for i in self.items], S.StandardKey.SelectAll)
        # --- 보기
        a_fit = self._act("a_fit", "전체 보기", self.fit, S("Ctrl+0"), ico="fit")
        a_zi = self._act("a_zi", "확대", lambda: self._zoom(1.25), S.StandardKey.ZoomIn)
        a_zo = self._act("a_zo", "축소", lambda: self._zoom(0.8), S.StandardKey.ZoomOut)
        # --- 규칙
        a_chk = self._act("a_chk", "규칙 검사", self.run_check, S("F5"), ico="check",
                          tip="현재 도면이 템플릿/WDID 규칙을 지키는지 검사하여 오류·경고 목록을 보여줍니다 (도면은 변경하지 않음)")
        a_fix = self._act("a_fix", "자동 수정", self.run_fix, S("F6"), ico="fix",
                          tip="'자동수정 가능' 항목을 고칩니다: ref 접미 제거, 누락 meta 보충, 별도 id 의 splice/twist 와 흩어진 text 병합 등")
        a_auto = self._act("a_auto", "이미지 네비게이션 ID 재생성", self.run_auto, None, ico="auto",
                           tip="각 부품의 이미지 뷰어 링크용 네비게이션 블록(id 100번대)을 삭제 후 다시 생성합니다 (component/inline/reference 의 ref 와 글자 속 숫자/숫자 WDID)")
        a_help = self._act("a_help", "규칙 설명…", self.show_rule_help, S("F1"), ico="help")
        a_about = self._act("a_about", "WD Studio 정보…", self.show_about, None, ico="info")
        a_lic = self._act("a_lic", "라이선스 정보…", lambda: QMessageBox.information(self, tr("라이선스"), __import__("licensing").info_text()), None)

        mb = self.menuBar()
        m = self._menu("파일"); [m.addAction(x) for x in (a_new, a_open, a_save, a_saveas, a_pdf)]; m.addSeparator(); m.addAction(a_split); m.addSeparator(); m.addAction(a_tclose); m.addAction(a_tcloseall); m.addAction(a_exit)
        m = self._menu("편집"); [m.addAction(x) for x in (a_undo, a_redo)]; m.addSeparator(); [m.addAction(x) for x in (a_cut, a_copy, a_paste, a_del)]; m.addSeparator(); [m.addAction(x) for x in (a_find, a_fnext, a_fprev)]; m.addSeparator(); m.addAction(a_cjk); m.addAction(a_all); m.addSeparator(); [m.addAction(x) for x in (a_fcopy, a_fpaste, a_fsel)]
        m = self._menu("보기"); [m.addAction(x) for x in (a_fit, a_zi, a_zo)]; self.view_menu = m
        self.ins_menu = self._menu("삽입")
        self.draw_menu = self._menu("그리기")
        self.obj_menu = self._menu("개체")
        m = self._menu("규칙"); [m.addAction(x) for x in (a_chk, a_fix, a_auto)]
        m = self._menu("도구"); m.addAction(a_sigexp); m.addAction(a_sigupd)
        m = self._menu("설정")
        m.addAction(a_defsize)
        a_acjk = QAction(tr("PDF 변환 시 중국어 자동 삭제"), self, checkable=True); a_acjk.setChecked(bool(i18n.get_setting("strip_cjk", True)))
        a_acjk.toggled.connect(lambda v: i18n.set_setting("strip_cjk", bool(v)))
        self.reg(lambda: a_acjk.setText(tr("PDF 변환 시 중국어 자동 삭제"))); m.addAction(a_acjk)
        a_aocr = QAction(tr("PDF 변환 시 글자 그림 OCR 복원"), self, checkable=True); a_aocr.setChecked(bool(i18n.get_setting("ocr_bitmap_text", True)))
        a_aocr.toggled.connect(lambda v: i18n.set_setting("ocr_bitmap_text", bool(v)))
        self.reg(lambda: a_aocr.setText(tr("PDF 변환 시 글자 그림 OCR 복원"))); m.addAction(a_aocr)
        fm_ = m.addMenu(""); self.reg(lambda: fm_.setTitle(tr("글자 크기")))
        fg = QActionGroup(self); cur = self.ui_font_size()
        for pt in (9, 10, 11, 12, 13, 14, 16, 18, 20):
            a = QAction("%d pt" % pt, self, checkable=True); a.setChecked(pt == cur); fg.addAction(a); fm_.addAction(a)
            a.triggered.connect(lambda _=False, p=pt: self.set_ui_font(p))
        mt_ = m.addMenu(""); self.reg(lambda: mt_.setTitle(tr("최대 문서 수")))
        mg = QActionGroup(self); curmt = self.MAX_TABS
        for nmt in sorted({3, 5, 8, 10, 15, 20, 30, curmt}):
            a = QAction("%d" % nmt, self, checkable=True); a.setChecked(nmt == curmt); mg.addAction(a); mt_.addAction(a)
            a.triggered.connect(lambda _=False, n=nmt: self.set_max_tabs(n))
        sm_ = m.addMenu(""); self.reg(lambda: sm_.setTitle(tr("스크롤바 두께")))
        sg = QActionGroup(self); cursb = int(i18n.get_setting("sb_width", 18) or 18)
        for px in (12, 16, 18, 22, 26, 30):
            a = QAction("%d px" % px, self, checkable=True); a.setChecked(px == cursb); sg.addAction(a); sm_.addAction(a)
            a.triggered.connect(lambda _=False, p=px: self.set_scrollbar(p))
        lm = m.addMenu(""); self.reg(lambda: lm.setTitle(tr("언어 / Language"))); lm.setIcon(icon("lang"))
        g = QActionGroup(self)
        for code, key in (("ko", "한국어"), ("en", "English")):
            a = QAction(key, self, checkable=True); a.setChecked(i18n.LANG == code); g.addAction(a); lm.addAction(a)
            a.triggered.connect(lambda _=False, c=code: self.set_language(c))
        m = self._menu("도움말"); m.addAction(a_help); m.addAction(a_lic); m.addAction(a_about)

        # --- 툴바 (아이콘 + 텍스트)
        def mk_tb(key):
            tb = QToolBar(self); tb.setObjectName("tb_" + key); tb.setMovable(False); tb.setIconSize(QSize(22, 22))
            tb.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
            self.reg(lambda: tb.setWindowTitle(tr(key)))
            return tb
        tb = mk_tb("파일 도구"); self.addToolBar(tb); [tb.addAction(x) for x in (a_new, a_open, a_save, a_pdf)]
        tb.addSeparator(); [tb.addAction(x) for x in (a_undo, a_redo)]
        tb.addSeparator(); [tb.addAction(x) for x in (a_cut, a_copy, a_paste, a_del)]
        tb.addSeparator(); [tb.addAction(x) for x in (a_find, a_chk, a_fix, a_fit)]
        self.addToolBarBreak()
        tb2 = mk_tb("그리기 도구"); self.addToolBar(tb2)
        grp = QActionGroup(self); self.tool_actions = {}

        def tool_act(key, label, tip, ico):
            a = QAction(self, checkable=True); a.setIcon(icon(ico))
            self.reg(lambda a=a: (a.setText(tr(label)), a.setToolTip(tr(tip)), a.setStatusTip(tr(tip))))
            a.triggered.connect(lambda _=False, k=key: self.set_tool(k))
            grp.addAction(a); self.tool_actions[key] = a
            return a
        # 선택/이동 드롭다운 (예시 화면과 동일)
        sel = tool_act("select", "선택", "선택: 클릭/드래그로 요소 선택, 선택 후 드래그하면 요소 이동", "select")
        pan = tool_act("pan", "이동", "이동(Pan): 마우스 드래그로 화면을 이동 (마우스 가운데 버튼 드래그도 가능)", "pan")
        tb2.addAction(sel); tb2.addAction(pan); tb2.addSeparator()         # 선택 / 이동 : 드롭다운 없이 나란히 독립 버튼
        self.tool_actions["select"].setChecked(True)
        for key, label, tip, ico in [("wire", "Wire", "클릭으로 꺾임점 추가, 더블클릭/Enter 로 완료", "wire"),
                                      ("component", "Component", "드래그하여 사각형 생성", "component"),
                                      ("inline", "Inline", "wire 위를 클릭 (Shift: 세로)", "inline"),
                                      ("reference", "Reference", "클릭하여 reference connector 추가", "reference"),
                                      ("sp", "Splice(SP)", "wire 끝점 근처 클릭", "sp"),
                                      ("twist", "Twist", "wire 사이를 클릭 (왼쪽-위 모서리)", "twist"),
                                      ("unshielded", "Unshielded", "wire 사이를 클릭", "unshielded"),
                                      ("text", "Text", "클릭하여 일반 텍스트 추가", "text"),
                                      ("fmt", "서식 브러시", "서식 브러시: 먼저 원본 객체를 선택한 뒤 이 도구를 켜고, 서식을 적용할 객체를 클릭 (Esc: 종료)", "brush")]:
            a = tool_act(key, label, tip, ico); tb2.addAction(a); self.draw_menu.addAction(a)
        self.draw_menu.insertAction(self.draw_menu.actions()[0], sel); self.draw_menu.insertAction(self.draw_menu.actions()[1], pan)
        self.draw_menu.insertSeparator(self.draw_menu.actions()[2])

        # ---- 삽입 도구 모음 (그림/도형/표/회전/서식/순서)
        self.addToolBarBreak()
        tb3 = mk_tb("삽입 도구"); self.addToolBar(tb3)
        tb3.addAction(a_img); tb3.addAction(a_imgclip)
        shape_act = tool_act("shape", "도형", "도형: 종류를 고른 뒤 도면에서 드래그하여 그립니다 (Shift: 정사각형/45°, 클릭만 하면 기본 크기, Esc/오른쪽 클릭: 종료)", "shapes")
        sbtn = QToolButton(); sbtn.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup); sbtn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        smenu = QMenu(self)
        for sa in self.shape_acts:
            smenu.addAction(sa)
        sbtn.setMenu(smenu); sbtn.setDefaultAction(shape_act)
        shape_act.triggered.connect(lambda _=False: self.shape_pick(self.shape_kind))
        tb3.addWidget(sbtn)
        tb3.addAction(a_table); tb3.addSeparator()

        def menu_btn(label, ico, acts_):
            b = QToolButton(); b.setIcon(icon(ico)); b.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
            b.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
            mm = QMenu(self)
            for x in acts_:
                mm.addSeparator() if x is None else mm.addAction(x)
            b.setMenu(mm); self.reg(lambda: b.setText(tr(label)))
            tb3.addWidget(b)
        menu_btn("회전/대칭", "rotate", [a_rotr, a_rotl, a_rota, None, a_flh, a_flv])
        tb3.addAction(a_osize); tb3.addAction(a_ostyle); tb3.addAction(a_crop)
        menu_btn("순서", "order", [a_front, a_fwd, a_bwd, a_back])

        # ---- 메뉴: 삽입 / 개체
        for x in (a_img, a_imgclip):
            self.ins_menu.addAction(x)
        shm = self.ins_menu.addMenu(""); self.reg(lambda: shm.setTitle(tr("도형")))
        for sa in self.shape_acts:
            shm.addAction(sa)
        self.ins_menu.addAction(a_table); self.ins_menu.addAction(self.tool_actions["text"])
        rm = self.obj_menu.addMenu(""); self.reg(lambda: rm.setTitle(tr("회전/대칭")))
        for x in (a_rotr, a_rotl, a_rota, a_flh, a_flv):
            rm.addAction(x)
        for x in (a_osize, a_ostyle, a_crop, a_ratio):
            self.obj_menu.addAction(x)
        om = self.obj_menu.addMenu(""); self.reg(lambda: om.setTitle(tr("순서")))
        for x in (a_front, a_fwd, a_bwd, a_back):
            om.addAction(x)
        self.obj_menu.addSeparator(); self.obj_menu.addAction(a_tedit)

    def _make_docks(self):
        # ---- 요소 목록 / SVG 코드 (DevTools 형)
        self.tree = CodeTree()
        self.tree.itemExpanded.connect(self.tree_expand)
        self.tree.itemSelectionChanged.connect(self.on_tree_selection)
        self.tree.dropped.connect(self.on_tree_drop)
        self.tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self.tree_menu)
        d = QDockWidget(self); d.setWidget(self.tree); d.setObjectName("dock_tree")
        self.reg(lambda: d.setWindowTitle(tr("요소 목록 / SVG 코드")))
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, d)
        self.resizeDocks([d], [520], Qt.Orientation.Horizontal)
        # ---- 속성
        w = QWidget(); l = QVBoxLayout(w)
        self.sel_label = QLabel(""); l.addWidget(self.sel_label)
        self.props = QTabWidget()
        mw = QWidget(); ml = QVBoxLayout(mw); ml.setContentsMargins(2, 2, 2, 2)
        self.meta_tbl = QTableWidget(0, 2); self.meta_tbl.horizontalHeader().setStretchLastSection(True)
        self.meta_tbl.cellChanged.connect(self.meta_changed)
        hb = QHBoxLayout(); self.b_madd = QPushButton(); self.b_mdel = QPushButton()
        self.b_madd.clicked.connect(self.add_meta_row); self.b_mdel.clicked.connect(self.del_meta_row)
        hb.addWidget(self.b_madd); hb.addWidget(self.b_mdel)
        ml.addLayout(hb); ml.addWidget(self.meta_tbl)
        vw = QWidget(); vl = QVBoxLayout(vw); vl.setContentsMargins(2, 2, 2, 2)
        self.prim_list = QListWidget(); self.prim_list.setMaximumHeight(150)
        self.prim_list.currentRowChanged.connect(self.prim_list_changed)
        self.attr_tbl = QTableWidget(0, 2); self.attr_tbl.horizontalHeader().setStretchLastSection(True)
        self.attr_tbl.cellChanged.connect(self.attr_changed)
        hb2 = QHBoxLayout(); self.b_aadd = QPushButton(); self.b_adel = QPushButton()
        self.b_aadd.clicked.connect(self.add_attr_row); self.b_adel.clicked.connect(self.del_attr_row)
        hb2.addWidget(self.b_aadd); hb2.addWidget(self.b_adel)
        vl.addWidget(self.prim_list); vl.addLayout(hb2); vl.addWidget(self.attr_tbl)
        self.props.addTab(vw, ""); self.props.addTab(mw, "")
        l.addWidget(self.props)
        d2 = QDockWidget(self); d2.setWidget(w); d2.setObjectName("dock_props")
        self.reg(lambda: (d2.setWindowTitle(tr("속성")), self.props.setTabText(0, tr("visible data")), self.props.setTabText(1, tr("metadata")),
                          self.meta_tbl.setHorizontalHeaderLabels([tr("meta"), tr("값")]), self.attr_tbl.setHorizontalHeaderLabels([tr("속성명"), tr("값")]),
                          self.b_madd.setText(tr("meta 추가")), self.b_mdel.setText(tr("meta 삭제")),
                          self.b_aadd.setText(tr("속성 추가")), self.b_adel.setText(tr("속성 삭제"))))
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, d2)
        # ---- 규칙 검사
        w2 = QWidget(); l2 = QVBoxLayout(w2)
        h = QHBoxLayout()
        for attr, key, fn in (("b_chk", "검사", self.run_check), ("b_fix", "자동수정", self.run_fix), ("b_auto", "이미지 네비게이션 ID 생성", self.run_auto), ("b_help", "규칙 설명", self.show_rule_help)):
            b = QPushButton(); b.clicked.connect(lambda _=False, f=fn: f()); h.addWidget(b); setattr(self, attr, b)
            self.reg(lambda b=b, key=key: b.setText(tr(key)))
        self.b_chk.setToolTip(""); l2.addLayout(h)
        self.issue_list = QListWidget(); self.issue_list.itemDoubleClicked.connect(self.goto_issue)
        l2.addWidget(self.issue_list)
        self.summary = QLabel(""); l2.addWidget(self.summary)
        d3 = QDockWidget(self); d3.setWidget(w2); d3.setObjectName("dock_rules")
        self.reg(lambda: d3.setWindowTitle(tr("규칙 검사 패널")))
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, d3)
        # ---- 코드 편집
        w3 = QWidget(); l3 = QVBoxLayout(w3)
        self.code_hint = QLabel(""); l3.addWidget(self.code_hint)
        self.code = QPlainTextEdit(); f = QFont(MONO, 9); f.setStyleHint(QFont.StyleHint.Monospace); self.code.setFont(f)
        self.code.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap); l3.addWidget(self.code)
        hb3 = QHBoxLayout(); self.b_apply = QPushButton(); self.b_revert = QPushButton()
        self.b_apply.clicked.connect(self.apply_code); self.b_revert.clicked.connect(self.show_code)
        hb3.addWidget(self.b_apply); hb3.addWidget(self.b_revert); l3.addLayout(hb3)
        d4 = QDockWidget(self); d4.setWidget(w3); d4.setObjectName("dock_code")
        self.reg(lambda: (d4.setWindowTitle(tr("코드 편집")), self.b_apply.setText(tr("적용")), self.b_revert.setText(tr("되돌리기")),
                          self.code_hint.setText(tr("선택한 그룹(id)의 SVG 코드를 직접 수정하고 [적용]을 누르세요"))))
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, d4)
        self.resizeDocks([d4], [220], Qt.Orientation.Vertical)
        self.scene.selectionChanged.connect(self.on_scene_selection)

    def reset_docks(self):
        """닫히거나 흩어진 패널을 기본 배치로 복원."""
        for dk in self.findChildren(QDockWidget):
            dk.setFloating(False); dk.show()
        try: self.restoreState(self._default_dock_state)
        except Exception: pass
        for dk in self.findChildren(QDockWidget): dk.show()

    # ------------------------------------------------------------------ 언어 / 도움말
    def set_language(self, code):
        i18n.set_lang(code)
        self.retranslate()
        self.refresh_all()
        self.run_check() if self.issue_list.count() else None

    def show_about(self):
        dlg = QDialog(self); dlg.setWindowTitle(tr("정보"))
        l = QVBoxLayout(dlg)
        lab = QLabel("<h2>%s</h2><p>%s</p><table><tr><td><b>%s</b></td><td>&nbsp;%s</td></tr><tr><td><b>%s</b></td><td>&nbsp;%s</td></tr>"
                     "<tr><td><b>%s</b></td><td>&nbsp;%s</td></tr></table>" % (
                         APP_NAME, tr("PDF 배선도를 배선도 템플릿/WDID 규칙에 맞는 SVG 로 변환하고 편집하는 도구"),
                         tr("버전"), "v" + VERSION, tr("빌드 날짜"), BUILD_DATE, tr("개발자"), DEVELOPER))
        lab.setTextFormat(Qt.TextFormat.RichText); l.addWidget(lab)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Close); bb.rejected.connect(dlg.reject); bb.accepted.connect(dlg.accept)
        bb.button(QDialogButtonBox.StandardButton.Close).clicked.connect(dlg.accept); l.addWidget(bb)
        dlg.exec()

    def show_rule_help(self):
        dlg = QDialog(self); dlg.setWindowTitle(tr("규칙 설명")); dlg.resize(780, 620)
        l = QVBoxLayout(dlg); t = QPlainTextEdit(); t.setReadOnly(True); t.setPlainText(rules.RULE_HELP["en" if i18n.LANG == "en" else "ko"])
        l.addWidget(t); bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Close); bb.button(QDialogButtonBox.StandardButton.Close).clicked.connect(dlg.accept); l.addWidget(bb)
        dlg.exec()

    # ------------------------------------------------------------------ 장면
    def rebuild(self):
        self._busy = True
        sel = {i.grp.gid for i in self.items if i.isSelected()}
        self.scene.clear(); self.overlays = []
        self.items = []; self.by_gid = {}
        vb = self.doc.viewbox
        page = QRectF(vb[0], vb[1], vb[2], vb[3]); self.page_rect = page
        m = max(page.width(), page.height()) * 1.0                       # 용지 주변 작업 여백
        self.scene.setSceneRect(page.adjusted(-m, -m, m, m))
        sh = self.scene.addRect(page.translated(7, 7), QPen(Qt.PenStyle.NoPen), QBrush(QColor(0, 0, 0, 60))); sh.setZValue(-102)
        pen = QPen(QColor("#1a73e8"), 3); pen.setCosmetic(True)
        pg = self.scene.addRect(page, pen, QBrush(Qt.GlobalColor.white)); pg.setZValue(-101)   # 용지(캔버스) 경계
        lab = self.scene.addSimpleText("%s  %.0f × %.0f" % (tr("캔버스"), page.width(), page.height()))
        lab.setBrush(QBrush(QColor("#1a73e8"))); lab.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations, True)
        lab.setPos(page.left(), page.top()); lab.setTransform(QTransform().translate(0, -20)); lab.setZValue(-100)
        self.handles = []
        for k in ("nw", "n", "ne", "e", "se", "s", "sw", "w"):
            h = PageHandle(self, k); self.scene.addItem(h); self.handles.append(h)
        self.place_handles()
        for g in self.doc.groups:
            if self.is_page_bg(g):
                continue
            it = GroupItem(g, self)
            it.setZValue(-1 if g.kind == "component" else (-2 if g.cls == "rectangle" else 0))
            self.scene.addItem(it); self.items.append(it); self.by_gid[g.gid] = it
            if g.gid in sel:
                it.setSelected(True)
        self.apply_item_flags()
        self.populate_tree()
        self._busy = False
        self.refresh_all()

    def is_page_bg(self, g):
        """용지 배경/격자용 그룹(화면에 그리지 않음). 눈에 보이는 프레임 사각형(rectangle)은 그린다."""
        if g.cls == "xygrid":
            return True
        if g.cls != "rectangle":
            return False
        pr = self.page_rect
        for p in g.prims:
            if p.tag != "rect":
                continue
            a = p.attrs
            try:
                full = float(a.get("width", 0)) >= pr.width() * 0.97 and float(a.get("height", 0)) >= pr.height() * 0.97
            except ValueError:
                full = False
            st = a.get("stroke", "none").lower(); fl = a.get("fill", "none").lower()
            vis = (st not in ("none", "#ffffff", "white")) or (fl not in ("none", "#ffffff", "white"))
            if full or not vis:
                return True
        return False

    def rebuild_group(self, gid):
        old = self.by_gid.get(gid)
        g = next((x for x in self.doc.groups if x.gid == gid), None)
        if g is None:
            return self.rebuild()
        if old is None:                       # 화면에 그려지지 않는 그룹(rectangle/xygrid)
            self.refresh_tree_group(g); return
        self._busy = True
        was = old.isSelected(); z = old.zValue(); idx = self.items.index(old)
        self.scene.removeItem(old)
        it = GroupItem(g, self); it.setZValue(z); self.scene.addItem(it)
        self.items[idx] = it; self.by_gid[gid] = it
        it.setSelected(was); self.apply_item_flags()
        self.refresh_tree_group(g)
        self._busy = False
        self.refresh_overlays()

    # ------------------------------------------------------------------ 캔버스 크기 조절 (마우스)
    def place_handles(self, rect=None):
        r = rect or self.page_rect
        xs = {"w": r.left(), "e": r.right(), "n": r.center().x(), "s": r.center().x()}
        for h in getattr(self, "handles", []):
            k = h.kind
            x = r.left() if "w" in k else (r.right() if "e" in k else r.center().x())
            y = r.top() if "n" in k else (r.bottom() if "s" in k else r.center().y())
            h.setPos(x, y)
            h.setVisible(self.tool == "select")

    def canvas_drag_start(self, kind):
        self._cd_kind = kind; self.auto_fit = False
        self._cd_rect = QRectF(self.page_rect); self._cd_prev = None

    def _cd_new_rect(self, p):
        r = QRectF(self.page_rect); k = self._cd_kind; mn = 100.0
        x, y = round(p.x()), round(p.y())
        if "w" in k: r.setLeft(min(x, r.right() - mn))
        if "e" in k: r.setRight(max(x, r.left() + mn))
        if "n" in k: r.setTop(min(y, r.bottom() - mn))
        if "s" in k: r.setBottom(max(y, r.top() + mn))
        return r

    def canvas_drag_move(self, p):
        r = self._cd_new_rect(p); self._cd_rect = r
        if self._cd_prev is not None:
            self.scene.removeItem(self._cd_prev)
        pen = QPen(QColor("#1a73e8"), 2, Qt.PenStyle.DashLine); pen.setCosmetic(True)
        self._cd_prev = self.scene.addRect(r, pen, QBrush(QColor(26, 115, 232, 25))); self._cd_prev.setZValue(2500)
        self._cd_prev.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
        self.place_handles(r)
        self.statusBar().showMessage("%s %.0f × %.0f" % (tr("캔버스"), r.width(), r.height()))

    def canvas_drag_end(self, p):
        r = self._cd_new_rect(p)
        if self._cd_prev is not None:
            self.scene.removeItem(self._cd_prev); self._cd_prev = None
        self.apply_canvas_rect(r)

    def apply_canvas_rect(self, r: QRectF):
        pr = self.page_rect
        if abs(r.width() - pr.width()) < 0.5 and abs(r.height() - pr.height()) < 0.5 and abs(r.left()) < 0.5 and abs(r.top()) < 0.5:
            self.place_handles(); return
        self.push_undo()
        dx, dy = -r.left(), -r.top()                       # 왼쪽/위쪽을 늘리면 내용을 같은 만큼 밀어서 위치 유지
        nw, nh = r.width(), r.height()
        for g in self.doc.groups:
            if self.is_page_bg(g):
                for p in g.prims:
                    if p.tag == "rect":
                        p.attrs["width"] = fmt(nw - 0.2325); p.attrs["height"] = fmt(nh - 0.3765)
                g.dirty()
            elif abs(dx) > 1e-9 or abs(dy) > 1e-9:
                g.translate(dx, dy)
        self.doc.viewbox = [0.0, 0.0, float(fmt(nw)), float(fmt(nh))]
        self.sel_prims = []
        self.rebuild()
        self.statusBar().showMessage("%s %s × %s" % (tr("캔버스"), fmt(nw), fmt(nh)))

    def _zoom(self, f):
        self.auto_fit = False; self.view.scale(f, f)

    def apply_item_flags(self):
        sel = self.tool == "select"
        for h in getattr(self, "handles", []):
            h.setVisible(sel)
        for i in self.items:
            i.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, sel)
            i.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, sel)
            i.setAcceptedMouseButtons(Qt.MouseButton.LeftButton if sel else Qt.MouseButton.NoButton)

    def fit(self, auto=False):
        self.auto_fit = True
        p = self.page_rect; pad = max(p.width(), p.height()) * 0.3
        self.view.resetTransform()
        self.view.fitInView(p.adjusted(-pad, -pad, pad, pad), Qt.AspectRatioMode.KeepAspectRatio)

    # ------------------------------------------------------------------ 선택 강조
    def refresh_overlays(self):
        for o in self.overlays:
            if o.scene() is not None:
                self.scene.removeItem(o)
        self.overlays = []
        for it in self.items:
            if it.isSelected():
                self._overlay(it.sceneBoundingRect(), "g#id-%d.%s" % (it.grp.gid, it.grp.cls), QColor(26, 115, 232, 70), QColor(26, 115, 232))
        for gid, k in self.sel_prims:
            it = self.by_gid.get(gid)
            if it and k < len(it.prim_items) and it.prim_items[k] is not None:
                p = it.grp.prims[k]
                self._overlay(it.prim_items[k].sceneBoundingRect(), "%s #%d" % (p.tag, k), QColor(255, 152, 0, 110), QColor(230, 110, 0))
        self.place_text_handles()
        self.place_obj_handles()

    # ------------------------------------------------------------------ 글자 길이/크기 마우스 조절
    def _single_text(self):
        """(group, index, prim) : 글자 1개만 선택된 경우."""
        if len(self.sel_prims) == 1:
            gid, k = self.sel_prims[0]; it = self.by_gid.get(gid)
            if it and k < len(it.grp.prims) and it.grp.prims[k].tag == "text":
                return it.grp, k, it.grp.prims[k]
            return None
        if not self.sel_prims:
            gs = [i for i in self.items if i.isSelected()]
            if len(gs) == 1:
                tp = [(k, p) for k, p in enumerate(gs[0].grp.prims) if p.tag == "text"]
                if len(tp) == 1 and len(gs[0].grp.prims) == 1:
                    return gs[0].grp, tp[0][0], tp[0][1]
        return None

    def place_text_handles(self):
        for h in getattr(self, "thandles", []):
            try:
                if h.scene() is not None:
                    self.scene.removeItem(h)
            except RuntimeError:
                pass
        self.thandles = []
        st = self._single_text()
        if st is None or self.tool != "select":
            return
        g, k, p = st
        it = self.by_gid.get(g.gid)
        if it is None or k >= len(it.prim_items) or it.prim_items[k] is None:
            return
        r = it.prim_items[k].sceneBoundingRect()
        for kind, pos in (("e", QPointF(r.right(), r.center().y())), ("s", QPointF(r.center().x(), r.bottom())), ("se", QPointF(r.right(), r.bottom()))):
            h = TextHandle(self, kind); h.setPos(pos); self.scene.addItem(h); self.thandles.append(h)

    def text_drag_start(self, kind, pos):
        st = self._single_text()
        if st is None:
            return
        g, k, p = st
        a = p.attrs
        self._td = dict(kind=kind, gid=g.gid, k=k, p0=pos, L0=float(a.get("textLength", 20)) or 20.0, fs0=float(a.get("font-size", 8)),
                        x0=float(a["x"]), y0=float(a["y"]), end=a.get("text-anchor") == "end")
        pen = QPen(QColor("#e65100"), 1.5, Qt.PenStyle.DashLine); pen.setCosmetic(True)
        it = self.by_gid[g.gid].prim_items[k]
        self._td_box = self.scene.addRect(it.sceneBoundingRect(), pen, QBrush(Qt.BrushStyle.NoBrush)); self._td_box.setZValue(3050)
        self._td_r0 = it.sceneBoundingRect()

    def _td_calc(self, pos, d=None):
        d = d or self._td; dx = pos.x() - d["p0"].x(); dy = pos.y() - d["p0"].y()
        L, fs = d["L0"], d["fs0"]
        if d["kind"] == "e":
            L = max(2.0, d["L0"] + dx)
        elif d["kind"] == "s":
            fs = max(1.0, d["fs0"] + dy / 1.25)
        else:
            f = max(0.1, (d["L0"] + dx) / d["L0"]); L = d["L0"] * f; fs = max(1.0, d["fs0"] * f)
        return L, fs

    def text_drag_move(self, pos):
        d = getattr(self, "_td", None)
        if not d:
            return
        L, fs = self._td_calc(pos); r0 = self._td_r0
        w = L; h = fs * 1.25
        x = r0.left() if not d["end"] else r0.right() - w
        self._td_box.setRect(QRectF(x, r0.top(), w, h))
        self.statusBar().showMessage("%s %.1f   %s %.2f" % (tr("글자 길이"), L, tr("글자 크기"), fs))

    def text_drag_end(self, pos):
        d = getattr(self, "_td", None)
        if not d:
            return
        self._td = None
        if self._td_box.scene() is not None:
            self.scene.removeItem(self._td_box)
        L, fs = self._td_calc(pos, d)
        if abs(L - d["L0"]) < 0.01 and abs(fs - d["fs0"]) < 0.01:
            return
        g = next((x for x in self.doc.groups if x.gid == d["gid"]), None)
        if g is None or d["k"] >= len(g.prims):
            return
        self.push_undo()
        p = g.prims[d["k"]]
        y = d["y0"] - d["fs0"] + fs                        # 글자 윗변 위치 유지
        p.attrs["textLength"] = fmt(L); p.attrs["font-size"] = fmt(fs); p.attrs["y"] = fmt(y)
        import re as _re
        m = _re.match(r"rotate\(([-\d.]+),", p.attrs.get("transform", "")); ang = m.group(1) if m else "0"
        p.attrs["transform"] = "rotate(%s,%s,%s)" % (ang, p.attrs["x"], p.attrs["y"])
        g.dirty()
        self.rebuild_group(g.gid)
        self.refresh_all()
        self.statusBar().showMessage("%s %s   %s %s" % (tr("글자 길이"), fmt(L), tr("글자 크기"), fmt(fs)))

    def _overlay(self, r: QRectF, label, fill, line):
        r = r.adjusted(-1.5, -1.5, 1.5, 1.5)
        pen = QPen(line, 2); pen.setCosmetic(True)
        box = self.scene.addRect(r, pen, QBrush(fill)); box.setZValue(2000); box.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
        chip = QGraphicsRectItem(0, 0, 10, 10); chip.setZValue(2001)
        txt = QGraphicsSimpleTextItem("%s   %.2f × %.2f" % (label, r.width() - 3, r.height() - 3), chip)
        f = QFont("Arial", 9); f.setBold(True); txt.setFont(f); txt.setBrush(QBrush(line.darker(130))); txt.setPos(4, 1)
        br = txt.boundingRect(); chip.setRect(0, 0, br.width() + 8, br.height() + 2)
        chip.setBrush(QBrush(QColor(255, 255, 255, 240))); cp = QPen(line, 1); cp.setCosmetic(True); chip.setPen(cp)
        chip.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations, True)
        chip.setPos(r.left(), r.top()); chip.setTransform(QTransform().translate(0, -chip.rect().height() - 3))
        chip.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
        self.scene.addItem(chip)
        self.overlays += [box, chip]

    # ------------------------------------------------------------------ 트리 (SVG 코드)
    def populate_tree(self):
        self.tree.blockSignals(True)
        self.tree.clear()
        for g in self.doc.groups:
            self.tree.addTopLevelItem(self._group_node(g))
        self.tree.blockSignals(False)

    def _node(self, plain, token):
        it = QTreeWidgetItem([plain]); it.setData(0, Qt.ItemDataRole.UserRole, token)
        it.setData(0, Qt.ItemDataRole.UserRole + 1, code_html(plain))
        it.setFlags(it.flags() | Qt.ItemFlag.ItemIsDragEnabled | Qt.ItemFlag.ItemIsDropEnabled)
        return it

    def _group_node(self, g: Group):
        label = g.get("ref", "") or ""
        it = self._node(_grp_open(g), ("g", g.gid))
        if g.meta or g.prims:
            it.addChild(QTreeWidgetItem(["…"]))
        return it

    def _fill_group(self, it: QTreeWidgetItem):
        gid = it.data(0, Qt.ItemDataRole.UserRole)[1]
        g = next((x for x in self.doc.groups if x.gid == gid), None)
        it.takeChildren()
        if g is None:
            return
        if g.meta:
            mn = self._node("<metadata>", ("metadata", gid))
            for k, (n, v, c) in enumerate(g.meta):
                mn.addChild(self._node('<meta name="%s">%s</meta>' % (n, ("<![CDATA[%s]]>" % v) if c else v), ("meta", gid, k)))
            it.addChild(mn)
        for k, p in enumerate(g.prims):
            it.addChild(self._node(p.to_xml(), ("prim", gid, k)))

    def tree_expand(self, item):
        if item.childCount() == 1 and item.child(0).data(0, Qt.ItemDataRole.UserRole) is None and item.data(0, Qt.ItemDataRole.UserRole):
            tok = item.data(0, Qt.ItemDataRole.UserRole)
            if tok[0] == "g":
                self.tree.blockSignals(True); self._fill_group(item); self.tree.blockSignals(False)

    def refresh_tree_group(self, g: Group):
        it = self._tree_group_item(g.gid)
        if it is None:
            return
        was = it.isExpanded()
        self.tree.blockSignals(True)
        it.setText(0, _grp_open(g)); it.setData(0, Qt.ItemDataRole.UserRole + 1, code_html(_grp_open(g)))
        it.takeChildren()
        if g.meta or g.prims:
            it.addChild(QTreeWidgetItem(["…"]))
        if was:
            self._fill_group(it)
        self.tree.blockSignals(False)

    def _tree_group_item(self, gid):
        for r in range(self.tree.topLevelItemCount()):
            it = self.tree.topLevelItem(r)
            if it.data(0, Qt.ItemDataRole.UserRole)[1] == gid:
                return it
        return None

    def _tree_prim_item(self, gid, k):
        it = self._tree_group_item(gid)
        if it is None:
            return None
        if not it.isExpanded():
            self.tree.blockSignals(True); it.setExpanded(True); self._fill_group(it); self.tree.blockSignals(False)
        for r in range(it.childCount()):
            c = it.child(r)
            if c.data(0, Qt.ItemDataRole.UserRole) == ("prim", gid, k):
                return c
        return None

    def sync_tree_selection(self):
        self.tree.blockSignals(True)
        self.tree.clearSelection()
        first = None
        if self.sel_prims:
            for gid, k in self.sel_prims:
                c = self._tree_prim_item(gid, k)
                if c is not None:
                    c.setSelected(True); first = first or c
        else:
            for gid in [i.grp.gid for i in self.items if i.isSelected()] + sorted(self.extra_gids):
                n = self._tree_group_item(gid)
                if n is not None:
                    n.setSelected(True); first = first or n
        if first is not None:
            self.tree.scrollToItem(first)
        self.tree.blockSignals(False)

    def tree_menu(self, pos):
        m = QMenu(self)
        for a in (self.a_cut, self.a_copy, self.a_paste, self.a_del):
            m.addAction(a)
        m.exec(self.tree.viewport().mapToGlobal(pos))

    def on_tree_selection(self):
        if self._busy:
            return
        toks = [i.data(0, Qt.ItemDataRole.UserRole) for i in self.tree.selectedItems() if i.data(0, Qt.ItemDataRole.UserRole)]
        gids = {t[1] for t in toks}
        self.sel_prims = [(t[1], t[2]) for t in toks if t[0] == "prim"]
        self.extra_gids = {g for g in gids if g not in self.by_gid}
        self._busy = True
        for it in self.items:
            it.setSelected(it.grp.gid in gids)
        self._busy = False
        self.refresh_all(sync_tree=False)
        its = [i for i in self.items if i.isSelected()]
        if its:
            self.view.ensureVisible(its[0])

    def on_tree_drop(self, toks, target):
        """요소/속성 줄을 다른 id(그룹) 위로 드래그 -> 그 id 하위로 이동."""
        if not target or target[0] == "meta":
            return
        tgt = next((g for g in self.doc.groups if g.gid == target[1]), None)
        if tgt is None:
            return
        prim_t = [t for t in toks if t[0] == "prim" and t[1] != tgt.gid]
        grp_t = [t for t in toks if t[0] == "g" and t[1] != tgt.gid]
        if not prim_t and not grp_t:
            return
        if grp_t and QMessageBox.question(self, tr("병합"), tr("요소(그룹)를 다른 id 로 병합하시겠습니까? 원래 id 는 삭제됩니다.")) != QMessageBox.StandardButton.Yes:
            return
        self.push_undo()
        by = {g.gid: g for g in self.doc.groups}
        moved = []
        for gid in sorted({t[1] for t in prim_t}):
            src = by[gid]
            idxs = sorted({t[2] for t in prim_t if t[1] == gid})
            moved += [src.prims[k] for k in idxs]
            for k in reversed(idxs):
                del src.prims[k]
            src.dirty()
        for t in grp_t:
            src = by.get(t[1])
            if src:
                moved += src.prims; self.doc.remove(src)
        tgt.prims.extend(moved); tgt.dirty()
        self.sel_prims = [(tgt.gid, len(tgt.prims) - len(moved) + i) for i in range(len(moved))]
        self.rebuild()
        for i in self.items:
            i.setSelected(i.grp.gid == tgt.gid)
        self.refresh_all()
        self.statusBar().showMessage("%s: %d → id-%d" % (tr("이동 완료"), len(moved), tgt.gid))

    # ------------------------------------------------------------------ 선택 → 패널
    def selected_groups(self):
        gs = [i.grp for i in self.items if i.isSelected()]
        have = {g.gid for g in gs}
        gs += [g for g in self.doc.groups if g.gid in self.extra_gids and g.gid not in have and g.gid not in self.by_gid]
        return gs

    def on_scene_selection(self):
        if self._busy:
            return
        self.sel_prims = []; self.extra_gids = set()
        try:
            self.refresh_all()
        except RuntimeError:
            pass

    def refresh_all(self, sync_tree=True):
        if self._busy:
            return
        self.refresh_overlays()
        if sync_tree:
            self.sync_tree_selection()
        self.refresh_props()
        self.show_code()

    def pick_prim(self, scene_pos):
        for it in sorted(self.items, key=lambda i: -i.zValue()):
            if it.sceneBoundingRect().contains(scene_pos):
                k = it.prim_at(scene_pos)
                if k >= 0:
                    self.select_prim(it.grp.gid, k); return

    def select_prim(self, gid, k):
        self._busy = True
        for i in self.items:
            i.setSelected(i.grp.gid == gid)
        self._busy = False
        self.sel_prims = [(gid, k)]
        self.extra_gids = {gid} if gid not in self.by_gid else set()
        self.refresh_all()

    def refresh_props(self):
        self._loading = True
        gs = self.selected_groups()
        self.meta_tbl.setRowCount(0); self.attr_tbl.setRowCount(0); self.prim_list.clear()
        if len(gs) == 1:
            g = gs[0]
            self.sel_label.setText("id-%d   (%s / %s)" % (g.gid, g.cls, g.kind))
            for n, v, c in g.meta:
                r = self.meta_tbl.rowCount(); self.meta_tbl.insertRow(r)
                self.meta_tbl.setItem(r, 0, QTableWidgetItem(n)); self.meta_tbl.setItem(r, 1, QTableWidgetItem(v))
            for k, p in enumerate(g.prims):
                brief = ("'%s'" % p.text) if p.tag == "text" else (p.attrs.get("d", "")[:40] if p.tag == "path" else "")
                self.prim_list.addItem("#%d  %s  %s" % (k, p.tag, brief))
            cur = next((k for gid, k in self.sel_prims if gid == g.gid), -1)
            if len(self.sel_prims) == 1 and cur >= 0:
                self.prim_list.setCurrentRow(cur)
                self.fill_attr_table(g.prims[cur])
        else:
            self.sel_label.setText(tr("선택 %d개") % len(gs) if gs else tr("선택 없음"))
        self._loading = False

    def fill_attr_table(self, p: Prim):
        self.attr_tbl.setRowCount(0)
        for k, v in p.attrs.items():
            r = self.attr_tbl.rowCount(); self.attr_tbl.insertRow(r)
            self.attr_tbl.setItem(r, 0, QTableWidgetItem(k)); self.attr_tbl.setItem(r, 1, QTableWidgetItem(str(v)))
        if p.tag == "text":
            r = self.attr_tbl.rowCount(); self.attr_tbl.insertRow(r)
            it = QTableWidgetItem("CDATA"); it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.attr_tbl.setItem(r, 0, it); self.attr_tbl.setItem(r, 1, QTableWidgetItem(p.text))

    def prim_list_changed(self, row):
        if self._loading or row < 0:
            return
        gs = self.selected_groups()
        if len(gs) == 1:
            self.select_prim(gs[0].gid, row)

    # ------------------------------------------------------------------ 속성 편집 (표 <-> 캔버스 양방향)
    def _cur_prim(self):
        gs = self.selected_groups()
        if len(gs) == 1 and len(self.sel_prims) == 1 and self.sel_prims[0][0] == gs[0].gid:
            k = self.sel_prims[0][1]
            if k < len(gs[0].prims):
                return gs[0], k, gs[0].prims[k]
        return None

    def attr_changed(self, r, c):
        if self._loading:
            return
        cur = self._cur_prim()
        if not cur:
            return
        g, k, p = cur
        self.push_undo()
        attrs = {}
        for i in range(self.attr_tbl.rowCount()):
            n = self.attr_tbl.item(i, 0).text().strip() if self.attr_tbl.item(i, 0) else ""
            v = self.attr_tbl.item(i, 1).text() if self.attr_tbl.item(i, 1) else ""
            if n == "CDATA":
                p.text = v
            elif n:
                attrs[n] = v
        p.attrs = attrs
        g.dirty()
        self.rebuild_group(g.gid)
        QTimer.singleShot(0, self.refresh_props)       # 수정한 값이 바로 캔버스와 목록/코드에 반영
        QTimer.singleShot(0, self.show_code)

    def add_attr_row(self):
        cur = self._cur_prim()
        if not cur:
            return
        dlg = FormDialog(self, tr("속성 추가"), [("이름", "")])
        if dlg.exec() and dlg.values()["이름"]:
            self.push_undo()
            cur[2].attrs[dlg.values()["이름"]] = ""; cur[0].dirty()
            self.rebuild_group(cur[0].gid); self.refresh_props(); self.show_code()

    def del_attr_row(self):
        cur = self._cur_prim(); r = self.attr_tbl.currentRow()
        if not cur or r < 0 or not self.attr_tbl.item(r, 0):
            return
        n = self.attr_tbl.item(r, 0).text()
        if n in cur[2].attrs:
            self.push_undo(); del cur[2].attrs[n]; cur[0].dirty()
            self.rebuild_group(cur[0].gid); self.refresh_props(); self.show_code()

    def meta_changed(self, r, c):
        if self._loading:
            return
        gs = self.selected_groups()
        if len(gs) != 1:
            return
        g = gs[0]; self.push_undo()
        meta = []
        for i in range(self.meta_tbl.rowCount()):
            n = (self.meta_tbl.item(i, 0).text() if self.meta_tbl.item(i, 0) else "").strip()
            v = self.meta_tbl.item(i, 1).text() if self.meta_tbl.item(i, 1) else ""
            if n:
                old = next((x for x in g.meta if x[0] == n), None)
                meta.append((n, v, old[2] if old else True))
        g.meta = meta; g.dirty()
        self.rebuild_group(g.gid); self.show_code()

    def add_meta_row(self):
        self._loading = True
        r = self.meta_tbl.rowCount(); self.meta_tbl.insertRow(r)
        self.meta_tbl.setItem(r, 0, QTableWidgetItem("")); self.meta_tbl.setItem(r, 1, QTableWidgetItem(""))
        self._loading = False
        self.meta_tbl.editItem(self.meta_tbl.item(r, 0))

    def del_meta_row(self):
        r = self.meta_tbl.currentRow()
        if r >= 0:
            self.meta_tbl.removeRow(r); self.meta_changed(r, 0)

    # ------------------------------------------------------------------ 코드 편집
    def show_code(self):
        gs = self.selected_groups()
        self.code.setPlainText(gs[0].to_xml().replace("\r\n", "\n") if len(gs) == 1 else "")
        self.code.setReadOnly(len(gs) != 1)

    def apply_code(self):
        gs = self.selected_groups()
        if len(gs) != 1:
            QMessageBox.information(self, tr("코드 편집"), tr("한 개의 그룹을 선택하세요")); return
        try:
            ng = parse_group_xml(self.code.toPlainText())
        except Exception as ex:
            QMessageBox.warning(self, tr("코드 오류"), str(ex)); return
        old = gs[0]
        if ng.gid != old.gid and any(x.gid == ng.gid for x in self.doc.groups):
            QMessageBox.warning(self, tr("코드 오류"), "id-%d 가 이미 존재합니다." % ng.gid); return
        self.push_undo()
        idx = next(i for i, x in enumerate(self.doc.items) if x is old)
        self.doc.items[idx] = ng
        self.sel_prims = []
        self.rebuild()
        for i in self.items:
            i.setSelected(i.grp.gid == ng.gid)
        self.refresh_all()
        self.statusBar().showMessage(tr("코드 적용 완료"))

    # ------------------------------------------------------------------ 편집 : 이동/삭제/클립보드/undo
    def push_undo(self):
        self.undo_stack.append(self.doc.to_xml())
        if len(self.undo_stack) > 80:
            self.undo_stack.pop(0)
        while len(self.undo_stack) > 3 and sum(len(s) for s in self.undo_stack) > 150_000_000:      # 큰 그림이 많을 때 메모리 보호
            self.undo_stack.pop(0)
        self.redo_stack.clear()
        self.modified = True

    def undo(self):
        if self.undo_stack:
            self.redo_stack.append(self.doc.to_xml()); self._restore(self.undo_stack.pop())

    def redo(self):
        if self.redo_stack:
            self.undo_stack.append(self.doc.to_xml()); self._restore(self.redo_stack.pop())

    def _restore(self, xml):
        path, title = self.doc.path, self.doc.title
        self.doc = Doc.parse(xml); self.doc.path, self.doc.title = path, title
        self.sel_prims = []
        self.rebuild()

    def move_prims(self, gid, ks, dx, dy, undo=True):
        """선택한 prim 들만 이동 (같은 id 안의 다른 객체는 그대로)."""
        g = next((x for x in self.doc.groups if x.gid == gid), None)
        if g is None:
            return
        if undo:
            self.push_undo()
        for k in ks:
            if k < len(g.prims):
                g.prims[k].translate(dx, dy)
        g.dirty()
        self.rebuild_group(gid)
        self.refresh_props(); self.show_code(); self.refresh_overlays()


    # ------------------------------------------------------------------ 그림 / 도형 / 표 개체
    IMG_EXT = (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".webp", ".tif", ".tiff", ".ico")

    def insert_pos(self):
        p = getattr(self, "_ctx_pt", None)
        if p is not None:
            return QPointF(p)
        c = self.view.mapToScene(self.view.viewport().rect().center()); pr = self.page_rect
        return QPointF(min(max(c.x(), pr.left() + 50), pr.right() - 50), min(max(c.y(), pr.top() + 50), pr.bottom() - 50))

    def _ensure_xlink(self):
        if "xmlns:xlink" not in self.doc.header:
            self.doc.header = self.doc.header.replace("<svg ", '<svg xmlns:xlink="http://www.w3.org/1999/xlink" ', 1)

    def _add_group_select(self, grp, prim_index=0):
        self.doc.add(grp)
        self.sel_prims = [(grp.gid, prim_index)]; self.extra_gids = set()
        self.rebuild()
        self.select_prim(grp.gid, prim_index)

    def insert_qimage(self, img, pos=None):
        """QImage(파일/클립보드/캡처) 를 도면에 그림(<image>)으로 삽입."""
        from PyQt6.QtCore import QBuffer, QByteArray, QIODevice
        from PyQt6.QtGui import QImage
        if not isinstance(img, QImage):
            img = QImage(img)
        if img.isNull():
            self.statusBar().showMessage(tr("그림을 읽을 수 없습니다.")); return False
        pw, ph = img.width(), img.height()
        if max(pw, ph) > 2400:
            img = img.scaled(2400, 2400, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        jpg = (not img.hasAlphaChannel()) and img.width() * img.height() > 400000
        ba = QByteArray(); buf = QBuffer(ba); buf.open(QIODevice.OpenModeFlag.WriteOnly)
        img.save(buf, "JPG" if jpg else "PNG", 90 if jpg else -1); buf.close()
        vb = self.doc.viewbox
        k = min(0.5, vb[2] * 0.5 / pw, vb[3] * 0.5 / ph)
        w, h = pw * k, ph * k
        c = pos if pos is not None else self.insert_pos()
        self.push_undo(); self._ensure_xlink()
        g = SH.image_group(self.doc, bytes(ba), pw, ph, round(c.x() - w / 2, 3), round(c.y() - h / 2, 3), round(w, 3), round(h, 3), "image/jpeg" if jpg else "image/png")
        self._add_group_select(g)
        self.statusBar().showMessage(tr("그림 삽입: %d × %d px (모서리 핸들로 크기, 위쪽 초록 핸들로 회전)") % (pw, ph))
        return True

    def insert_image_path(self, path, pos=None):
        from PyQt6.QtGui import QImage
        return self.insert_qimage(QImage(path), pos)

    def insert_image_file(self):
        fs, _ = QFileDialog.getOpenFileNames(self, tr("그림 삽입"), self.last_dir(), tr("그림 파일") + " (*.png *.jpg *.jpeg *.bmp *.gif *.webp *.tif *.tiff *.ico);;All (*.*)")
        for i, f in enumerate(fs):
            self.remember_dir(f)
            c = self.insert_pos(); c = QPointF(c.x() + 12 * i, c.y() + 12 * i)
            self.insert_image_path(f, c)

    def insert_clipboard_image(self):
        img = QApplication.clipboard().image()
        if img.isNull():
            self.statusBar().showMessage(tr("클립보드에 그림이 없습니다. (Win+Shift+S 로 화면을 캡처한 뒤 붙여넣으세요)")); return
        self.insert_qimage(img)

    def drop_file(self, path, pt):
        pl = path.lower()
        if pl.endswith(self.IMG_EXT):
            self.insert_image_path(path, pt)
        elif pl.endswith((".svg", ".pdf")):
            self.open_file(path)

    # --- 도형
    def shape_pick(self, kind):
        self.shape_kind = kind
        self.tool_actions["shape"].setChecked(True); self.set_tool("shape")
        self.statusBar().showMessage(tr("도형") + ": " + tr(SH.KIND_NAME[kind]) + " — " + tr("도면에서 드래그하여 그립니다 (Shift: 정사각형/45°, 클릭만 하면 기본 크기, Esc/오른쪽 클릭: 종료)"))

    def shape_preview(self, p):
        if self._rubber is not None:
            self.scene.removeItem(self._rubber); self._rubber = None
        a, b = self._drag0, p
        if QApplication.keyboardModifiers() & Qt.KeyboardModifier.ShiftModifier:
            b = self._shape_constrain(a, b)
        pen = QPen(QColor("#0a84ff"), 1, Qt.PenStyle.DashLine); pen.setCosmetic(True)
        if self.shape_kind in ("line", "arrow"):
            self._rubber = self.scene.addLine(a.x(), a.y(), b.x(), b.y(), pen)
        else:
            self._rubber = self.scene.addRect(QRectF(a, b).normalized(), pen)
        self._rubber.setZValue(1000)

    def _shape_constrain(self, a, b):
        dx, dy = b.x() - a.x(), b.y() - a.y()
        if self.shape_kind in ("line", "arrow"):
            ang = round(math.atan2(dy, dx) / (math.pi / 4)) * (math.pi / 4); L = math.hypot(dx, dy)
            return QPointF(a.x() + L * math.cos(ang), a.y() + L * math.sin(ang))
        s = max(abs(dx), abs(dy))
        return QPointF(a.x() + math.copysign(s, dx or 1), a.y() + math.copysign(s, dy or 1))

    def shape_finish(self, p):
        a, b = self._drag0, p
        if QApplication.keyboardModifiers() & Qt.KeyboardModifier.ShiftModifier:
            b = self._shape_constrain(a, b)
        self.cancel_tool()
        kind = self.shape_kind; line = kind in ("line", "arrow")
        dx, dy = b.x() - a.x(), b.y() - a.y()
        if math.hypot(dx, dy) < 4:                                   # 클릭만 : 기본 크기
            x, y, w, h = a.x(), a.y(), (90.0 if line else 90.0), (0.0 if line else (90.0 if kind in ("ellipse", "star", "pentagon", "hexagon", "plus", "diamond") else 60.0))
            sx = sy = 1.0
        else:
            x, y, w, h = min(a.x(), b.x()), min(a.y(), b.y()), abs(dx), abs(dy)
            sx = -1.0 if (line and dx < 0) else 1.0; sy = -1.0 if (line and dy < 0) else 1.0
        st = getattr(self, "shape_style", None) or {}
        self.push_undo()
        g = SH.shape_group(self.doc, kind, round(x, 3), round(y, 3), round(w, 3), round(h, 3), **st)
        if sx < 0 or sy < 0:
            SH.set_xf(g.prims[0], 0.0, sx, sy)
        self._add_group_select(g)
        self.tool_actions["select"].trigger()
        self.select_prim(g.gid, 0)

    # --- 개체 선택/핸들
    def cur_obj(self):
        cur = self._single_prim()
        if cur and SH.is_obj(cur[2]) and local_rect(cur[2]) is not None:
            return cur
        return None

    def place_obj_handles(self):
        for h in getattr(self, "ohandles", []):
            try:
                if h.scene() is not None:
                    self.scene.removeItem(h)
            except RuntimeError:
                pass
        self.ohandles = []
        ob = self.cur_obj()
        if ob is None and self.tool == "select":
            tg = self.sel_table()
            if tg is not None:                                      # 표: 전체 크기 조절 핸들 (회전 없음)
                sp = SH.table_spec(tg); r = (sp[2], sp[3], sp[1] * sp[4], sp[0] * sp[5])
                for kind, (dx, dy) in SH.HANDLES.items():
                    h = ObjHandle(self, kind); h.setPos(r[0] + r[2] * (dx + 1) / 2, r[1] + r[3] * (dy + 1) / 2)
                    self.scene.addItem(h); self.ohandles.append(h)
            return
        if ob is None or self.tool != "select":
            return
        g, k, p = ob
        r = local_rect(p); a, sx, sy = xf_get(p)
        for kind, (dx, dy) in SH.HANDLES.items():
            if p.attrs.get("data-shape") in ("line", "arrow") and kind in ("n", "s") and r[3] == 0:
                continue
            x, y = SH.handle_pos(r, a, sx, sy, dx, dy)
            h = ObjHandle(self, kind); h.setPos(x, y); self.scene.addItem(h); self.ohandles.append(h)
        off = 26.0 / max(0.05, self.view.transform().m11())
        x, y = SH.to_scene(r, a, sx, sy, (r[0] + r[2] / 2, r[1] - off if sy > 0 else r[1] + r[3] + off))
        h = ObjHandle(self, "rot"); h.setPos(x, y); self.scene.addItem(h); self.ohandles.append(h)

    def sel_table(self):
        """선택된 것이 삽입한 표 1개(그룹 전체 또는 그 안의 요소)이면 그 그룹."""
        if self.sel_prims:
            gids = {gid for gid, _k in self.sel_prims}
            gs = [g for g in self.doc.groups if g.gid in gids]
        else:
            gs = self.selected_groups()
        if len(gs) == 1 and SH.table_spec(gs[0]) is not None:
            return gs[0]
        return None

    def obj_drag_start(self, kind, pos):
        ob = self.cur_obj()
        if ob is None:
            tg = self.sel_table()
            if tg is None:
                return
            sp = SH.table_spec(tg)
            self._od = dict(kind=kind, gid=tg.gid, k=0, rect=(sp[2], sp[3], sp[1] * sp[4], sp[0] * sp[5]), a=0.0, sx=1.0, sy=1.0, new=None,
                            img=False, line=False, table=sp)
            pen = QPen(QColor("#e65100"), 1.5, Qt.PenStyle.DashLine); pen.setCosmetic(True)
            self._od_box = self.scene.addPolygon(QPolygonF(), pen); self._od_box.setZValue(3050)
            return
        g, k, p = ob
        a, sx, sy = xf_get(p)
        self._od = dict(kind=kind, gid=g.gid, k=k, rect=local_rect(p), a=a, sx=sx, sy=sy, new=None, img=p.tag == "image",
                        line=p.attrs.get("data-shape") in ("line", "arrow"))
        pen = QPen(QColor("#e65100"), 1.5, Qt.PenStyle.DashLine); pen.setCosmetic(True)
        self._od_box = self.scene.addPolygon(QPolygonF(), pen); self._od_box.setZValue(3050)

    def _od_calc(self, pos):
        d = self._od; shift = bool(QApplication.keyboardModifiers() & Qt.KeyboardModifier.ShiftModifier)
        if d["kind"] == "rot":
            return d["rect"], SH.rotate_angle(d["rect"], d["sy"], (pos.x(), pos.y()), snap=shift)
        if d.get("table"):
            rows, cols = d["table"][0], d["table"][1]
            x0, y0, w0, h0 = d["rect"]
            r = list(SH.resize(d["rect"], 0.0, 1.0, 1.0, d["kind"], (pos.x(), pos.y()), keep_aspect=shift))
            mw, mh = cols * 6.0, rows * 4.0                        # 칸 최소 크기
            if r[2] < mw:
                r[0] = x0 + w0 - mw if "w" in d["kind"] else x0; r[2] = mw
            if r[3] < mh:
                r[1] = y0 + h0 - mh if "n" in d["kind"] else y0; r[3] = mh
            return tuple(r), 0.0
        keep = (d["img"] != shift) and d["kind"] in ("nw", "ne", "sw", "se")       # 그림은 모서리에서 기본 비율 유지, Shift 로 해제 (도형은 반대)
        r = SH.resize(d["rect"], d["a"], d["sx"], d["sy"], d["kind"], (pos.x(), pos.y()), keep_aspect=keep, allow_zero=d["line"])
        return r, d["a"]

    def obj_drag_move(self, pos):
        d = getattr(self, "_od", None)
        if not d:
            return
        r, a = self._od_calc(pos); d["new"] = (r, a)
        pts = SH.corners(r, a, d["sx"], d["sy"])
        self._od_box.setPolygon(QPolygonF([QPointF(*q) for q in pts]))
        if d.get("table"):
            sp = d["table"]
            self.statusBar().showMessage("%s %.1f × %.1f   (%s %.1f × %.1f)" % (tr("표 크기"), r[2], r[3], tr("칸"), r[2] / sp[1], r[3] / sp[0])); return
        self.statusBar().showMessage("%s %.1f × %.1f   %s %.1f°" % (tr("크기"), r[2], r[3], tr("회전"), a))

    def obj_drag_end(self, pos):
        d = getattr(self, "_od", None)
        if not d:
            return
        self._od = None
        if self._od_box.scene() is not None:
            self.scene.removeItem(self._od_box)
        if d["new"] is None:
            return
        r, a = d["new"]
        g = next((x for x in self.doc.groups if x.gid == d["gid"]), None)
        if d.get("table") and g is not None:
            rows, cols, _x, _y, _cw, _ch, fs, header, texts = d["table"]
            self.push_undo()
            g.prims = SH.table_prims(round(r[0], 3), round(r[1], 3), rows, cols, round(r[2] / cols, 3), round(r[3] / rows, 3), texts, fs, header)
            g.dirty(); self.sel_prims = []; self.rebuild_group(g.gid); self.refresh_props(); self.show_code(); self.refresh_all()
            return
        if g is None or d["k"] >= len(g.prims):
            return
        self.push_undo(); p = g.prims[d["k"]]
        if d["kind"] == "rot":
            SH.set_xf(p, a, d["sx"], d["sy"])
        else:
            SH.set_rect(p, *r)
        g.dirty(); self.rebuild_group(g.gid); self.refresh_props(); self.show_code(); self.refresh_all()

    # --- 개체 명령 (회전/대칭/크기/서식/순서)
    def _obj_apply(self, fn):
        ob = self.cur_obj()
        if ob is None:
            self.statusBar().showMessage(tr("그림 또는 도형 1개를 먼저 선택하세요")); return
        g, k, p = ob
        self.push_undo(); fn(p)
        g.dirty(); self.rebuild_group(g.gid); self.refresh_props(); self.show_code(); self.refresh_all()

    def obj_rotate(self, delta):
        def f(p):
            a, sx, sy = xf_get(p); SH.set_xf(p, a + delta, sx, sy)
        self._obj_apply(f)

    def obj_flip(self, horizontal):
        def f(p):
            a, sx, sy = xf_get(p); SH.set_xf(p, *SH.flip(a, sx, sy, horizontal))
        self._obj_apply(f)

    def obj_angle(self):
        ob = self.cur_obj()
        if ob is None:
            self.statusBar().showMessage(tr("그림 또는 도형 1개를 먼저 선택하세요")); return
        a, sx, sy = xf_get(ob[2])
        dlg = FormDialog(self, tr("각도 지정 회전"), [("회전 각도 (°)", fmt(a))])
        if dlg.exec():
            try:
                v = float(dlg.values()["회전 각도 (°)"])
            except ValueError:
                return
            self._obj_apply(lambda p: SH.set_xf(p, v, sx, sy))

    def obj_size(self):
        ob = self.cur_obj()
        if ob is None:
            self.statusBar().showMessage(tr("그림 또는 도형 1개를 먼저 선택하세요")); return
        dlg = ObjSizeDialog(self, ob[2])
        if dlg.exec():
            v = dlg.values()

            def f(p):
                SH.set_rect(p, v["x"], v["y"], max(0.0, v["w"]), max(0.0, v["h"])); SH.set_xf(p, v["a"], v["sx"], v["sy"])
            self._obj_apply(f)

    def obj_style(self):
        ob = self.cur_obj()
        if ob is None:
            self.statusBar().showMessage(tr("그림 또는 도형 1개를 먼저 선택하세요")); return
        dlg = ShapeStyleDialog(self, ob[2])
        if dlg.exec():
            self._obj_apply(dlg.apply)
            st = dlg.style()
            if st:
                self.shape_style = st                                  # 이후 새로 그리는 도형에 같은 서식 사용

    def obj_crop(self):
        ob = self.cur_obj()
        if ob is None or ob[2].tag != "image":
            self.statusBar().showMessage(tr("자를 그림 1개를 먼저 선택하세요")); return
        data, _m = SH.image_bytes(ob[2])
        pix = QPixmap(); 
        if data is None or not pix.loadFromData(data):
            self.statusBar().showMessage(tr("이 그림은 내장 데이터가 아니라 자를 수 없습니다")); return
        dlg = CropDialog(self, pix)
        if not dlg.exec():
            return
        l, t, r, b = dlg.margins()
        if max(l, t, r, b) < 1e-6:
            return
        self._obj_apply(lambda p: SH.crop_image(p, l, t, r, b))
        self.statusBar().showMessage(tr("그림을 잘랐습니다"))

    def obj_ratio(self):
        def f(p):
            nat = p.attrs.get("data-natural")
            if p.tag != "image" or not nat:
                return
            pw, ph = (float(v) for v in nat.split()); x, y, w, h = local_rect(p)
            SH.set_rect(p, x, y, w, w * ph / pw)
        self._obj_apply(f)

    def obj_order(self, how):
        gs = self.selected_groups()
        if len(gs) != 1:
            self.statusBar().showMessage(tr("순서를 바꿀 개체 1개를 선택하세요")); return
        g = gs[0]; self.push_undo()
        items = self.doc.items; i = items.index(g)
        idx = [n for n, x in enumerate(items) if isinstance(x, Group)]
        pos = idx.index(i)
        items.pop(i)
        if how == "front":
            items.append(g)
        elif how == "back":
            first = next((n for n, x in enumerate(items) if isinstance(x, Group) and x.cls not in ("rectangle", "xygrid")), len(items))
            items.insert(first, g)
        elif how == "fwd" and pos + 1 < len(idx):
            items.insert(idx[pos + 1], g)
        elif how == "bwd" and pos > 0:
            items.insert(idx[pos - 1], g)
        else:
            items.insert(i, g)
        sp = list(self.sel_prims); self.rebuild(); self.sel_prims = sp; self.refresh_all()

    # --- 표
    def insert_table(self):
        dlg = TableDialog(self)
        if not dlg.exec():
            return
        rows, cols, cw, ch, fs, header, texts = dlg.values()
        c = self.insert_pos()
        self.push_undo()
        g = SH.table_group(self.doc, round(c.x() - cols * cw / 2, 3), round(c.y() - rows * ch / 2, 3), rows, cols, cw, ch, texts, fs, header)
        self.doc.add(g); self.sel_prims = []; self.rebuild()
        for i in self.items:
            i.setSelected(i.grp.gid == g.gid)
        self.refresh_all()

    def dbl_click_table(self, pt):
        """pt 위치가 삽입한 표(data-table)면 표 편집 창을 연다. 처리했으면 True."""
        it, k = self.hit_at(pt)
        if it is None or SH.table_spec(it.grp) is None:
            return False
        for i in self.items:
            i.setSelected(i.grp.gid == it.grp.gid)
        self.edit_table(it.grp); return True

    def edit_table(self, grp=None):
        gs = [grp] if grp is not None else self.selected_groups()
        sp = SH.table_spec(gs[0]) if len(gs) == 1 else None
        if sp is None:
            self.statusBar().showMessage(tr("표를 선택하세요 (삽입한 표만 편집할 수 있습니다)")); return
        dlg = TableDialog(self, sp)
        if not dlg.exec():
            return
        rows, cols, cw, ch, fs, header, texts = dlg.values(); g = gs[0]
        self.push_undo()
        g.prims = SH.table_prims(sp[2], sp[3], rows, cols, cw, ch, texts, fs, header); g.dirty()
        self.sel_prims = []; self.rebuild_group(g.gid); self.refresh_props(); self.show_code(); self.refresh_all()

    # ------------------------------------------------------------------ 도면 오른쪽 마우스 메뉴
    def hit_at(self, pt):
        for it in sorted(self.items, key=lambda i: -i.zValue()):
            if it.sceneBoundingRect().contains(pt):
                k = it.prim_at(pt)
                if k >= 0:
                    return it, k
        return None, -1

    def right_click_select(self, pt):
        """오른쪽 클릭한 위치의 객체를 선택(이미 선택된 객체 위면 선택 유지)."""
        it, k = self.hit_at(pt)
        if it is None:
            return
        if (it.grp.gid, k) in self.sel_prims or (not self.sel_prims and it.isSelected()):
            return
        self.select_prim(it.grp.gid, k)

    def canvas_menu(self, pt, gpos):
        it, k = self.hit_at(pt)
        m = QMenu(self)
        tg = it.grp if (it is not None and SH.table_spec(it.grp) is not None) else None
        if tg is None:                                            # 표가 선택돼 있으면 어디를 눌러도 표 편집 표시
            sg = self.selected_groups()
            if len(sg) == 1 and SH.table_spec(sg[0]) is not None:
                tg = sg[0]
        if tg is not None:
            ta = m.addAction(self.a_tedit.icon(), tr("표 편집…")); ta.triggered.connect(lambda _=False, g=tg: self.edit_table(g))
            f = ta.font() if hasattr(ta, "font") else None
            if f is not None:
                f.setBold(True); ta.setFont(f)
            m.addSeparator()
        for a in (self.a_undo, self.a_redo):
            m.addAction(a)
        m.addSeparator()
        for a in (self.a_cut, self.a_copy, self.a_paste, self.a_del):
            m.addAction(a)
        m.addSeparator()
        for a in (self.a_fcopy, self.a_fpaste, self.a_fsel):
            m.addAction(a)
        if it is not None:
            m.addSeparator()
            p = it.grp.prims[k]
            a1 = m.addAction(tr("이 객체만 선택") + " (%s #%d)" % (p.tag, k)); a1.triggered.connect(lambda: self.select_prim(it.grp.gid, k))
            a2 = m.addAction(tr("id 전체 선택") + " (id-%d)" % it.grp.gid)
            a2.triggered.connect(lambda: self.select_group_whole(it.grp.gid))
        if self.cur_obj() is not None:
            m.addSeparator()
            sm = m.addMenu(tr("회전/대칭"))
            for a in (self.a_rotr, self.a_rotl, self.a_rota, self.a_flh, self.a_flv):
                sm.addAction(a)
            for a in (self.a_osize, self.a_ostyle):
                m.addAction(a)
            om = m.addMenu(tr("순서"))
            for a in (self.a_front, self.a_fwd, self.a_bwd, self.a_back):
                om.addAction(a)
        m.addSeparator()
        im = m.addMenu(tr("삽입"))
        for a in (self.a_img, self.a_imgclip, self.a_table):
            im.addAction(a)
        sh = im.addMenu(tr("도형"))
        for a in self.shape_acts:
            sh.addAction(a)
        m.addSeparator()
        for a in (self.a_all, self.a_find, self.a_chk, self.a_fix, self.a_cjk, self.a_fit):
            m.addAction(a)
        self._ctx_pt = QPointF(pt)
        m.exec(gpos)
        self._ctx_pt = None

    def select_group_whole(self, gid):
        self._busy = True
        for i in self.items:
            i.setSelected(i.grp.gid == gid)
        self._busy = False
        self.sel_prims = []; self.extra_gids = set()
        self.refresh_all()

    # ------------------------------------------------------------------ 방향키 이동
    def nudge(self, dx, dy):
        """선택한 객체(개별 prim 이 선택되어 있으면 그것만, 아니면 id 전체)를 방향키로 이동."""
        import time
        ps = list(self.sel_prims); gs = self.selected_groups()
        if not ps and not gs:
            return False
        now = time.time()
        if not (now - getattr(self, "_nudge_t", 0) < 1.0 and len(self.undo_stack) == getattr(self, "_nudge_n", -1)):
            self.push_undo()                  # 연속으로 누르는 동안은 실행 취소 1단계로 묶음
        self._nudge_t = now; self._nudge_n = len(self.undo_stack)
        if ps:
            by = {}
            for gid, k in ps:
                by.setdefault(gid, []).append(k)
            for gid, ks in by.items():
                self.move_prims(gid, ks, dx, dy, undo=False)
        else:
            for g in gs:
                g.translate(dx, dy)
            for g in gs:
                self.rebuild_group(g.gid)
            self.refresh_props(); self.show_code(); self.refresh_overlays()
        self.statusBar().showMessage(tr("이동 (%s, %s)") % (("%g" % dx), ("%g" % dy)))
        return True

    # ------------------------------------------------------------------ 서식 복사
    FMT_GEOM = {"text": {"x", "y", "transform"}, "path": {"d"}, "rect": {"x", "y", "width", "height"},
                "ellipse": {"cx", "cy", "rx", "ry"}, "image": {"x", "y", "width", "height", "href", "xlink:href"}}
    FMT_TEXT = ("font-family", "font-size", "textLength")

    def _single_prim(self):
        """(group, index, prim) : 객체 1개만 선택된 경우(개별 prim, 또는 prim 이 1개뿐인 id)."""
        if len(self.sel_prims) == 1:
            gid, k = self.sel_prims[0]; g = next((x for x in self.doc.groups if x.gid == gid), None)
            if g is not None and k < len(g.prims):
                return g, k, g.prims[k]
            return None
        if not self.sel_prims:
            gs = self.selected_groups()
            if len(gs) == 1 and len(gs[0].prims) == 1:
                return gs[0], 0, gs[0].prims[0]
        return None

    def fmt_keys_for(self, p):
        names = [k for k in p.attrs if k not in self.FMT_GEOM.get(p.tag, set())]
        saved = i18n.get_setting("fmt_keys_" + p.tag, None)
        if saved is not None:
            return [k for k in names if k in saved]
        if p.tag == "text":
            return [k for k in self.FMT_TEXT if k in names]
        return names

    def fmt_copy(self, ask=False, quiet=False):
        """선택한 객체의 서식(속성)을 서식 클립보드에 복사. ask=True 면 복사할 속성을 고르는 창을 띄움."""
        cur = self._single_prim()
        if not cur:
            if not quiet:
                self.statusBar().showMessage(tr("서식을 복사할 객체 1개를 먼저 선택하세요 (개별 객체는 더블클릭 또는 Alt+클릭)"))
            return False
        p = cur[2]
        names = [k for k in p.attrs if k not in self.FMT_GEOM.get(p.tag, set())]
        keys = self.fmt_keys_for(p)
        if ask:
            dlg = FormatCopyDialog(self, p, names, keys)
            if not dlg.exec():
                return False
            keys = dlg.checked()
            i18n.set_setting("fmt_keys_" + p.tag, keys)
        if not keys:
            self.statusBar().showMessage(tr("복사할 속성이 선택되지 않았습니다 (편집 > 서식 복사 항목 선택…)")); return False
        self.fmt_clip = {"tag": p.tag, "attrs": {k: p.attrs[k] for k in keys if k in p.attrs}}
        self.statusBar().showMessage(tr("서식 복사: ") + ", ".join("%s=%s" % kv for kv in self.fmt_clip["attrs"].items()))
        return True

    def fmt_apply(self, targets):
        """targets: [(group, prim)] 에 서식 클립보드의 속성을 적용. 적용한 개수 반환."""
        clip = getattr(self, "fmt_clip", None)
        if not clip:
            self.statusBar().showMessage(tr("먼저 서식을 복사하세요 (Ctrl+Shift+C)")); return 0
        tg = [(g, p) for g, p in targets if p.tag == clip["tag"]]
        if not tg:
            self.statusBar().showMessage(tr("같은 종류(%s)의 대상 객체가 없습니다") % clip["tag"]); return 0
        self.push_undo()
        for g, p in tg:
            p.attrs.update(clip["attrs"]); g.dirty()
        for gid in {g.gid for g, _ in tg}:
            self.rebuild_group(gid)
        self.refresh_props(); self.show_code(); self.refresh_overlays()
        self.statusBar().showMessage(tr("서식 적용: %d개") % len(tg))
        return len(tg)

    def fmt_paste(self):
        by = {g.gid: g for g in self.doc.groups}
        tg = []
        if self.sel_prims:
            for gid, k in self.sel_prims:
                if gid in by and k < len(by[gid].prims):
                    tg.append((by[gid], by[gid].prims[k]))
        else:
            for g in self.selected_groups():
                tg += [(g, p) for p in g.prims]
        self.fmt_apply(tg)

    def fmt_select(self):
        self.fmt_copy(ask=True)

    def fmt_brush(self, pt):
        """서식 브러시 도구: 클릭한 객체에 복사해 둔 서식을 적용."""
        for it in sorted(self.items, key=lambda i: -i.zValue()):
            if it.sceneBoundingRect().contains(pt):
                k = it.prim_at(pt)
                if k >= 0:
                    self.fmt_apply([(it.grp, it.grp.prims[k])]); return
        self.statusBar().showMessage(tr("클릭한 위치에 객체가 없습니다"))

    def move_selected(self):
        moved = [i for i in self.items if i.isSelected() and (abs(i.pos().x()) > 1e-6 or abs(i.pos().y()) > 1e-6)]
        if not moved:
            return
        self.push_undo()
        for i in moved:
            i.grp.translate(i.pos().x(), i.pos().y())
        for i in moved:
            self.rebuild_group(i.grp.gid)
        self.refresh_props(); self.show_code()           # 캔버스에서 바꾼 위치가 attribute(x,y,d..)에 즉시 반영

    def delete_selected(self):
        if self.sel_prims:
            self.push_undo()
            by = {g.gid: g for g in self.doc.groups}
            for gid in {g for g, _ in self.sel_prims}:
                ks = sorted({k for g, k in self.sel_prims if g == gid}, reverse=True)
                for k in ks:
                    if gid in by and k < len(by[gid].prims):
                        del by[gid].prims[k]
                by[gid].dirty()
            self.sel_prims = []
            self.rebuild(); return
        gs = self.selected_groups()
        if gs:
            self.push_undo()
            for g in gs:
                self.doc.remove(g)
            self.rebuild()

    def set_scrollbar(self, px):
        i18n.set_setting("sb_width", int(px))
        apply_ui_font(self.ui_font_size())

    # ------------------------------------------------------------------ 찾기
    def find_open(self):
        if getattr(self, "_find", None) is None:
            self._find = FindDialog(self)
        self._find.show(); self._find.raise_(); self._find.activateWindow(); self._find.edit.setFocus(); self._find.edit.selectAll()

    def find_next(self, step=1):
        self.find_open()
        self._find.step(step)

    def find_all(self, q, case=False, scope="all"):
        """(gid, prim_index|None, 설명) 목록."""
        out = []
        if not q:
            return out
        qq = q if case else q.lower()
        def hit(s):
            return qq in (s if case else s.lower())
        for g in self.doc.groups:
            tag = "id-%d" % g.gid
            if scope in ("all", "meta"):
                if hit(tag) or hit(g.cls):
                    out.append((g.gid, None, "%s  [%s]" % (tag, g.cls)))
                for n, v, _c in g.meta:
                    if hit(n) or hit(v):
                        out.append((g.gid, None, "%s meta %s = %s" % (tag, n, v[:60])))
            if scope in ("all", "text"):
                for k, p in enumerate(g.prims):
                    if p.tag == "text" and hit(p.text):
                        out.append((g.gid, k, "%s text #%d : %s" % (tag, k, p.text[:60])))
        return out

    def find_select(self, gid, k=None):
        self.extra_gids = set() if gid in self.by_gid else {gid}
        self.sel_prims = [(gid, k)] if k is not None else []
        self._busy = True
        for i in self.items:
            i.setSelected(i.grp.gid == gid)
        self._busy = False
        self.refresh_all()
        it = self.by_gid.get(gid)
        if it is not None:
            if k is not None and k < len(it.prim_items) and it.prim_items[k] is not None:
                self.view.auto_fit = False
                self.view.centerOn(it.prim_items[k].sceneBoundingRect().center())
            else:
                self.view.auto_fit = False
                self.view.centerOn(it)

    def delete_cjk(self):
        from model import strip_cjk
        self.push_undo(); n = strip_cjk(self.doc); self.sel_prims = []
        self.rebuild()
        self.statusBar().showMessage(tr("중국어 글자 %d개 삭제") % n)

    def _collect_clip(self):
        if self.sel_prims:
            by = {g.gid: g for g in self.doc.groups}
            xs = [by[g].prims[k].to_xml() for g, k in sorted(self.sel_prims) if g in by and k < len(by[g].prims)]
            return {"kind": "prims", "xml": xs}
        gs = self.selected_groups()
        if gs:
            return {"kind": "groups", "xml": [g.to_xml() for g in gs]}
        return None

    def copy(self):
        c = self._collect_clip()
        if c:
            self.clip = c
            QApplication.clipboard().setText("\n".join(c["xml"]))
            self.statusBar().showMessage("%s: %d" % (tr("복사"), len(c["xml"])))

    def cut(self):
        self.copy()
        if self.clip:
            self.delete_selected()

    def paste(self):
        from model import parse_prim_xml
        md = QApplication.clipboard().mimeData()
        if md is not None and md.hasImage() and not md.hasText():          # 화면 캡처/외부에서 복사한 그림
            self.insert_clipboard_image(); return
        clip = self.clip
        if clip is None:
            txt = QApplication.clipboard().text().strip()
            if txt.startswith("<g "):
                clip = {"kind": "groups", "xml": re.findall(r'<g id="id-\d+".*?</g>', txt, re.S)}
            elif txt.startswith("<"):
                clip = {"kind": "prims", "xml": [l for l in txt.splitlines() if l.strip()]}
        if not clip:
            self.statusBar().showMessage(tr("클립보드가 비어 있습니다.")); return
        if clip["kind"] == "prims":
            gs = self.selected_groups()
            if len(gs) != 1:
                self.statusBar().showMessage(tr("붙여넣기 대상 그룹을 선택하세요.")); return
            self.push_undo(); g = gs[0]; start = len(g.prims)
            for x in clip["xml"]:
                try:
                    g.prims.append(parse_prim_xml(x))
                except Exception:
                    pass
            g.dirty(); self.sel_prims = [(g.gid, k) for k in range(start, len(g.prims))]
            self.rebuild(); return
        self.push_undo(); new = []
        for x in clip["xml"]:
            try:
                g = parse_group_xml(x)
            except Exception:
                continue
            g.gid = self.doc.next_id()
            g.translate(10, 10)
            tg = g.get("tag", "")
            if tg and tg != "AUTO_GENERATED":
                g.set("tag", re.sub(r"_\d+_$", "_%d_" % (960000 + g.gid), tg) if re.search(r"_\d+_$", tg) else tg + "_c%d" % g.gid)
            self.doc.add(g); new.append(g.gid)
        self.sel_prims = []
        self.rebuild()
        for i in self.items:
            i.setSelected(i.grp.gid in new)
        self.refresh_all()

    def keyPressEvent(self, ev):
        super().keyPressEvent(ev)

    # ------------------------------------------------------------------ 파일
    @staticmethod
    def ui_font_size():
        try:
            return int(i18n.get_setting("ui_font", 11))
        except Exception:
            return 11

    def set_ui_font(self, pt):
        i18n.set_setting("ui_font", pt)
        apply_ui_font(pt)
        self.tree.set_code_font(max(9, pt - 1))
        sz = max(22, int(pt * 2.2))
        for tb in self.findChildren(QToolBar):
            tb.setIconSize(QSize(sz, sz))
        f = QFont(MONO, max(9, pt - 1)); f.setStyleHint(QFont.StyleHint.Monospace); self.code.setFont(f)
        self.statusBar().showMessage("%s: %d pt" % (tr("글자 크기"), pt))

    @staticmethod
    def default_canvas():
        try:
            w = float(i18n.get_setting("canvas_w", 1874.25)); h = float(i18n.get_setting("canvas_h", 1251))
            return (w, h) if w > 0 and h > 0 else (1874.25, 1251.0)
        except Exception:
            return 1874.25, 1251.0

    def set_default_canvas(self):
        w, h = self.default_canvas()
        dlg = FormDialog(self, tr("기본 캔버스 크기…"), [("캔버스 폭", fmt(w)), ("캔버스 높이", fmt(h))])
        if dlg.exec():
            try:
                nw, nh = (float(dlg.values()[k]) for k in ("캔버스 폭", "캔버스 높이"))
                assert nw > 0 and nh > 0
            except Exception:
                QMessageBox.warning(self, tr("기본 캔버스 크기…"), tr("숫자를 입력하세요 (>0)")); return
            i18n.set_setting("canvas_w", nw); i18n.set_setting("canvas_h", nh)
            self.statusBar().showMessage("%s%s × %s" % (tr("기본 캔버스 크기 저장: "), fmt(nw), fmt(nh)))

    @staticmethod
    def blank_doc(nw, nh, title="new_wiring"):
        d = Doc(); d.viewbox = [0.0, 0.0, nw, nh]; d.title = title
        rw, rh = nw - 0.2325, nh - 0.3765
        for gid, cls, st, fl in ((2, "rectangle", "#ffffff", "#ffffff"), (3, "xygrid", "none", "none")):
            d.add(parse_group_xml('<g id="id-%d" class="%s">\n<rect x="-0.15" y="-0.0345" width="%s" height="%s" stroke="%s" fill="%s" stroke-width="0.75"/>\n</g>' % (gid, cls, fmt(rw), fmt(rh), st, fl)))
        return d

    def new_doc(self):
        if not self._blank_reusable() and len(self.tabs) >= self.MAX_TABS:
            self.tab_new(); return
        w, h = self.default_canvas()
        dlg = FormDialog(self, tr("새 도면"), [("도면 이름", "new_wiring"), ("캔버스 폭", fmt(w)), ("캔버스 높이", fmt(h))])
        if not dlg.exec():
            return
        v = dlg.values()
        try:
            nw, nh = float(v["캔버스 폭"]), float(v["캔버스 높이"])
            assert nw > 0 and nh > 0
        except Exception:
            QMessageBox.warning(self, tr("새 도면"), tr("숫자를 입력하세요 (>0)")); return
        d = self.blank_doc(nw, nh, v["도면 이름"] or "new_wiring")
        if not self.tab_new():
            return
        self.doc = d; self.sel_prims = []; self.extra_gids = set()
        self.undo_stack, self.redo_stack = [], []; self.modified = False
        self._set_name(d.title)
        self.rebuild(); self.fit(); QTimer.singleShot(0, self.fit)
        self.run_check()
        self.statusBar().showMessage("%s: %s × %s" % (tr("새 도면"), fmt(nw), fmt(nh)))

    def last_dir(self):
        """마지막으로 열기/저장한 폴더 (없으면 문서 폴더/홈)."""
        d = i18n.get_setting("last_dir", "") or ""
        if (not d or not os.path.isdir(d)) and getattr(self.doc, "path", None):
            d = os.path.dirname(self.doc.path)
        return d if d and os.path.isdir(d) else os.path.expanduser("~")

    def remember_dir(self, path):
        try:
            d = os.path.dirname(os.path.abspath(path))
            if os.path.isdir(d):
                i18n.set_setting("last_dir", d)
        except Exception:
            pass

    def sig_export_dlg(self):
        self._sig = SigTableDialog(self, "export"); self._sig.show()

    def sig_update_dlg(self):
        self._sig = SigTableDialog(self, "update"); self._sig.show()

    def split_dlg(self):
        self._split = SplitDialog(self, None); self._split.show()

    def open_file(self, path=None):
        if not path:
            path, _ = QFileDialog.getOpenFileName(self, tr("열기"), self.last_dir(), "WD (*.pdf *.svg);;PDF (*.pdf);;SVG (*.svg)")
        if not path:
            return
        self.remember_dir(path)
        k = self.find_tab(path)
        if k >= 0:
            self.goto_tab(k); return
        if not self._blank_reusable() and len(self.tabs) >= self.MAX_TABS:
            self.tab_new(); return
        try:
            doc, imp = load_any(path)
        except Exception as ex:
            QMessageBox.critical(self, tr("열기 실패"), str(ex)); return
        if imp is not None and path.lower().endswith(".pdf"):
            st = imp.stats
            if not (st["wire"] or st["component"] or st["inline"] or st["reference"] or st["sp"]):
                import imgimport
                if imgimport.has_image_only(path):
                    r = self.ask_image_mode(path)
                    if r is None:
                        return
                    doc, imp = r
        if not self.tab_new():
            return
        self.doc = doc; self.sel_prims = []; self.extra_gids = set()
        self.undo_stack, self.redo_stack = [], []
        self.modified = path.lower().endswith(".pdf")
        self._set_name(os.path.basename(path), os.path.abspath(path))
        self.rebuild(); self.fit(); QTimer.singleShot(0, self.fit); QTimer.singleShot(150, self.fit)
        msg = tr("열기 완료: ") + os.path.basename(path)
        if imp is not None and not hasattr(imp, "stats"):         # 이미지 PDF 처리 결과
            if imp.warn:
                self._warn_box = QMessageBox(QMessageBox.Icon.Information, tr("변환 경고"), "\n".join(imp.warn), parent=self)
                self._warn_box.setModal(False); self._warn_box.show()
        elif imp is not None:
            st = imp.stats
            msg += "  | wire %d, component %d, inline %d, reference %d, SP %d, twist %d, unshielded %d" % (
                st["wire"], st["component"], st["inline"], st["reference"], st["sp"], st["twist"], st["unshielded"])
            if imp.warn:
                self._warn_box = QMessageBox(QMessageBox.Icon.Information, tr("변환 경고"), "\n".join(imp.warn), parent=self)
                self._warn_box.setModal(False); self._warn_box.show()
        self.statusBar().showMessage(msg)
        self.run_check()

    def ask_image_mode(self, path):
        """이미지(사진)만 들어 있는 PDF : 1) 이미지로 삽입  2) OCR 로 글자/상자 재현  중 선택."""
        import imgimport
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Icon.Question); box.setWindowTitle(tr("이미지 PDF"))
        box.setText(tr("이 PDF 는 선/글자 정보가 없는 이미지(사진) 입니다.\n처리 방법을 선택하세요."))
        b1 = box.addButton(tr("이미지로 삽입"), QMessageBox.ButtonRole.AcceptRole)
        b3 = box.addButton(tr("OCR 로 글자/상자 재현"), QMessageBox.ButtonRole.AcceptRole)
        box.addButton(tr("취소"), QMessageBox.ButtonRole.RejectRole)
        box.exec()
        c = box.clickedButton()
        if c not in (b1, b3):
            return None
        mode = "image" if c is b1 else "ocr"
        try:
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
            doc, warn = imgimport.build(path, mode)
        except Exception as ex:
            QMessageBox.critical(self, tr("변환 실패"), str(ex)); return None
        finally:
            QApplication.restoreOverrideCursor()
        class _R:  # 이미지 PDF 변환 결과(경고만)
            pass
        r = _R(); r.warn = warn
        return doc, r

    def save_svg(self):
        if not self.doc.path:
            return self.save_svg_as()
        export_svg(self.doc, self.doc.path); self.modified = False
        self.statusBar().showMessage(tr("저장: ") + self.doc.path)

    def save_svg_as(self):
        path, _ = QFileDialog.getSaveFileName(self, tr("SVG 저장"), os.path.join(self.last_dir(), (self.doc.title or "wiring") + ".svg"), "SVG (*.svg)")
        if path:
            self.remember_dir(path)
            export_svg(self.doc, path); self.modified = False
            self._set_name(os.path.basename(path), os.path.abspath(path))
            self.statusBar().showMessage(tr("저장: ") + path)

    def export_pdf_dlg(self):
        path, _ = QFileDialog.getSaveFileName(self, tr("PDF 내보내기…"), os.path.join(self.last_dir(), (self.doc.title or "wiring") + ".pdf"), "PDF (*.pdf)")
        if path:
            self.remember_dir(path)
            try:
                export_pdf(self.doc, path); self.statusBar().showMessage(tr("PDF 저장: ") + path)
            except Exception as ex:
                QMessageBox.critical(self, tr("PDF 내보내기 실패"), str(ex))

    # ------------------------------------------------------------------ 도구
    def set_tool(self, key):
        if key == "fmt":
            self.fmt_copy(quiet=True) if self._single_prim() else None      # 원본이 선택되어 있으면 바로 서식 복사
        self.cancel_tool()
        self.tool = key
        self.view.setDragMode({"select": QGraphicsView.DragMode.RubberBandDrag, "pan": QGraphicsView.DragMode.ScrollHandDrag}.get(key, QGraphicsView.DragMode.NoDrag))
        self.apply_item_flags(); self.apply_cursor()
        self.statusBar().showMessage(self.tool_actions[key].toolTip())

    def apply_cursor(self):
        self.view.setCursor({"select": Qt.CursorShape.ArrowCursor, "pan": Qt.CursorShape.OpenHandCursor}.get(self.tool, Qt.CursorShape.CrossCursor))

    def cancel_tool(self):
        self._pts = []; self._drag0 = None
        if self._rubber is not None:
            self.scene.removeItem(self._rubber); self._rubber = None

    @staticmethod
    def snap(p, step=1.0):
        return QPointF(round(p.x() / step) * step, round(p.y() / step) * step)

    def tool_press(self, p, ev):
        t = self.tool
        if t == "fmt":
            self.fmt_brush(p); return
        if t == "shape":
            self._drag0 = p; return
        if t == "wire":
            self._pts.append(self.snap(p, 0.5)); self._update_rubber(p)
        elif t == "component":
            self._drag0 = p
        elif t == "inline":
            w, d, q = E.nearest_wire(self.doc, (p.x(), p.y()))
            x, y = (q if (w and d < 15) else (p.x(), p.y()))
            dlg = FormDialog(self, tr("Inline"), [("ref (94/번호:핀)", "94/")])
            if dlg.exec():
                self.push_undo()
                self.doc.add(E.inline_group(self.doc, x, y, dlg.values()["ref (94/번호:핀)"], vertical=bool(ev.modifiers() & Qt.KeyboardModifier.ShiftModifier)))
                self.rebuild()
        elif t == "reference":
            dlg = FormDialog(self, tr("Reference"), [("ref (31/숫자)", "31/")])
            if dlg.exec():
                self.push_undo(); self.doc.add(E.reference_group(self.doc, p.x(), p.y(), dlg.values()["ref (31/숫자)"])); self.rebuild()
        elif t == "sp":
            w, d, q = E.nearest_wire(self.doc, (p.x(), p.y()))
            if not w:
                self.statusBar().showMessage(tr("wire 가 없습니다.")); return
            dlg = FormDialog(self, tr("Splice(SP)"), [("라벨 (SP숫자문자)", "SP")])
            if dlg.exec():
                self.push_undo(); pts = []
                for pr in w.prims:
                    if pr.tag == "path" and pr.attrs.get("stroke") == "#000000":
                        pts = path_points(pr.attrs["d"]); break
                ends = [pts[0], pts[-1]] if pts else [q]
                c = min(ends, key=lambda e: math.dist(e, (p.x(), p.y())))
                w.prims.append(E.dot_prim(*c)); w.prims.extend(E.sp_prims(c[0], c[1], dlg.values()["라벨 (SP숫자문자)"]))
                w.dirty(); self.rebuild_group(w.gid)
        elif t in ("twist", "unshielded"):
            w, d, q = E.nearest_wire(self.doc, (p.x(), p.y()))
            if not w:
                self.statusBar().showMessage(tr("wire 가 없습니다.")); return
            dlg = FormDialog(self, tr("Twist" if t == "twist" else "Unshielded"), [("라벨", "T2_25_T01_01" if t == "twist" else "MOAS_S01_01")])
            if dlg.exec():
                self.push_undo(); w.prims.extend(E.twist_prims(p.x(), p.y(), dlg.values()["라벨"], t == "unshielded")); w.dirty(); self.rebuild_group(w.gid)
        elif t == "text":
            dlg = FormDialog(self, tr("Text"), [("내용", "")])
            if dlg.exec() and dlg.values()["내용"]:
                self.push_undo(); s = dlg.values()["내용"]
                g = Group(gid=self.doc.next_id(), cls="text")
                g.meta = [("type", "text", True), ("tag", E.next_tag(self.doc, "gr_", "_8_"), True)]
                g.prims.append(E._text(p.x(), p.y(), s, size=12.1398, length=len(s) * 7))
                self.doc.add(g); self.rebuild()

    def _update_rubber(self, cur):
        if self._rubber is not None:
            self.scene.removeItem(self._rubber)
        path = QPainterPath(self._pts[0])
        for q in self._pts[1:]:
            path.lineTo(q)
        path.lineTo(cur)
        pen = QPen(QColor("#0a84ff"), 1, Qt.PenStyle.DashLine); pen.setCosmetic(True)
        self._rubber = self.scene.addPath(path, pen); self._rubber.setZValue(1000)

    def tool_move(self, p):
        if self.tool == "wire" and self._pts:
            self._update_rubber(p)
        elif self.tool == "shape" and self._drag0 is not None:
            self.shape_preview(p)
        elif self.tool == "component" and self._drag0 is not None:
            if self._rubber is not None:
                self.scene.removeItem(self._rubber)
            pen = QPen(QColor("#0a84ff"), 1, Qt.PenStyle.DashLine); pen.setCosmetic(True)
            self._rubber = self.scene.addRect(QRectF(self._drag0, p).normalized(), pen); self._rubber.setZValue(1000)

    def tool_release(self, p):
        if self.tool == "shape" and self._drag0 is not None:
            self.shape_finish(p); return
        if self.tool == "component" and self._drag0 is not None:
            r = QRectF(self._drag0, p).normalized()
            self.cancel_tool()
            if r.width() < 8 or r.height() < 8:
                return
            dlg = FormDialog(self, tr("Component"), [("ref (숫자/숫자)", "4/"), ("description", ""), ("harness", "*opt*"), ("variant", "*opt*")])
            if dlg.exec():
                v = dlg.values(); self.push_undo()
                self.doc.add(E.component_group(self.doc, round(r.x(), 3), round(r.y(), 3), round(r.width(), 3), round(r.height(), 3),
                                               v["ref (숫자/숫자)"], v["description"], v["harness"], v["variant"]))
                self.rebuild()

    def finish_wire(self):
        pts = [(q.x(), q.y()) for q in self._pts]
        dedup = []
        for q in pts:
            if not dedup or math.dist(q, dedup[-1]) > 0.5:
                dedup.append(q)
        self.cancel_tool()
        if len(dedup) < 2:
            return
        dlg = FormDialog(self, tr("Wire"), [("ref (신호명+문자)", ""), ("harness", ""), ("variant", "*opt*"), ("option", ""), ("area", "0.35"), ("color", ""), ("option_description", "")])
        if dlg.exec():
            v = dlg.values(); self.push_undo()
            self.doc.add(E.wire_group(self.doc, dedup, v["ref (신호명+문자)"], v["variant"], v["option"], v["harness"], v["area"], v["color"], v["option_description"]))
            self.rebuild()

    # ------------------------------------------------------------------ 규칙
    def run_check(self):
        self.issues = rules.check(self.doc)
        self.issue_list.clear()
        for i in self.issues:
            it = QListWidgetItem("[%s] id-%d %s %s" % (tr("오류") if i.level == "error" else (tr("참고") if i.level == "info" else tr("경고")), i.gid, i.msg, tr("(자동수정 가능)") if i.fixable else ""))
            it.setData(Qt.ItemDataRole.UserRole, i.gid)
            it.setForeground(QColor({"error": "#c0392b", "info": "#7f8c8d"}.get(i.level, "#b9770e")))
            self.issue_list.addItem(it)
        e = sum(1 for i in self.issues if i.level == "error")
        ni = sum(1 for i in self.issues if i.level == "info")
        self.summary.setText(tr("오류 %d, 경고 %d, 자동수정 가능 %d") % (e, len(self.issues) - e - ni, sum(1 for i in self.issues if i.fixable)) + (("  |  " + tr("참고 %d") % ni) if ni else ""))

    def run_fix(self):
        self.push_undo(); n = rules.fix(self.doc); self.sel_prims = []
        self.rebuild(); self.run_check()
        left = sum(1 for i in self.issues if i.level == "error")
        self.statusBar().showMessage(tr("자동 수정 %d건 적용") % n + ("  |  " + tr("남은 오류 %d건은 수동 수정 필요") % left if left else ""))

    def run_auto(self):
        self.push_undo(); n = rules.regenerate_auto_symbols(self.doc); self.sel_prims = []
        self.rebuild(); self.run_check()
        self.statusBar().showMessage(tr("이미지 네비게이션 ID %d개 생성") % n)

    def goto_issue(self, item):
        gid = item.data(Qt.ItemDataRole.UserRole)
        self.sel_prims = []
        self._busy = True
        for i in self.items:
            i.setSelected(i.grp.gid == gid)
        self._busy = False
        self.refresh_all()
        if gid in self.by_gid:
            self.view.centerOn(self.by_gid[gid])

    def closeEvent(self, ev):
        self._tab_save(self.cur)
        if any(t.get("modified") for t in self.tabs):
            r = QMessageBox.question(self, tr("종료 확인"), tr("저장하지 않은 변경 내용이 있습니다. 종료할까요?"))
            if r != QMessageBox.StandardButton.Yes:
                ev.ignore(); return
        ev.accept()


def scrollbar_css(w=None):
    w = int(w or i18n.get_setting("sb_width", 18) or 18)
    return ("QScrollBar:vertical {background:#e6e8eb; width:%dpx; margin:0px;}"
            "QScrollBar:horizontal {background:#e6e8eb; height:%dpx; margin:0px;}"
            "QScrollBar::handle:vertical {background:#8c929b; min-height:48px; border-radius:%dpx; margin:2px;}"
            "QScrollBar::handle:horizontal {background:#8c929b; min-width:48px; border-radius:%dpx; margin:2px;}"
            "QScrollBar::handle:hover {background:#5b626c;} QScrollBar::handle:pressed {background:#1a73e8;}"
            "QScrollBar::add-line, QScrollBar::sub-line {width:0px; height:0px; background:none; border:none;}"
            "QScrollBar::add-page, QScrollBar::sub-page {background:none;}") % (w, w, w // 2 - 2, w // 2 - 2)


def apply_ui_font(pt):
    app = QApplication.instance()
    f = app.font(); f.setPointSize(pt); app.setFont(f)
    app.setStyleSheet("QDockWidget, QMenuBar, QMenu, QToolBar, QToolButton, QTabBar, QStatusBar, QHeaderView, QToolTip {font-size:%dpt}" % pt + scrollbar_css())
    for w in app.allWidgets():
        w.setFont(f) if not isinstance(w, (CodeTree, QPlainTextEdit)) else None


def main(argv=None):
    argv = argv or sys.argv
    i18n.load_lang()
    app = QApplication(argv)
    app.setApplicationName(APP_NAME)
    import licensing
    licensing.enforce_gui()                          # EXE 실행 시 라이선스 키 확인 (개발 실행은 통과)
    f0 = app.font(); f0.setPointSize(MainWindow.ui_font_size()); app.setFont(f0)
    w = MainWindow()
    w.set_ui_font(MainWindow.ui_font_size())
    w.show()
    if len(argv) > 1 and os.path.exists(argv[1]):
        w.open_file(argv[1])
    sys.exit(app.exec())
