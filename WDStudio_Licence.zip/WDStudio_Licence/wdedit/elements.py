"""편집기에서 새 요소를 만들 때 쓰는 템플릿 생성기 (SVG 좌표계)."""
from __future__ import annotations
import re
import math
from model import Group, Prim, fmt, path_points

K = "#000000"


def _text(x, y, s, fam="OF Helvetica", size=8.09323, rot=0, anchor="start", length=None):
    if length is None:
        length = len(s) * size * 0.62
    return Prim("text", {"x": fmt(x), "y": fmt(y), "text-anchor": anchor, "fill": K,
                         "transform": "rotate(%d,%s,%s)" % (rot, fmt(x), fmt(y)), "textLength": fmt(length),
                         "font-family": fam, "font-size": fmt(size)}, s)


def _poly(pts, join="round", cap="butt"):
    d = "M" + " L".join("%s,%s" % (fmt(x), fmt(y)) for x, y in pts)
    return Prim("path", {"d": d, "fill": "none", "stroke": K, "stroke-linecap": cap, "stroke-linejoin": join, "stroke-width": "0.75"})


def next_tag(doc, prefix, suffix="_"):
    n = 950000 + len(doc.groups)
    tags = {g.get("tag") for g in doc.groups}
    while "%s%d%s" % (prefix, n, suffix) in tags:
        n += 1
    return "%s%d%s" % (prefix, n, suffix)


def wire_group(doc, pts, ref="", variant="*opt*", option="", harness="", area="0.35", color="", desc="", wirestyle="2TBD"):
    g = Group(gid=doc.next_id(), cls="wire")
    m = re.match(r"^([A-Z]{1,2}\d+)([A-Z]+)$", ref)
    g.meta = [("type", "physical_wire", True), ("tag", next_tag(doc, "w_"), True), ("ref", ref, True), ("variant", variant, True),
              ("option", option, True), ("harness", harness, False), ("area", area, False), ("signal", m.group(1) if m else "", False),
              ("color", color, False), ("option_description", desc, True)]
    g.prims.append(_poly(pts))
    # 라벨: 가장 긴 구간의 중앙 위
    seg = max(zip(pts, pts[1:]), key=lambda s: math.dist(*s))
    (x0, y0), (x1, y1) = seg
    if ref:
        l1 = "%s %s %s %s" % (ref, wirestyle, area, color)
        l2 = "%s %s %s  " % (harness, variant, option)
        if abs(y1 - y0) <= abs(x1 - x0):
            x = min(x0, x1) + (abs(x1 - x0) - len(l1) * 4.7) / 2
            g.prims += [_text(x, y0 - 2.007, l1), _text(x, y0 + 7.034, l2)]
        else:
            y = max(y0, y1) - (abs(y1 - y0) - len(l1) * 4.7) / 2
            g.prims += [_text(x0 - 1.423, y, l1, rot=270), _text(x0 + 7.62, y, l2, rot=270)]
    return g


def component_group(doc, x, y, w, h, ref, desc, harness="*opt*", variant="*opt*"):
    g = Group(gid=doc.next_id(), cls="symbol")
    m = re.match(r"(\d+)/(\d+)", ref)
    pre = "_%02d_%03d_" % (int(m.group(1)), int(m.group(2))) if m else "_"
    g.meta = [("type", "component", True),
              ("tag", next_tag(doc, pre + re.sub(r"[^A-Za-z0-9]+", "_", desc).strip("_") + "_"), True), ("ref", ref, True),
              ("description", desc, True), ("harness", harness, True), ("variant", variant, True)]
    g.prims.append(Prim("rect", {"x": fmt(x), "y": fmt(y), "width": fmt(w), "height": fmt(h), "stroke": K, "fill": "none", "stroke-width": "3"}))
    g.prims.append(_text(x, y - 28.8, ref, size=12.1398, length=len(ref) * 6.08))
    g.prims.append(_text(x + 38, y - 28.8, desc, "Times New Roman", 12, length=len(desc) * 7.5))
    return g


def inline_group(doc, x, y, ref, vertical=False):
    g = Group(gid=doc.next_id(), cls="symbol")
    g.meta = [("type", "inline_connector", True), ("tag", next_tag(doc, "_inline25__"), True), ("ref", ref, True),
              ("variant", "*opt*", True), ("option", "", True), ("harness", "", False), ("area", "", False),
              ("signal", "", False), ("color", "", False), ("option_description", "", True)]
    d = (0, 1) if vertical else (1, 0)
    n = (-d[1], d[0])
    s = (x - d[0] * 14.585, y - d[1] * 14.585)
    P = lambda u, v=0: (s[0] + d[0] * u + n[0] * v, s[1] + d[1] * u + n[1] * v)

    def seg(a, b, cap="butt"):
        p = _poly([a, b], "miter", cap)
        return p
    g.prims += [seg(P(0), P(10.208)), seg(P(15.68), P(10.208), "round"), seg(P(18.23), P(29.17))]
    a0, a1 = P(14.27, 3.632), P(14.27, -3.632)
    g.prims.append(Prim("path", {"d": "M%s,%s A3.6456,3.6456 0 1,0, %s,%s " % (fmt(a0[0]), fmt(a0[1]), fmt(a1[0]), fmt(a1[1])),
                                 "stroke": K, "fill": "none", "stroke-width": "0.75"}))
    tx, ty = P(24, -10)
    g.prims.append(_text(tx, ty, ref, size=12.1398, anchor="end", length=len(ref) * 5.9))
    return g


def reference_group(doc, x, y, ref):
    g = Group(gid=doc.next_id(), cls="symbol")
    g.meta = [("type", "reference_connector", True), ("tag", next_tag(doc, "_reference__"), True), ("ref", ref, True)]
    g.prims.append(_poly([(x + 11.666, y), (x, y)], "miter"))
    g.prims.append(Prim("ellipse", {"cx": fmt(x + 0.091), "cy": fmt(y - 0.091), "rx": "2.18736", "ry": "2.18736", "stroke": K, "fill": K, "stroke-width": "0.75"}))
    g.prims.append(_text(x - 190, y + 3.7, ref, size=12.1398, length=len(ref) * 6.08))
    return g


def sp_prims(cx, cy, label):
    W = "#ffffff"
    wh = lambda d: Prim("path", {"d": d, "fill": "none", "stroke": W, "stroke-linecap": "butt", "stroke-linejoin": "miter", "stroke-width": "0.75"})
    out = [Prim("ellipse", {"cx": fmt(cx), "cy": fmt(cy), "rx": "5.10384", "ry": "5.10384", "stroke": K, "fill": K, "stroke-width": "0.75"}),
           wh("M%s,%s L%s,%s" % (fmt(cx), fmt(cy - 4.739), fmt(cx), fmt(cy + 4.739))),
           wh("M%s,%s L%s,%s L%s,%s L%s,%s" % (fmt(cx - 3.281), fmt(cy - 3.281), fmt(cx + 3.281), fmt(cy + 3.281), fmt(cx), fmt(cy), fmt(cx + 3.281), fmt(cy - 3.281)) +
              " L%s,%s L%s,%s" % (fmt(cx - 3.281), fmt(cy + 3.281), fmt(cx), fmt(cy))),
           wh("M%s,%s L%s,%s" % (fmt(cx - 4.739), fmt(cy), fmt(cx + 4.739), fmt(cy)))]
    if label:
        out.append(_text(cx + 3.5, cy + 17.3, label, size=12.1398, length=len(label) * 7.3))
    return out


def dot_prim(x, y):
    return Prim("ellipse", {"cx": fmt(x), "cy": fmt(y), "rx": "0.9114", "ry": "0.9114", "stroke": K, "fill": K, "stroke-width": "0.75"})


def twist_prims(x0, y0, label, unshielded=False):
    """x0,y0 = 왼쪽-위 모서리. 폭 14.58 x 높이 29.165"""
    x1, y1 = x0 + 14.58, y0 + 29.165
    out = [Prim("path", {"d": "M%s,%s A7.2912,7.2912 0 1,0, %s,%s " % (fmt(x1), fmt(y0 + .254), fmt(x0), fmt(y0 + .127)), "stroke": K, "fill": "none", "stroke-width": "0.75"}),
           Prim("path", {"d": "M%s,%s A7.2912,7.2912 0 0,0, %s,%s " % (fmt(x0), fmt(y1 + .127), fmt(x1), fmt(y1 - .127)), "stroke": K, "fill": "none", "stroke-width": "0.75"})]
    if unshielded:
        out.append(_poly([(x1, y0), (x1, y1)], "miter"))
        out.append(_poly([(x0, y0), (x0, y1)], "miter"))
    out.append(_poly([(x0, y0), (x1, y1)], "miter"))
    out.append(_poly([(x1, y0), (x0, y1)], "miter"))
    if label:
        out.append(_text(x0 - 10, y1 + 18, label, "Arial", 7.5, length=len(label) * 5.0))
    return out


def nearest_wire(doc, p):
    best, bd, bpt = None, 1e18, None
    for g in doc.groups:
        if g.kind != "wire":
            continue
        for pr in g.prims:
            if pr.tag != "path" or pr.attrs.get("stroke") != K or "fill-rule" in pr.attrs:
                continue
            pts = path_points(pr.attrs["d"])
            for a, b in zip(pts, pts[1:]):
                d, q = _seg(p, a, b)
                if d < bd:
                    best, bd, bpt = g, d, q
    return best, bd, bpt


def _seg(p, a, b):
    ax, ay = a; bx, by = b; px, py = p
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    t = 0 if L2 == 0 else max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / L2))
    q = (ax + t * dx, ay + t * dy)
    return math.hypot(px - q[0], py - q[1]), q
