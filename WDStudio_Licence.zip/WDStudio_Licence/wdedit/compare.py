"""변환 결과(PDF->SVG)와 기준 SVG 비교: 종류별 개수/ref 일치율."""
import sys, re, collections
sys.path.insert(0, '.')
from model import Doc
from export import load_any

def summarize(doc):
    c = collections.Counter(); refs = collections.defaultdict(list)
    sp = tw = us = 0
    for g in doc.groups:
        k = g.kind; t = g.type
        if g.get("tag") == "AUTO_GENERATED": c["auto"] += 1; continue
        c[t or g.cls] += 1
        if t in ("physical_wire", "component", "inline_connector", "reference_connector"):
            refs[t].append(g.get("ref", ""))
        if g.kind == "wire":
            for p in g.prims:
                if p.tag == "ellipse" and p.attrs.get("rx") == "5.10384": sp += 1
                if p.tag == "text" and re.match(r"^T2_25_", p.text): tw += 1
                if p.tag == "text" and re.match(r"^MOAS_", p.text): us += 1
    c["SP"] = sp; c["twist"] = tw; c["unshielded"] = us
    return c, refs

def cmp(pdf, svg):
    d1, imp = load_any(pdf); d0 = Doc.load(svg)
    c1, r1 = summarize(d1); c0, r0 = summarize(d0)
    print("==", pdf.split('/')[-1])
    keys = sorted(set(c0) | set(c1))
    for k in keys:
        flag = "" if c0[k] == c1[k] else "  <<<"
        print("  %-24s ref=%3d conv=%3d%s" % (k, c0[k], c1[k], flag))
    for t in r0:
        a, b = collections.Counter(r0[t]), collections.Counter(r1.get(t, []))
        miss = list((a - b).elements()); extra = list((b - a).elements())
        if miss or extra: print("   %s ref 누락=%s 추가=%s" % (t, miss[:8], extra[:8]))
    return d1, imp

if __name__ == "__main__":
    cmp(sys.argv[1], sys.argv[2])


def detail(pdf, svg):
    """meta 필드/좌표 단위 비교 (원점 오프셋은 첫 component rect 로 보정)."""
    from model import path_points
    d1, _ = load_any(pdf); d0 = Doc.load(svg)
    def rects(d):
        o = {}
        for g in d.groups:
            if g.type == "component" and g.get("tag") != "AUTO_GENERATED":
                r = [p for p in g.prims if p.tag == "rect"]
                if r: o.setdefault(g.get("ref"), (float(r[0].attrs["x"]), float(r[0].attrs["y"])))
        return o
    r0, r1 = rects(d0), rects(d1)
    common = [k for k in r0 if k in r1]
    if not common: print("  (공통 component 없음)"); return
    off = (r0[common[0]][0] - r1[common[0]][0], r0[common[0]][1] - r1[common[0]][1])
    bad = collections.Counter(); tot = collections.Counter(); maxd = 0
    w0 = {g.get("ref"): g for g in d0.groups if g.kind == "wire" and g.get("ref")}
    for g in d1.groups:
        if g.kind != "wire" or not g.get("ref") or g.get("ref") not in w0: continue
        h = w0[g.get("ref")]
        for key in ("variant", "option", "harness", "area", "signal", "color", "option_description"):
            tot[key] += 1
            if g.get(key, "") != h.get(key, ""): bad[key] += 1
        p1 = [path_points(p.attrs["d"]) for p in g.prims if p.tag == "path" and p.attrs.get("stroke") == "#000000"]
        p0 = [path_points(p.attrs["d"]) for p in h.prims if p.tag == "path" and p.attrs.get("stroke") == "#000000"]
        if p1 and p0 and len(p1[0]) == len(p0[0]):
            for a, b in zip(p1[0], p0[0]):
                maxd = max(maxd, abs(a[0] + off[0] - b[0]), abs(a[1] + off[1] - b[1]))
        else:
            bad["path_pts"] += 1
    print("  offset=(%.2f,%.2f) wire path 최대 좌표오차=%.3f" % (off[0], off[1], maxd))
    print("  wire meta 불일치:", dict(bad), "/ 비교", dict(tot).get("variant", 0), "개")
    # component meta
    c0 = {g.get("ref"): g for g in d0.groups if g.type == "component" and g.get("tag") != "AUTO_GENERATED"}
    for g in d1.groups:
        if g.type == "component" and g.get("tag") != "AUTO_GENERATED" and g.get("ref") in c0:
            h = c0[g.get("ref")]
            diff = {k: (g.get(k), h.get(k)) for k in ("description", "harness", "variant", "tag") if g.get(k) != h.get(k)}
            if diff: print("  comp", g.get("ref"), diff)


if __name__ == "__main__" and len(sys.argv) > 3:
    detail(sys.argv[1], sys.argv[2])
