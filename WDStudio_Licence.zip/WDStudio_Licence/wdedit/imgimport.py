"""이미지(래스터)만 들어 있는 PDF(예: Armament List 배치도) 처리.

mode = "image" : 시트 제목 + 이미지(<image>, base64 PNG) 로 SVG 생성 (화면 표시용, 규칙 요소 없음)
mode = "ocr"   : OCR(rapidocr_onnxruntime)로 글자와 상자를 인식해 text / rect 로 재현 (검수 필요)
"""
from __future__ import annotations
import base64
import math
import os
import re

import pymupdf

from model import Doc, Group, Prim, fmt

STROKE = "#000000"
OCR_DPI = 300
IMG_DPI = 200


def page_images(path, page_no=0):
    """페이지에 배치된 이미지의 영역(pt) 목록."""
    d = pymupdf.open(path)
    p = d[page_no]
    out = []
    for info in p.get_image_info():
        r = pymupdf.Rect(info["bbox"])
        if r.width > 60 and r.height > 40:
            out.append(r)
    return out


def has_image_only(path, page_no=0):
    try:
        return bool(page_images(path, page_no))
    except Exception:
        return False


def ocr_available():
    try:
        import rapidocr_onnxruntime  # noqa: F401
        return True
    except Exception:
        return False


def _sheet_name(path):
    stem = os.path.splitext(os.path.basename(path))[0]
    return re.sub(r"^[0-9a-f]{8}-", "", stem)


def build(path, mode="image", page_no=0):
    """(Doc, warnings) 반환."""
    from pdfimport import S0
    d = pymupdf.open(path)
    page = d[page_no]
    k = page.rect.width / 1417.0
    S = S0 * k
    imgs = page_images(path, page_no)
    if not imgs:
        raise ValueError("페이지에서 이미지를 찾지 못했습니다.")
    area = pymupdf.Rect(imgs[0])
    for r in imgs[1:]:
        area |= r
    warn = []
    ox, oy = area.x0 - 40 * S, area.y0 - 70 * S
    W = (area.x1 - ox) / S + 40
    H = (area.y1 - oy) / S + 12
    sheet = _sheet_name(path)

    doc = Doc()
    doc.header = ('<?xml version="1.0" encoding="UTF-8"?>\r\n'
                  '<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.0//EN" "http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd">\r\n'
                  '<!--Created with PDF2WD converter-->\r\n'
                  '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 %s %s">' % (fmt(W), fmt(H)))
    doc.viewbox = [0, 0, round(W, 2), round(H, 2)]
    doc.title = sheet
    bg = Group(gid=2, cls="rectangle", has_meta_block=False)
    bg.prims.append(Prim("rect", {"x": "-0.15", "y": "-0.0345", "width": fmt(W - 0.2325), "height": fmt(H - 0.3765), "stroke": "#ffffff", "fill": "#ffffff", "stroke-width": "0.75"}))
    gr = Group(gid=3, cls="xygrid", has_meta_block=False)
    gr.prims.append(Prim("rect", {"x": "-0.15", "y": "-0.0345", "width": fmt(W - 0.2325), "height": fmt(H - 0.3765), "stroke": "none", "fill": "none", "stroke-width": "0.75"}))
    doc.add(bg); doc.add(gr)
    nid = [4]
    tags = [1060000]

    def new_id():
        nid[0] += 1
        return nid[0]

    def tag(pre, suf="_"):
        tags[0] += 1
        return "%s%d%s" % (pre, tags[0], suf)

    # 시트 이름
    g = Group(gid=new_id(), cls="text")
    g.meta = [("type", "textvar {Sheet Name}", True), ("tag", tag("gr_"), True)]
    L = len(sheet) * 40.4662 * 0.55
    g.prims.append(Prim("text", {"x": fmt(W - L - 20), "y": "33.8645", "text-anchor": "start", "fill": STROKE,
                                 "transform": "rotate(0,%s,33.8645)" % fmt(W - L - 20), "textLength": fmt(L),
                                 "font-family": "OF Helvetica", "font-size": "40.4662"}, sheet))
    doc.add(g)

    def X(v): return (v - ox) / S
    def Y(v): return (v - oy) / S

    if mode == "image":
        for r in imgs:
            pix = page.get_pixmap(dpi=IMG_DPI, clip=r)
            b64 = base64.b64encode(pix.tobytes("png")).decode("ascii")
            g = Group(gid=new_id(), cls="symbol")
            g.meta = [("type", "drawing", True), ("tag", "IMAGE_" + tag("", ""), True)]
            g.prims.append(Prim("image", {"x": fmt(X(r.x0)), "y": fmt(Y(r.y0)), "width": fmt(r.width / S), "height": fmt(r.height / S),
                                          "preserveAspectRatio": "none", "xlink:href": "data:image/png;base64," + b64}))
            doc.add(g)
        warn.append("이미지로 삽입했습니다. (규칙 요소 wire/component 는 만들어지지 않음)")
        return doc, warn

    # ---------------------------------------------------------------- OCR
    if not ocr_available():
        raise RuntimeError("OCR 엔진이 설치되어 있지 않습니다.  pip install rapidocr_onnxruntime")
    import numpy as np
    from rapidocr_onnxruntime import RapidOCR
    eng = RapidOCR()
    ntext = nlow = nrect = 0
    for r in imgs:
        pix = page.get_pixmap(dpi=OCR_DPI, clip=r)
        arr = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
        if pix.n == 4:
            arr = arr[:, :, :3]
        arr = np.ascontiguousarray(arr)
        pt = 72.0 / OCR_DPI                       # px -> pdf pt
        def P(px, py): return X(r.x0 + px * pt), Y(r.y0 + py * pt)

        # 상자(사각형) 검출
        try:
            import cv2
            gray = cv2.cvtColor(arr, cv2.COLOR_RGB2GRAY)
            _, bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
            cons, _ = cv2.findContours(bw, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
            rects = []
            Hh, Ww = gray.shape
            for c in cons:
                per = cv2.arcLength(c, True)
                ap = cv2.approxPolyDP(c, 0.02 * per, True)
                if len(ap) != 4 or not cv2.isContourConvex(ap):
                    continue
                x, y, w, h = cv2.boundingRect(ap)
                if w < 40 or h < 25 or w * h > 0.8 * Ww * Hh:
                    continue
                if cv2.contourArea(ap) < 0.8 * w * h:       # 거의 직사각형인 것만
                    continue
                # 선 굵기 때문에 바깥/안쪽 윤곽이 둘 다 잡히는 경우 -> 안쪽 것 제거(바깥 하나만)
                if any(abs(x - a) < 16 and abs(y - b) < 16 and abs(w - cc) < 28 and abs(h - dd) < 28 for a, b, cc, dd in rects):
                    continue
                rects.append((x, y, w, h))
            if rects:
                g = Group(gid=new_id(), cls="symbol")
                g.meta = [("type", "drawing", True), ("tag", "OCR_SHAPES", True)]
                for x, y, w, h in rects:
                    x0, y0 = P(x, y)
                    g.prims.append(Prim("rect", {"x": fmt(x0), "y": fmt(y0), "width": fmt(w * pt / S), "height": fmt(h * pt / S),
                                                 "stroke": STROKE, "fill": "none", "stroke-width": "0.75"}))
                doc.add(g)
                nrect += len(rects)
        except Exception as ex:                      # opencv 없음 등 : 글자만
            warn.append("상자 검출 생략: %s" % ex)

        res, _ = eng(arr)
        for box, s, conf in (res or []):
            s = (s or "").strip()
            if not s:
                continue
            if float(conf) < 0.45:
                nlow += 1; continue
            (x0, y0), (x1, y1), (x2, y2), (x3, y3) = box
            w = math.hypot(x1 - x0, y1 - y0); h = math.hypot(x3 - x0, y3 - y0)
            if h > 0.07 * arr.shape[0] and w > 0.07 * arr.shape[1] / 3:      # 비정상적으로 큰 오인식 글자
                nlow += 1; continue
            vertical = h > 1.6 * w and len(s) > 2
            if vertical:
                L = h * pt / S; fs = w * pt / S * 0.9
                bx, by = P(x3 + 0.78 * (x2 - x3), y3)          # 아래쪽 + 오른쪽 기준
                tr = "rotate(270,%s,%s)" % (fmt(bx), fmt(by))
            else:
                L = w * pt / S; fs = h * pt / S * 0.85
                bx, by = P(x3, y3 - 0.18 * h)
                tr = "rotate(0,%s,%s)" % (fmt(bx), fmt(by))
            g = Group(gid=new_id(), cls="text")
            g.meta = [("type", "text", True), ("tag", tag("gr_"), True)]
            g.prims.append(Prim("text", {"x": fmt(bx), "y": fmt(by), "text-anchor": "start", "fill": STROKE, "transform": tr,
                                         "textLength": fmt(max(L, 1.0)), "font-family": "OF Helvetica", "font-size": fmt(max(fs, 3.0))}, s))
            doc.add(g); ntext += 1
    try:
        import i18n
        if i18n.get_setting("strip_cjk", True):
            from model import strip_cjk
            nc = strip_cjk(doc)
            if nc:
                warn.append("중국어 글자 %d개를 삭제했습니다." % nc)
    except Exception:
        pass
    warn.append("OCR 로 글자 %d개, 상자 %d개를 인식했습니다 (신뢰도 낮은 글자 %d개 제외). 반드시 원본과 대조해 검수하세요." % (ntext, nrect, nlow))
    return doc, warn
