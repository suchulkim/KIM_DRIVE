@echo off
chcp 65001 >nul
cd /d "%~dp0"
REM 검은 창 없이 WD Studio 실행 (패키지 확인은 창 없이 건너뜀). 오류 확인이 필요하면 run.bat 사용
where pythonw >nul 2>nul
if errorlevel 1 (
  echo pythonw 를 찾을 수 없습니다. run.bat 을 사용하세요.
  pause
  exit /b 1
)
start "" pythonw main.py %*
exit
