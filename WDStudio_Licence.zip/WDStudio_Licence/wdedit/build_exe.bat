@echo off
chcp 65001 >nul
cd /d "%~dp0"
REM Build single-file executable (dist\WDStudio.exe)
python -m pip install PyQt6 pymupdf pyinstaller rapidocr_onnxruntime openpyxl
python -m PyInstaller --noconsole --onefile --name WDStudio main.py --hidden-import gui --hidden-import model --hidden-import pdfimport --hidden-import rules --hidden-import elements --hidden-import export --hidden-import optionmap --hidden-import version --hidden-import icons --hidden-import i18n --hidden-import pdfimport_kx --hidden-import compare --hidden-import imgimport --hidden-import splitpdf --hidden-import shapes --hidden-import sigtable --hidden-import licensing --hidden-import openpyxl --collect-all rapidocr_onnxruntime
echo.
echo Done: dist\WDStudio.exe
pause
