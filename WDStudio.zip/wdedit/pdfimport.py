"""PDF 배선도 -> 템플릿 SVG 자동 구조화 변환기.

PyMuPDF 로 벡터(get_drawings)와 텍스트(rawdict)를 추출하여
wire / component / inline_connector / reference_connector 그룹을 만들고
SP(splice), twist, unshielded 는 물리적으로 연결된 wire 그룹 하위에 넣는다.
"""
from __future__ import annotations
import math
import os
import re
import pymupdf

from model import Doc, Group, Prim, fmt

S = 0.4483008 / 0.75            # PDF pt -> SVG 단위 배율 (SVG = PDF / S)
STROKE = "#000000"

RE_WIRE1 = re.compile(r"^([A-Z]{1,2}\d{3,5}[A-Z]{1,3}) (\S+) ([\d.]+) ([A-Z]{2}(?:/[A-Z]{2})?)\s*$")
RE_WIRE2 = re.compile(r"^([A-Za-z][A-Za-z_0-9]{0,6}) (\S+)(?: (.*?))?\s*$")
RE_SP = re.compile(r"^SP\d+[A-Z]+$")
RE_TWIST = re.compile(r"^T2_25_\w+$")
RE_UNSH = re.compile(r"^MOAS_\w+$")
RE_INLINE = re.compile(r"^94/\d+(\.\d+)?:\d+$")
RE_REFCONN = re.compile(r"^(\d+/\d+|.+:SP\d+[A-Z]+|.+:\d+/\d+(\.\w+)?(:\d+)?)$")
RE_HEADER = re.compile(r"^(\d+/\d+(?:\.\w+)?)\s+(.+)$")
RE_WDID = re.compile(r"^\d+/\d+(\.\w+)?$")


# ----------------------------------------------------------------------------
class T:                      # 텍스트(스팬 단위)
    def __init__(self, s, ox, oy, rot, font, size, bbox, ln):
        self.s, self.ox, self.oy, self.rot = s, ox, oy, rot
        self.font, self.size, self.bbox, self.len = font, size, bbox, ln
        self.used = False
        self.role = None

    @property
    def cx(self): return (self.bbox[0] + self.bbox[2]) / 2

    @property
    def cy(self): return (self.bbox[1] + self.bbox[3]) / 2

    @property
    def end(self):
        a = math.radians(self.rot)
        return (self.ox + math.cos(a) * self.len, self.oy + math.sin(a) * self.len)


class D:                      # 드로잉
    def __init__(self, d):
        self.raw = d
        self.type = d["type"]
        self.w = d.get("width") or 0
        self.color = tuple(round(c) for c in (d.get("color") or (0, 0, 0)))
        self.fill = d.get("fill")
        self.rect = d["rect"]
        self.items = d["items"]
        self.used = False
        kinds = {it[0] for it in self.items}
        self.kinds = kinds
        self.pts = None
        if kinds == {"l"}:
            pts = [(self.items[0][1].x, self.items[0][1].y)]
            for it in self.items:
                pts.append((it[2].x, it[2].y))
            self.pts = pts

    @property
    def white(self): return self.color == (1, 1, 1)

    @property
    def is_line(self): return self.pts is not None and not self.fill

    def length(self):
        return sum(math.dist(a, b) for a, b in zip(self.pts, self.pts[1:])) if self.pts else 0


def _rot(line):
    dx, dy = line["dir"]
    a = round(math.degrees(math.atan2(dy, dx))) % 360
    return {0: 0, 90: 90, 180: 180, 270: 270}.get(a, a)


def extract_texts(page):
    out = []
    raw = page.get_text("rawdict")
    for b in raw["blocks"]:
        for ln in b.get("lines", []):
            rot = _rot(ln)
            for sp in ln["spans"]:
                chars = sp["chars"]
                if not chars:
                    continue
                s = "".join(c["c"] for c in chars)
                if not s.strip():
                    continue
                font = sp["font"]
                x0, y0, x1, y1 = sp["bbox"]
                if rot in (90, 270):
                    L = y1 - y0
                else:
                    L = x1 - x0
                ox, oy = sp["origin"]
                # Type3 의 헤더("4/223 DESC")는 참조번호/설명으로 분할
                m = RE_HEADER.match(s.strip()) if font.startswith("Type3") else None
                if m and " " in s:
                    k = s.index(" ")
                    rest = [c for c in chars[k:] if c["c"] != " "]
                    if rest:
                        ref_chars = chars[:k]
                        dsc_chars = chars[k:]
                        j = next(i for i, c in enumerate(dsc_chars) if c["c"] != " ")
                        dsc_chars = dsc_chars[j:]
                        for part in (ref_chars, dsc_chars):
                            ps = "".join(c["c"] for c in part).rstrip()
                            a = part[0]["origin"]
                            bx0 = min(c["bbox"][0] for c in part); bx1 = max(c["bbox"][2] for c in part)
                            by0 = min(c["bbox"][1] for c in part); by1 = max(c["bbox"][3] for c in part)
                            ll = (by1 - by0) if rot in (90, 270) else (bx1 - bx0)
                            t = T(ps, a[0], a[1], rot, font, sp["size"], (bx0, by0, bx1, by1), ll)
                            t.is_header_part = "ref" if part is ref_chars else "desc"
                            out.append(t)
                        continue
                t = T(s.rstrip(), ox, oy, rot, font, sp["size"], (x0, y0, x1, y1), L)
                out.append(t)
    return out


# ----------------------------------------------------------------------------
def _circle_from_curves(d: D):
    """4개 베지어로 이루어진 원/호의 (cx, cy, r)."""
    xs, ys = [], []
    for it in d.items:
        if it[0] == "c":
            for p in it[1:]:
                xs.append(p.x); ys.append(p.y)
    r = d.rect
    return ((r.x0 + r.x1) / 2, (r.y0 + r.y1) / 2, (r.width + r.height) / 4)


def seg_dist(p, a, b):
    ax, ay = a; bx, by = b; px, py = p
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    t = 0 if L2 == 0 else max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / L2))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def poly_dist(p, pts):
    return min(seg_dist(p, a, b) for a, b in zip(pts, pts[1:])) if len(pts) > 1 else math.dist(p, pts[0])


def _pt_seg_dist(p, a, b):
    ax, ay = a; bx, by = b; px, py = p
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    t = 0 if L2 == 0 else max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / L2))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def inside(p, r, m=0.0):
    return r.x0 + m < p[0] < r.x1 - m and r.y0 + m < p[1] < r.y1 - m


class Importer:
    def __init__(self, path, page_no=0):
        self.path = path
        self.doc_pdf = pymupdf.open(path)
        self.page = self.doc_pdf[page_no]
        self.warn = []
        self.stats = {}

    # -------------------------------------------------------------- 좌표
    def run(self) -> Doc:
        page = self.page
        texts = extract_texts(page)
        draws = [D(d) for d in page.get_drawings()]
        self._frame(draws)
        sheet = self._sheet_name(texts)
        # 도면 영역 밖 / 표제란 제외
        fx0, fy0, fx1, fy1 = self.frame
        keepD = []
        for d in draws:
            r = d.rect
            if r.x0 < fx0 - 0.5 or r.x1 > fx1 + 0.5 or r.y0 < fy0 - 0.5 or r.y1 > fy1 + 0.5:
                continue
            if d.pts and len(d.pts) == 2:        # 프레임 경계선 위의 선
                (a, b), (c, e) = d.pts
                if (abs(a - fx0) < .5 and abs(c - fx0) < .5) or (abs(a - fx1) < .5 and abs(c - fx1) < .5) \
                        or (abs(b - fy0) < .5 and abs(e - fy0) < .5) or (abs(b - fy1) < .5 and abs(e - fy1) < .5):
                    continue
            if self._in_title(r):
                continue
            if d.w and d.w < 0.1 and d.type == "fs" and d.rect.width > 1000:   # 배경 사각형
                continue
            if d.type == "fs" and d.rect.width > 1300:
                continue
            keepD.append(d)
        keepT = []
        for t in texts:
            if not (fx0 - 0.5 <= t.ox <= fx1 + 0.5 and fy0 - 0.5 <= t.oy <= fy1 + 0.5):
                continue
            if self._in_title(pymupdf.Rect(t.bbox)):
                continue
            if t.s == sheet:
                continue
            keepT.append(t)
        self.D, self.T = keepD, keepT
        self.sheet = sheet

        comps = self._components()
        sps = self._splices()
        twists = self._twists()
        inl = self._inlines()
        refc = self._refconns()
        wires = self._wires(comps)
        self._attach_labels(wires)
        self._assign_to_wires(wires, sps, twists)
        self._comp_texts(comps)
        self._comp_meta(comps, wires)
        self.dropped_white = 0
        for d in self.D:
            if not d.used and d.white:
                d.used = True; self.dropped_white += 1
        leftover_t = [t for t in self.T if not t.used]
        leftover_d = [d for d in self.D if not d.used]
        return self._build(sheet, comps, wires, inl, refc, leftover_t, leftover_d)

    def _frame(self, draws):
        hs, vs = [], []
        for d in draws:
            if d.is_line and len(d.pts) == 2 and d.w < 0.6 and not d.white:
                (x0, y0), (x1, y1) = d.pts
                if abs(y0 - y1) < 0.01 and abs(x1 - x0) > 1000:
                    hs.append(y0)
                if abs(x0 - x1) < 0.01 and abs(y1 - y0) > 800:
                    vs.append(x0)
        hs.sort(); vs.sort()
        if len(hs) >= 4 and len(vs) >= 4:
            self.frame = (vs[1], hs[1], vs[-2], hs[-2])
        else:
            r = self.page.rect
            self.frame = (28.74, 18.04, r.width - 28.5, r.height - 17.4)
        self._title = None
        fx0, fy0, fx1, fy1 = self.frame
        for d in draws:
            if d.type == "s" and "re" in d.kinds and d.rect.width > 250 and d.rect.height > 80 \
                    and d.rect.x1 >= fx1 - 6 and d.rect.y1 >= fy1 - 6:
                self._title = d.rect

    def _in_title(self, r):
        if self._title is None:
            return False
        t = self._title
        return r.x0 >= t.x0 - 2 and r.y0 >= t.y0 - 2 and r.x1 <= t.x1 + 2 and r.y1 <= t.y1 + 2

    def _sheet_name(self, texts):
        stem = os.path.splitext(os.path.basename(self.path))[0]
        stem = re.sub(r"^[0-9a-f]{8}-", "", stem)
        for t in texts:
            if t.font.startswith("Helvetica") and re.match(r"^1E\d+\w*_", t.s) and abs(t.size - 8.07) < 0.3:
                return t.s
        return stem

    # -------------------------------------------------------------- 변환
    def tx(self, x):
        return (x - self.ox) / S

    def ty(self, y):
        return (y - self.oy) / S

    def pt(self, p):
        return (self.tx(p[0]), self.ty(p[1]))

    # -------------------------------------------------------------- 컴포넌트
    def _components(self):
        comps = []
        for d in self.D:
            if d.type == "s" and "re" in d.kinds and len(d.items) == 1 and not d.white and \
                    (d.w > 1.8 or d.rect.width * d.rect.height > 1500):
                d.used = True
                comps.append({"rect": d.rect, "prims": [], "texts": [], "hdr_ref": None, "hdr_desc": None,
                              "conn": None, "conns": [], "pins": [], "wires": []})
        comps.sort(key=lambda c: (c["rect"].x0, c["rect"].y0))
        for c in comps:
            r = c["rect"]
            rr = pymupdf.Rect(r.x0 - 1, r.y0 - 1, r.x1 + 1, r.y1 + 1)
            for d in self.D:
                if d.used:
                    continue
                if d.type == "s" and d.kinds <= {"re", "qu"} and not d.white and rr.intersects(d.rect) and \
                        (rr.contains(d.rect) or (d.rect.width < 12 and d.rect.height < 20)):
                    d.used = True
                    c["prims"].append(("rect", d))
                elif d.is_line and not d.white and (any(inside(p, r, 0.8) for p in d.pts) or
                                                    (len(d.pts) == 2 and inside(((d.pts[0][0] + d.pts[1][0]) / 2, (d.pts[0][1] + d.pts[1][1]) / 2), r, 0.8))):
                    d.used = True
                    c["prims"].append(("line", d))
            # 소속 선에 점이 닿는 짧은 보조선(접지 기호 등)을 연쇄로 소속시킴
            changed = True
            while changed:
                changed = False
                claimed = [x for k, x in c["prims"] if k == "line"]
                for d in self.D:
                    if d.used or not d.is_line or d.white or d.length() > 45 or d.w > 1.0:
                        continue
                    near_bar = d.length() < 12 and any(_pt_seg_dist(((d.pts[0][0] + d.pts[-1][0]) / 2, (d.pts[0][1] + d.pts[-1][1]) / 2), a, b) < 9
                                                         for x in claimed for a, b in zip(x.pts, x.pts[1:])) and \
                        len({round(p[0]) for p in d.pts}) > 1 and abs(d.pts[0][1] - d.pts[-1][1]) < 0.1 and \
                        not any(RE_WIRE1.match(t.s) and math.hypot(t.cx - d.pts[0][0], t.cy - d.pts[0][1]) < 30 for t in self.T)
                    if near_bar or any(_pt_seg_dist(p, a, b) < 0.8 for p in d.pts for x in claimed for a, b in zip(x.pts, x.pts[1:])) or \
                            any(_pt_seg_dist(p, a, b) < 0.8 for x in claimed for p in x.pts for a, b in zip(d.pts, d.pts[1:])):
                        d.used = True; c["prims"].append(("line", d)); changed = True
        return comps

    def _comp_texts(self, comps):
        # 참조번호(WDID) 텍스트 -> 가장 가까운 컴포넌트
        for t in self.T:
            if t.used or not re.match(r"^\d+/\d+(\.\w+)?$", t.s):
                continue
            best = None
            for c in comps:
                if inside((t.ox, t.oy), c["rect"]):
                    continue
                dd = self._rdist(t, c["rect"])
                if dd <= 60 and (best is None or dd < best[0]):
                    best = (dd, c)
            if best:
                c = best[1]
                if c["hdr_ref"] is None or self._rdist(t, c["rect"]) < self._rdist(c["hdr_ref"], c["rect"]):
                    c["hdr_ref"] = t
        for c in comps:
            r = c["rect"]
            h = c["hdr_ref"]
            if h:
                h.used = True; h.role = "ref"
                for t in self.T:
                    if t.used or t is h or t.rot != h.rot:
                        continue
                    if ("Times" in t.font or re.match(r"^[A-Z]{1,2}:[\w\-]+$", t.s)) and self._near_rect(t, r, 60) and not inside((t.ox, t.oy), r):
                        if self._same_line(t, h) and c["hdr_desc"] is None:
                            t.used = True; t.role = "desc"; c["hdr_desc"] = t
                        elif not self._same_line(t, h):
                            al = abs(t.ox - h.ox) if h.rot in (0, 180) else abs(t.oy - h.oy)
                            perp = abs(t.oy - h.oy) if h.rot in (0, 180) else abs(t.ox - h.ox)
                            if al < 6 and perp < 30:
                                t.used = True; t.role = "conn"; c["conns"].append((perp, t))
                c["conns"].sort(key=lambda x: x[0])
                c["conns"] = [t for _, t in c["conns"]]
                c["conn"] = c["conns"][0] if c["conns"] else None
            rr = pymupdf.Rect(r.x0 - 1, r.y0 - 1, r.x1 + 1, r.y1 + 1)
            for t in self.T:
                if not t.used and rr.contains(pymupdf.Point(t.ox, t.oy)):
                    t.used = True; t.role = "pin"; c["texts"].append(t)
            for t in self.T:
                if not t.used and "Type3" in t.font and self._near_rect(t, r, 16) and t.s in ("Ag",):
                    t.used = True; t.role = "pin"; c["texts"].append(t)

    @staticmethod
    def _rdist(t, r):
        x0, y0, x1, y1 = t.bbox
        dx = max(r.x0 - x1, 0, x0 - r.x1); dy = max(r.y0 - y1, 0, y0 - r.y1)
        return math.hypot(dx, dy)

    def _near_rect(self, t, r, m):
        return self._rdist(t, r) <= m

    @staticmethod
    def _same_line(a, b):
        if a.rot in (0, 180):
            return abs(a.oy - b.oy) < 3
        return abs(a.ox - b.ox) < 3

    # -------------------------------------------------------------- SP
    def _splices(self):
        sps = []
        for d in self.D:
            if d.used or d.type != "fs" or d.fill is None:
                continue
            if tuple(round(c) for c in d.fill) != (0, 0, 0) or "c" not in d.kinds:
                continue
            cx, cy, r = _circle_from_curves(d)
            if 2.6 <= r <= 3.6:
                d.used = True
                sps.append({"c": (cx, cy), "label": None})
            elif r < 1.0:
                d.used = True            # 접속점(dot) : 재생성
            else:
                pass
        # 흰색 십자선은 재생성
        for d in self.D:
            if d.white and d.is_line and not d.used:
                mx, my = (d.rect.x0 + d.rect.x1) / 2, (d.rect.y0 + d.rect.y1) / 2
                if any(abs(mx - s["c"][0]) < 3.5 and abs(my - s["c"][1]) < 3.5 for s in sps):
                    d.used = True
        for s in sps:
            best = None
            for t in self.T:
                if not t.used and RE_SP.match(t.s):
                    dd = math.hypot(t.cx - s["c"][0], t.cy - s["c"][1])
                    if dd < 60 and (best is None or dd < best[0]):
                        best = (dd, t)
            if best:
                best[1].used = True; best[1].role = "sp"; s["label"] = best[1]
        return sps

    # -------------------------------------------------------------- twist / unshielded
    def _twists(self):
        arcs = []
        for d in self.D:
            if not d.used and d.type == "s" and d.kinds == {"c"}:
                cx, cy, r = _circle_from_curves(d)
                rw, rh = d.rect.width, d.rect.height
                if 3.5 <= max(rw, rh) <= 9.5 and min(rw, rh) >= 3.5:     # 반지름 ~4.36 의 호
                    arcs.append(d)
        tw = []
        used = set()
        for i, a in enumerate(arcs):
            if i in used:
                continue
            for j in range(i + 1, len(arcs)):
                if j in used:
                    continue
                b = arcs[j]
                ra, rb = a.rect, b.rect
                horiz = abs(ra.x0 - rb.x0) < 0.6 and abs(ra.x1 - rb.x1) < 0.6 and 20 < abs(ra.y0 - rb.y0) < 40
                vert = abs(ra.y0 - rb.y0) < 0.6 and abs(ra.y1 - rb.y1) < 0.6 and 20 < abs(ra.x0 - rb.x0) < 40
                if not (horiz or vert):
                    # 긴 unshielded : 한쪽 방향 간격 임의
                    horiz = abs(ra.x0 - rb.x0) < 0.6 and abs(ra.x1 - rb.x1) < 0.6 and abs(ra.y0 - rb.y0) > 8
                    vert = abs(ra.y0 - rb.y0) < 0.6 and abs(ra.y1 - rb.y1) < 0.6 and abs(ra.x0 - rb.x0) > 8
                if horiz or vert:
                    used.add(i); used.add(j)
                    a.used = b.used = True
                    box = pymupdf.Rect(min(ra.x0, rb.x0), min(ra.y0, rb.y0), max(ra.x1, rb.x1), max(ra.y1, rb.y1))
                    tw.append({"box": box, "prims": [a, b], "label": None, "kind": "twist"})
                    break
        for t in tw:
            bb = pymupdf.Rect(t["box"].x0 - 0.7, t["box"].y0 - 0.7, t["box"].x1 + 0.7, t["box"].y1 + 0.7)
            for d in self.D:
                if d.used or not d.is_line:
                    continue
                if d.w > 1.0:
                    continue
                if bb.contains(d.rect) and len(d.pts) == 2:
                    d.used = True
                    t["prims"].append(d)
            cx, cy = (t["box"].x0 + t["box"].x1) / 2, (t["box"].y0 + t["box"].y1) / 2
            best = None
            for x in self.T:
                if x.used:
                    continue
                if RE_TWIST.match(x.s) or RE_UNSH.match(x.s):
                    dd = math.hypot(x.cx - cx, x.cy - cy)
                    if dd < 45 and (best is None or dd < best[0]):
                        best = (dd, x)
            if best:
                best[1].used = True; best[1].role = "twist"; t["label"] = best[1]
                t["kind"] = "unshielded" if RE_UNSH.match(best[1].s) else "twist"
        return tw

    # -------------------------------------------------------------- inline
    def _inlines(self):
        inl = []
        arcs = []
        for d in self.D:
            if not d.used and d.type == "s" and d.kinds == {"c"}:
                rw, rh = d.rect.width, d.rect.height
                if 1.5 <= max(rw, rh) <= 4.8:
                    arcs.append(d)
        for a in arcs:
            cx, cy, _ = _circle_from_curves(a)
            c = (a.rect.x0 + a.rect.x1) / 2, (a.rect.y0 + a.rect.y1) / 2
            stubs = []
            for d in self.D:
                if d.used or not d.is_line or len(d.pts) != 2:
                    continue
                (x0, y0), (x1, y1) = d.pts
                if abs(y0 - y1) < 0.05 and abs(y0 - c[1]) < 0.3 and max(abs(x0 - c[0]), abs(x1 - c[0])) < 10.0:
                    stubs.append((d, "h"))
                elif abs(x0 - x1) < 0.05 and abs(x0 - c[0]) < 0.3 and max(abs(y0 - c[1]), abs(y1 - c[1])) < 10.0:
                    stubs.append((d, "v"))
            blacks = [s for s in stubs if not s[0].white]
            if len(blacks) < 2:
                continue
            first = blacks[0][0]
            (x0, y0), (x1, y1) = first.pts
            dvec = (x1 - x0, y1 - y0)
            n = math.hypot(*dvec) or 1
            dvec = (dvec[0] / n, dvec[1] / n)
            # 시작점 : 두 stub 중 중심에서 가장 먼 바깥 끝점
            ends = [p for s in blacks for p in s[0].pts]
            ax = "h" if blacks[0][1] == "h" else "v"
            key = (lambda p: p[0]) if ax == "h" else (lambda p: p[1])
            ends.sort(key=key)
            lo, hi = ends[0], ends[-1]
            start, end = (lo, hi) if (dvec[0] > 0 or dvec[1] > 0) else (hi, lo)
            dvec = ((end[0] - start[0]), (end[1] - start[1]))
            n = math.hypot(*dvec) or 1
            dvec = (dvec[0] / n, dvec[1] / n)
            for s in stubs:
                s[0].used = True
            a.used = True
            lab = None
            best = None
            for t in self.T:
                if not t.used and RE_INLINE.match(t.s):
                    dd = math.hypot(t.cx - c[0], t.cy - c[1])
                    if dd < 60 and (best is None or dd < best[0]):
                        best = (dd, t)
            if best:
                best[1].used = True; best[1].role = "inline"; lab = best[1]
            inl.append({"start": start, "end": end, "d": dvec, "label": lab, "center": c})
        inl.sort(key=lambda i: (round(i["center"][0]), i["center"][1]))
        return inl

    # -------------------------------------------------------------- reference connector
    def _refconns(self):
        res = []
        for d in self.D:
            if d.used or d.type != "fs" or "c" not in d.kinds or d.fill is None:
                continue
            if tuple(round(c) for c in d.fill) != (0, 0, 0):
                continue
            cx, cy, r = _circle_from_curves(d)
            if not (0.9 <= r <= 2.0):
                continue
            line = None
            for l in self.D:
                if l.used or not l.is_line or len(l.pts) != 2 or l.length() > 12:
                    continue
                if min(math.dist(l.pts[0], (cx, cy)), math.dist(l.pts[1], (cx, cy))) < 1.2:
                    line = l; break
            if not line:
                continue
            d.used = True; line.used = True
            best = None
            for t in self.T:
                if not t.used and RE_REFCONN.match(t.s) and not RE_SP.match(t.s) and not RE_INLINE.match(t.s):
                    dd = math.hypot(t.cx - cx, t.cy - cy)
                    if dd < 150 and (best is None or dd < best[0]):
                        best = (dd, t)
            lab = None
            if best:
                best[1].used = True; best[1].role = "refconn"; lab = best[1]
            lab2 = None
            if lab:        # 라벨 바로 아래 줄(예: 시트 좌표 '5D')
                for t in self.T:
                    if not t.used and t.rot == lab.rot and abs(t.ox - lab.ox) < 2 and 3.0 < t.oy - lab.oy < 12 and len(t.s) <= 4:
                        t.used = True; t.role = "refconn"; lab2 = t; break
            res.append({"c": (cx, cy), "r": r, "line": line, "label": lab, "label2": lab2})
        return res

    # -------------------------------------------------------------- wire
    def _wires(self, comps):
        ws = []
        for d in self.D:
            if d.used or not d.is_line or d.white or d.w > 1.0:
                continue
            if d.length() < 1.0:
                continue
            d.used = True
            ws.append({"pts": d.pts, "l1": None, "l2": None, "sps": [], "tw": [], "d": d})
        ws.sort(key=lambda w: (round(w["pts"][0][1]), w["pts"][0][0]))
        return ws

    def _attach_labels(self, wires):
        first = [t for t in self.T if not t.used and RE_WIRE1.match(t.s)]
        for t in first:
            best = None
            for w in wires:
                dd = poly_dist((t.cx, t.cy), w["pts"])
                if dd < 9 and (best is None or dd < best[0]):
                    best = (dd, w)
            if best and best[1]["l1"] is None:
                best[1]["l1"] = t; t.used = True; t.role = "wire1"
            elif best:
                # 이미 라벨이 있는 wire : 가장 가까운 다른 wire
                alts = sorted(((poly_dist((t.cx, t.cy), w["pts"]), i) for i, w in enumerate(wires) if w["l1"] is None))
                if alts and alts[0][0] < 14:
                    wires[alts[0][1]]["l1"] = t; t.used = True; t.role = "wire1"
        for w in wires:
            t1 = w["l1"]
            if not t1:
                continue
            best = None
            for t in self.T:
                if t.used or t.rot != t1.rot:
                    continue
                if t1.rot in (0, 180):
                    along = abs(t.ox - t1.ox); perp = t.oy - t1.oy
                else:
                    along = abs(t.oy - t1.oy); perp = t.ox - t1.ox
                if along < 2 and 3.0 < perp < 8.5 and RE_WIRE2.match(t.s):
                    if best is None or perp < best[0]:
                        best = (perp, t)
            if best:
                best[1].used = True; best[1].role = "wire2"; w["l2"] = best[1]

    def _assign_to_wires(self, wires, sps, twists):
        for s in sps:
            owners = []
            for i, w in enumerate(wires):
                if any(math.dist(p, s["c"]) < 1.0 for p in (w["pts"][0], w["pts"][-1])):
                    owners.append(i)
            s["owners"] = owners
            if owners:
                wires[owners[0]]["sps"].append(s)
            else:
                best = min(range(len(wires)), key=lambda i: poly_dist(s["c"], wires[i]["pts"])) if wires else None
                if best is not None:
                    wires[best]["sps"].append(s); s["owners"] = [best]
        for t in twists:
            cx, cy = (t["box"].x0 + t["box"].x1) / 2, (t["box"].y0 + t["box"].y1) / 2
            corners = [(t["box"].x0, t["box"].y0), (t["box"].x1, t["box"].y0), (t["box"].x0, t["box"].y1),
                       (t["box"].x1, t["box"].y1), (cx, t["box"].y0), (cx, t["box"].y1), (t["box"].x0, cy), (t["box"].x1, cy)]
            best = None
            for i, w in enumerate(wires):
                dd = min(poly_dist(c, w["pts"]) for c in corners)
                if best is None or dd < best[0]:
                    best = (dd, i)
            if best:
                wires[best[1]]["tw"].append(t)

    def _comp_meta(self, comps, wires):
        for c in comps:
            r = pymupdf.Rect(c["rect"].x0 - 2, c["rect"].y0 - 2, c["rect"].x1 + 2, c["rect"].y1 + 2)
            for w in wires:
                if not w["l2"]:
                    continue
                for p in (w["pts"][0], w["pts"][-1]):
                    if r.contains(pymupdf.Point(*p)):
                        c["wires"].append(w)
                        break

    # -------------------------------------------------------------- 빌드
    def _style(self, t: T, role=None):
        """(font-family, font-size)"""
        f = t.font
        if f.startswith("Type3"):
            big = role in ("ref", "sp", "inline", "refconn")
            return "OF Helvetica", 12.1398 if big else 8.09323
        if "Times" in f:
            return "Times New Roman", round(t.size / S * 2) / 2
        if "Helvetica" in f or "Arial" in f:
            return "Arial", round(t.size / S * 2) / 2
        return "OF Helvetica", round(t.size / S * 2) / 2

    def text_prim(self, t: T, role=None, anchor=None):
        fam, fs = self._style(t, role)
        if anchor == "end":
            ex, ey = t.end
            x, y = self.tx(ex), self.ty(ey)
        else:
            x, y = self.tx(t.ox), self.ty(t.oy)
        a = {"x": fmt(x), "y": fmt(y), "text-anchor": anchor or "start", "fill": "#000000",
             "transform": "rotate(%d,%s,%s)" % (t.rot, fmt(x), fmt(y)),
             "textLength": fmt(t.len / S), "font-family": fam, "font-size": fmt(fs)}
        return Prim("text", a, t.s)

    def path_prim(self, pts, cap="butt", join="round", extra=None):
        d = "M" + " L".join("%s,%s" % (fmt(self.tx(p[0])), fmt(self.ty(p[1]))) for p in pts)
        a = {"d": d, "fill": "none", "stroke": STROKE, "stroke-linecap": cap, "stroke-linejoin": join, "stroke-width": "0.75"}
        return Prim("path", a)

    def _twist_prims(self, tw):
        out = []
        for d in tw["prims"]:
            if d.kinds == {"c"}:
                cs = [it for it in d.items if it[0] == "c"]
                s = cs[0][1]; e = cs[-1][4]; m = cs[len(cs) // 2 - 1][4] if len(cs) > 1 else cs[0][3]
                sx, sy = self.pt((s.x, s.y)); ex, ey = self.pt((e.x, e.y)); mx, my = self.pt((m.x, m.y))
                cross = (mx - sx) * (ey - sy) - (my - sy) * (ex - sx)
                sweep = 1 if cross > 0 else 0
                chord_mid_y = (sy + ey) / 2
                large = 1 if (my < chord_mid_y and abs(ex - sx) > abs(ey - sy)) else 0
                dd = "M%s,%s A7.2912,7.2912 0 %d,%d, %s,%s " % (fmt(sx), fmt(sy), large, sweep, fmt(ex), fmt(ey))
                out.append(Prim("path", {"d": dd, "stroke": STROKE, "fill": "none", "stroke-width": "0.75"}))
            else:
                out.append(self.path_prim(d.pts, join="miter"))
        if tw["label"]:
            out.append(self.text_prim(tw["label"], "twist"))
        return out

    def _sp_prims(self, sp):
        cx, cy = self.pt(sp["c"])
        r = 5.10384
        out = [Prim("ellipse", {"cx": fmt(cx), "cy": fmt(cy), "rx": "5.10384", "ry": "5.10384", "stroke": STROKE, "fill": STROKE, "stroke-width": "0.75"})]
        wh = lambda d: {"d": d, "fill": "none", "stroke": "#ffffff", "stroke-linecap": "butt", "stroke-linejoin": "miter", "stroke-width": "0.75"}
        h = 4.739
        out.append(Prim("path", wh("M%s,%s L%s,%s" % (fmt(cx), fmt(cy - h), fmt(cx), fmt(cy + h)))))
        k = 3.281
        pts = [(cx, cy), (cx - k, cy - k), (cx, cy), (cx + k * .889, cy - k), (cx, cy), (cx + k * 1.111, cy + k), (cx, cy), (cx - k, cy + k)]
        out.append(Prim("path", wh("M" + " L".join("%s,%s" % (fmt(a), fmt(b)) for a, b in pts))))
        out.append(Prim("path", wh("M%s,%s L%s,%s" % (fmt(cx - h), fmt(cy), fmt(cx + h), fmt(cy)))))
        if sp["label"]:
            out.append(self.text_prim(sp["label"], "sp"))
        return out

    def dot(self, p):
        x, y = self.pt(p)
        return Prim("ellipse", {"cx": fmt(x), "cy": fmt(y), "rx": "0.9114", "ry": "0.9114", "stroke": STROKE, "fill": STROKE, "stroke-width": "0.75"})

    def _build(self, sheet, comps, wires, inl, refc, leftT, leftD):
        # 원점/크기 결정 : 사용된 모든 요소의 bbox
        xs, ys = [], []
        def grow(x, y):
            xs.append(x); ys.append(y)
        for w in wires:
            for p in w["pts"]: grow(*p)
        for c in comps:
            grow(c["rect"].x0, c["rect"].y0); grow(c["rect"].x1, c["rect"].y1)
            for t in ([c["hdr_ref"], c["hdr_desc"], c["conn"]] + c["texts"]):
                if t: grow(t.bbox[0], t.bbox[1]); grow(t.bbox[2], t.bbox[3])
        for t in self.T:
            grow(t.bbox[0], t.bbox[1]); grow(t.bbox[2], t.bbox[3])
        for d in self.D:
            grow(d.rect.x0, d.rect.y0); grow(d.rect.x1, d.rect.y1)
        minx, miny, maxx, maxy = min(xs), min(ys), max(xs), max(ys)
        self.ox = minx - 3 * S
        self.oy = miny - 70 * S
        W = (maxx - self.ox) / S + 12
        H = (maxy - self.oy) / S + 12
        doc = Doc()
        doc.header = ('<?xml version="1.0" encoding="UTF-8"?>\r\n'
                      '<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.0//EN" "http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd">\r\n'
                      '<!--Created with PDF2WD converter-->\r\n'
                      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %s %s">' % (fmt(W), fmt(H)))
        doc.viewbox = [0, 0, round(W, 2), round(H, 2)]
        doc.title = sheet
        gid = [3]

        def nid():
            gid[0] += 1
            return gid[0]
        # 배경 / 그리드
        bg = Group(gid=nid() + 28 if False else 2, cls="rectangle", has_meta_block=False)
        bg.prims.append(Prim("rect", {"x": "-0.5", "y": "-0.0345", "width": fmt(W + 1), "height": fmt(H), "stroke": "#ffffff", "fill": "#ffffff", "stroke-width": "0.75"}))
        doc.add(bg)
        gr = Group(gid=3, cls="xygrid", has_meta_block=False)
        gr.prims.append(Prim("rect", {"x": "-0.5", "y": "-0.0345", "width": fmt(W + 1), "height": fmt(H), "stroke": "none", "fill": "none", "stroke-width": "0.75"}))
        doc.add(gr)
        gid[0] = 4
        tagn = [900000]

        def tag(prefix, suffix="_"):
            tagn[0] += 1
            return "%s%d%s" % (prefix, tagn[0], suffix)

        # --- 컴포넌트
        order = []
        for c in comps:
            g = Group(gid=0, cls="symbol")
            ref_raw = c["hdr_ref"].s if c["hdr_ref"] else ""
            ref = re.sub(r"(\d+/\d+)\.\w+$", r"\1", ref_raw)
            desc = c["hdr_desc"].s if c["hdr_desc"] else ""
            m = re.match(r"(\d+)/(\d+)", ref)
            ptag = "_%02d_%03d_" % (int(m.group(1)), int(m.group(2))) if m else "_"
            dtag = re.sub(r"[^A-Za-z0-9]+", "_", desc).strip("_")
            harness = variant = "*opt*"
            if c["wires"]:
                w = c["wires"][0]
                m2 = RE_WIRE2.match(w["l2"].s)
                if m2:
                    harness = m2.group(1); variant = m2.group(2)
            g.meta = [("type", "component", True), ("tag", "%s%s_%s" % (ptag, dtag, tag("AUTO", "_")) if dtag else tag("_AUTO", "_"), True),
                      ("ref", ref, True), ("description", desc, True), ("harness", harness, True), ("variant", variant, True)]
            r = c["rect"]
            g.prims.append(Prim("rect", {"x": fmt(self.tx(r.x0)), "y": fmt(self.ty(r.y0)), "width": fmt(r.width / S), "height": fmt(r.height / S),
                                         "stroke": STROKE, "fill": "none", "stroke-width": "3"}))
            for kind, d in c["prims"]:
                if kind == "rect":
                    rr = d.rect
                    if d.kinds == {"re"}:
                        g.prims.append(Prim("rect", {"x": fmt(self.tx(rr.x0)), "y": fmt(self.ty(rr.y0)), "width": fmt(rr.width / S),
                                                     "height": fmt(rr.height / S), "stroke": STROKE, "fill": "none", "stroke-width": "0.75"}))
                    else:
                        p = [self.pt((rr.x0, rr.y0)), self.pt((rr.x1, rr.y0)), self.pt((rr.x1, rr.y1)), self.pt((rr.x0, rr.y1))]
                        dd = "M" + " L".join("%s,%s" % (fmt(a), fmt(b)) for a, b in p + [p[0]]) + " Z"
                        g.prims.append(Prim("path", {"d": dd, "stroke": STROKE, "fill": "none", "fill-rule": "evenodd", "stroke-width": "0.75"}))
                else:
                    g.prims.append(self.path_prim(d.pts))
            for t, role in [(c["hdr_ref"], "ref"), (c["hdr_desc"], "desc")] + [(x, "conn") for x in c["conns"]]:
                if t:
                    p = self.text_prim(t, role)
                    if role == "desc" or role == "conn":
                        p.attrs["font-family"] = "Times New Roman"; p.attrs["font-size"] = "12"
                    g.prims.append(p)
            for t in c["texts"]:
                g.prims.append(self.text_prim(t, "pin"))
            order.append((r.y0, r.x0, "c", g))
        # --- wire
        def wire_group(w):
            g = Group(gid=0, cls="wire")
            t1, t2 = w["l1"], w["l2"]
            ref = sig = color = area = harness = variant = option = ""
            if t1:
                m = RE_WIRE1.match(t1.s)
                ref, area, color = m.group(1), m.group(3), m.group(4)
                ms = re.match(r"^([A-Z]{1,2}\d+)([A-Z]+)$", ref)
                sig = ms.group(1) if ms else ref
            if t2:
                m2 = RE_WIRE2.match(t2.s)
                harness, variant, option = m2.group(1), m2.group(2), (m2.group(3) or "")
            g.meta = [("type", "physical_wire", True), ("tag", tag("w_"), True), ("ref", ref, True), ("variant", variant or "*opt*", True),
                      ("option", option, True), ("harness", harness, False), ("area", area, False), ("signal", sig, False),
                      ("color", color, False), ("option_description", "STD" if option == "ALL" else "", True)]
            g.prims.append(self.path_prim(w["pts"]))
            for t, role in ((t1, "wire1"), (t2, "wire2")):
                if t:
                    g.prims.append(self.text_prim(t, role))
            return g
        wire_groups = []
        for w in wires:
            g = wire_group(w)
            w["g"] = g
            wire_groups.append((w, g))
        # SP 접속점 : SP 중심과 만나는 wire 끝에 dot, SP 심볼은 첫 소유 wire 에
        for w, g in wire_groups:
            for s in w["sps"]:
                for p in (w["pts"][0], w["pts"][-1]):
                    if math.dist(p, s["c"]) < 1.0:
                        g.prims.append(self.dot(p))
        for w, g in wire_groups:
            for s in w["sps"]:
                g.prims.extend(self._sp_prims(s))
            for t in w["tw"]:
                g.prims.extend(self._twist_prims(t))
        for w, g in wire_groups:
            if g.prims:
                p0 = w["pts"][0]
                order.append((p0[1], p0[0], "w", g))
        # --- inline
        for i in inl:
            g = Group(gid=0, cls="symbol")
            ref = i["label"].s if i["label"] else ""
            ref = re.sub(r"^(94/\d+)\.\d+(:\d+)$", r"\1\2", ref)      # WDID: .숫자 접미 제거
            g.meta = [("type", "inline_connector", True), ("tag", tag("_inline25__"), True), ("ref", ref, True), ("variant", "*opt*", True),
                      ("option", "", True), ("harness", "", False), ("area", "", False), ("signal", "", False), ("color", "", False),
                      ("option_description", "", True)]
            s = self.pt(i["start"]); d = i["d"]
            nx, ny = -d[1], d[0]
            P = lambda u, v=0: (s[0] + d[0] * u + nx * v, s[1] + d[1] * u + ny * v)
            seg = lambda a, b, cap="butt": Prim("path", {"d": "M%s,%s L%s,%s" % (fmt(a[0]), fmt(a[1]), fmt(b[0]), fmt(b[1])), "fill": "none",
                                                          "stroke": STROKE, "stroke-linecap": cap, "stroke-linejoin": "miter", "stroke-width": "0.75"})
            g.prims.append(seg(P(0), P(10.208)))
            g.prims.append(seg(P(15.68), P(10.208), "round"))
            g.prims.append(seg(P(18.23), P(29.17)))
            a0, a1 = P(14.27, 3.632), P(14.27, -3.632)
            g.prims.append(Prim("path", {"d": "M%s,%s A3.6456,3.6456 0 1,0, %s,%s " % (fmt(a0[0]), fmt(a0[1]), fmt(a1[0]), fmt(a1[1])),
                                         "stroke": STROKE, "fill": "none", "stroke-width": "0.75"}))
            if i["label"]:
                g.prims.append(self.text_prim(i["label"], "inline", "end"))
            order.append((i["center"][1], i["center"][0], "i", g))
        # --- reference connector
        for rc in refc:
            g = Group(gid=0, cls="symbol")
            lab = rc["label"].s if rc["label"] else ""
            ref = lab if re.match(r"^\d+/\d+$", lab) else ""
            g.meta = [("type", "reference_connector", True), ("tag", tag("_reference__"), True)]
            if ref:
                g.meta.append(("ref", ref, True))
            elif not re.search(r"\d+/\d+", lab):
                self.warn.append("reference connector '%s' : WDID(31/숫자)를 확인하세요" % lab)
            pts = rc["line"].pts
            c = rc["c"]
            far = max(pts, key=lambda p: math.dist(p, c)); near = min(pts, key=lambda p: math.dist(p, c))
            g.prims.append(self.path_prim([far, near], join="miter"))
            cx, cy = self.pt(c)
            g.prims.append(Prim("ellipse", {"cx": fmt(cx), "cy": fmt(cy), "rx": "2.18736", "ry": "2.18736", "stroke": STROKE, "fill": STROKE, "stroke-width": "0.75"}))
            if rc["label"]:
                g.prims.append(self.text_prim(rc["label"], "refconn"))
            if rc.get("label2"):
                g.prims.append(self.text_prim(rc["label2"], "refconn"))
            order.append((c[1], c[0], "r", g))
        # --- 정렬/ID 부여
        order.sort(key=lambda o: (round(o[0] / 40), o[1]))
        for _, _, _, g in order:
            g.gid = nid()
            doc.add(g)
        # --- 제목(textvar)
        tg = Group(gid=nid(), cls="text")
        tg.meta = [("type", "textvar {Sheet Name}", True), ("tag", tag("gr_", "_4_"), True)]
        tl = max(8.0, len(sheet) * 22.5)
        tg.prims.append(Prim("text", {"x": fmt(W - tl - 6), "y": "33.8645", "text-anchor": "start", "fill": "#000000",
                                      "transform": "rotate(0,%s,33.8645)" % fmt(W - tl - 6), "textLength": fmt(tl),
                                      "font-family": "OF Helvetica", "font-size": "40.4662"}, sheet))
        doc.add(tg)
        tb = Group(gid=nid(), cls="symbol")
        tb.meta = [("type", "drawing", True), ("tag", "WD_TitleBlock_GEELY_190517_%d_" % tagn[0], True)]
        doc.add(tb)
        # --- 남은 텍스트 / 도형 (손실 방지)
        for t in leftT:
            g = Group(gid=nid(), cls="text")
            g.meta = [("type", "text", True), ("tag", tag("gr_", "_8_"), True)]
            g.prims.append(self.text_prim(t, None))
            doc.add(g)
        if leftD:
            g = Group(gid=nid(), cls="symbol")
            g.meta = [("type", "drawing", True), ("tag", "UNCLASSIFIED_SHAPES", True)]
            for d in leftD:
                if d.pts and not d.white:
                    g.prims.append(self.path_prim(d.pts, join="miter"))
                elif d.kinds == {"re"} or d.kinds == {"qu"}:
                    rr = d.rect
                    g.prims.append(Prim("rect", {"x": fmt(self.tx(rr.x0)), "y": fmt(self.ty(rr.y0)), "width": fmt(rr.width / S),
                                                 "height": fmt(rr.height / S), "stroke": STROKE, "fill": "none", "stroke-width": "0.75"}))
            if g.prims:
                doc.add(g)
                self.warn.append("분류되지 않은 도형 %d개를 'UNCLASSIFIED_SHAPES' 그룹으로 보존했습니다." % len(g.prims))
        for g in doc.groups:
            g.raw = None
        self.stats = {
            "wire": len(wires), "wire_labeled": sum(1 for w in wires if w["l1"]), "component": len(comps),
            "inline": len(inl), "reference": len(refc), "sp": sum(len(w["sps"]) for w in wires),
            "twist": sum(1 for w in wires for t in w["tw"] if t["kind"] == "twist"),
            "unshielded": sum(1 for w in wires for t in w["tw"] if t["kind"] == "unshielded"),
            "leftover_text": len(leftT), "leftover_shapes": len(leftD),
        }
        return doc


def import_pdf(path, page_no=0):
    imp = Importer(path, page_no)
    doc = imp.run()
    import rules
    import optionmap
    imp.stats["option_desc"] = optionmap.apply(doc)             # option 코드 -> option_description 사전
    imp.stats["auto"] = rules.regenerate_auto_symbols(doc)   # 컴포넌트/인라인/reference 의 AUTO_GENERATED 블록
    return doc, imp
