@echo off
chcp 65001 >nul
cd /d "%~dp0"
REM 배선도 편집기 실행 (필요 패키지 자동 설치)
python -c "import PyQt6, pymupdf" 2>/dev/null || (
  echo 필요한 패키지를 설치합니다...
  python -m pip install PyQt6 pymupdf
)
python main.py %*
if errorlevel 1 pause
