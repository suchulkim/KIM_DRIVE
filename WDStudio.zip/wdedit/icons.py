"""툴바/메뉴 아이콘 (QPainter 로 직접 그림 - 외부 이미지 파일 불필요)."""
import math
from PyQt6.QtCore import Qt, QPointF, QRectF
from PyQt6.QtGui import QColor, QIcon, QPainter, QPen, QPixmap, QPolygonF, QBrush, QFont, QPainterPath

BLUE = QColor("#1f5fbf"); DARK = QColor("#2b2b2b"); RED = QColor("#c0392b"); GREEN = QColor("#2e8b57"); GRAY = QColor("#666666")


def _make(draw, size=24):
    pm = QPixmap(size * 2, size * 2)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.scale(2, 2)
    draw(p)
    p.end()
    pm.setDevicePixelRatio(2)
    return QIcon(pm)


def _pen(c=DARK, w=1.6):
    pen = QPen(c, w); pen.setCapStyle(Qt.PenCapStyle.RoundCap); pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin); return pen


def _select(p):
    p.setPen(_pen(DARK, 1.2)); p.setBrush(QBrush(QColor("#ffffff")))
    p.drawPolygon(QPolygonF([QPointF(6, 3), QPointF(6, 19), QPointF(10, 15), QPointF(13, 21), QPointF(15.5, 20), QPointF(12.5, 14), QPointF(18, 14)]))


def _pan(p):
    p.setPen(_pen(DARK, 1.3)); p.setBrush(QBrush(QColor("#ffe9b0")))
    p.drawRoundedRect(QRectF(7, 10, 11, 10), 3, 3)
    for i, x in enumerate((8, 11, 14, 17)):
        top = 4 + (1 if i in (0, 3) else 0) * 2
        p.drawRoundedRect(QRectF(x - 1.2, top, 2.4, 9), 1.2, 1.2)
    p.drawLine(QPointF(7.5, 14), QPointF(4.5, 11.5))


def _wire(p):
    p.setPen(_pen(BLUE, 2)); p.drawPolyline(QPolygonF([QPointF(3, 18), QPointF(9, 18), QPointF(9, 7), QPointF(21, 7)]))
    p.setBrush(QBrush(BLUE)); p.drawEllipse(QPointF(3, 18), 2, 2); p.drawEllipse(QPointF(21, 7), 2, 2)


def _component(p):
    p.setPen(_pen(DARK, 2)); p.setBrush(QBrush(QColor("#dce8fb"))); p.drawRect(QRectF(7, 4, 11, 16))
    p.setPen(_pen(DARK, 1.2))
    for y in (8, 12, 16): p.drawLine(QPointF(3, y), QPointF(7, y)); p.drawLine(QPointF(18, y), QPointF(22, y))


def _inline(p):
    p.setPen(_pen(DARK, 1.6)); p.drawLine(QPointF(2, 12), QPointF(9, 12)); p.drawLine(QPointF(16, 12), QPointF(22, 12))
    p.setBrush(Qt.BrushStyle.NoBrush); p.drawArc(QRectF(8, 6, 9, 12), 90 * 16, -180 * 16 * -1)
    p.setBrush(QBrush(DARK)); p.drawEllipse(QPointF(11.5, 12), 1.3, 1.3)


def _reference(p):
    p.setPen(_pen(DARK, 1.6)); p.drawLine(QPointF(3, 12), QPointF(13, 12))
    p.setBrush(QBrush(DARK)); p.drawEllipse(QPointF(13, 12), 2.2, 2.2)
    p.setPen(_pen(GRAY, 1.3)); p.drawLine(QPointF(16, 9), QPointF(22, 9)); p.drawLine(QPointF(16, 14), QPointF(22, 14))


def _splice(p):
    p.setPen(_pen(DARK, 1.6)); p.drawLine(QPointF(2, 12), QPointF(22, 12))
    p.setBrush(QBrush(QColor("#555"))); p.drawEllipse(QPointF(12, 12), 5.5, 5.5)
    p.setPen(_pen(QColor("white"), 1.2)); p.drawLine(QPointF(8.5, 8.5), QPointF(15.5, 15.5)); p.drawLine(QPointF(15.5, 8.5), QPointF(8.5, 15.5))


def _twist(p):
    p.setPen(_pen(DARK, 1.5)); p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawLine(QPointF(3, 12), QPointF(7, 12)); p.drawLine(QPointF(17, 12), QPointF(21, 12))
    p.drawArc(QRectF(7, 5, 10, 14), 0, 180 * 16); p.drawArc(QRectF(7, 5, 10, 14), 180 * 16, 180 * 16)
    p.drawLine(QPointF(8, 6), QPointF(16, 18)); p.drawLine(QPointF(16, 6), QPointF(8, 18))


def _unshielded(p):
    _twist(p); p.setPen(_pen(RED, 1.4)); p.drawLine(QPointF(7, 6), QPointF(7, 18)); p.drawLine(QPointF(17, 6), QPointF(17, 18))


def _text(p):
    p.setPen(_pen(DARK, 1)); f = QFont("Times New Roman", 15); f.setBold(True); p.setFont(f)
    p.drawText(QRectF(2, 1, 20, 22), Qt.AlignmentFlag.AlignCenter, "T")


def _open(p):
    p.setPen(_pen(DARK, 1.3)); p.setBrush(QBrush(QColor("#ffd86b")))
    p.drawPolygon(QPolygonF([QPointF(2, 7), QPointF(9, 7), QPointF(11, 9), QPointF(21, 9), QPointF(21, 20), QPointF(2, 20)]))


def _save(p):
    p.setPen(_pen(DARK, 1.3)); p.setBrush(QBrush(QColor("#7aa7e8"))); p.drawRoundedRect(QRectF(3, 3, 18, 18), 2, 2)
    p.setBrush(QBrush(QColor("white"))); p.drawRect(QRectF(7, 3, 10, 7)); p.drawRect(QRectF(7, 14, 10, 7))


def _pdf(p):
    p.setPen(_pen(DARK, 1.3)); p.setBrush(QBrush(QColor("white"))); p.drawRect(QRectF(5, 2, 14, 20))
    p.setPen(_pen(RED, 1)); f = QFont("Arial", 6); f.setBold(True); p.setFont(f); p.drawText(QRectF(5, 8, 14, 8), Qt.AlignmentFlag.AlignCenter, "PDF")


def _check(p):
    p.setPen(_pen(GREEN, 2.6)); p.drawPolyline(QPolygonF([QPointF(4, 13), QPointF(10, 19), QPointF(20, 6)]))


def _fix(p):
    p.setPen(_pen(DARK, 1.2)); p.setBrush(QBrush(QColor("#f0b429")))
    p.save(); p.translate(12, 12); p.rotate(-45)
    p.drawRoundedRect(QRectF(-2.2, -3, 4.4, 17), 1.5, 1.5); p.drawEllipse(QPointF(0, -6), 5, 5)
    p.restore()


def _fit(p):
    p.setPen(_pen(DARK, 1.8))
    for sx, sy in ((1, 1), (-1, 1), (1, -1), (-1, -1)):
        x = 12 - sx * 9; y = 12 - sy * 9
        p.drawLine(QPointF(x, y), QPointF(x + sx * 5, y)); p.drawLine(QPointF(x, y), QPointF(x, y + sy * 5))


def _undo(p):
    p.setPen(_pen(DARK, 2)); p.setBrush(Qt.BrushStyle.NoBrush); p.drawArc(QRectF(5, 7, 14, 11), 0, 180 * 16 * -1 if False else 180 * 16)
    p.drawLine(QPointF(5, 12), QPointF(2.5, 8)); p.drawLine(QPointF(5, 12), QPointF(9, 10.5))


def _redo(p):
    p.save(); p.translate(24, 0); p.scale(-1, 1); _undo(p); p.restore()


def _help(p):
    p.setPen(_pen(BLUE, 1.5)); p.setBrush(QBrush(QColor("#e7f0ff"))); p.drawEllipse(QPointF(12, 12), 9, 9)
    f = QFont("Arial", 12); f.setBold(True); p.setFont(f); p.drawText(QRectF(3, 3, 18, 18), Qt.AlignmentFlag.AlignCenter, "?")


def _info(p):
    p.setPen(_pen(BLUE, 1.5)); p.setBrush(QBrush(QColor("#e7f0ff"))); p.drawEllipse(QPointF(12, 12), 9, 9)
    f = QFont("Arial", 12); f.setBold(True); p.setFont(f); p.drawText(QRectF(3, 3, 18, 18), Qt.AlignmentFlag.AlignCenter, "i")


def _scissors(p):
    p.setPen(_pen(DARK, 1.5)); p.drawEllipse(QPointF(7, 18), 2.5, 2.5); p.drawEllipse(QPointF(17, 18), 2.5, 2.5)
    p.drawLine(QPointF(8.5, 16), QPointF(17, 4)); p.drawLine(QPointF(15.5, 16), QPointF(7, 4))


def _copy(p):
    p.setPen(_pen(DARK, 1.3)); p.setBrush(QBrush(QColor("white"))); p.drawRect(QRectF(4, 4, 11, 14)); p.drawRect(QRectF(9, 8, 11, 13))


def _paste(p):
    p.setPen(_pen(DARK, 1.3)); p.setBrush(QBrush(QColor("#ffd86b"))); p.drawRoundedRect(QRectF(4, 4, 16, 18), 2, 2)
    p.setBrush(QBrush(QColor("white"))); p.drawRect(QRectF(8, 9, 12, 13)); p.drawRect(QRectF(9, 2, 6, 4))


def _delete(p):
    p.setPen(_pen(RED, 2.2)); p.drawLine(QPointF(6, 6), QPointF(18, 18)); p.drawLine(QPointF(18, 6), QPointF(6, 18))


def _lang(p):
    p.setPen(_pen(BLUE, 1.3)); p.setBrush(Qt.BrushStyle.NoBrush); p.drawEllipse(QPointF(12, 12), 9, 9)
    p.drawEllipse(QRectF(7, 3, 10, 18)); p.drawLine(QPointF(3, 12), QPointF(21, 12))


_DRAW = {"select": _select, "pan": _pan, "wire": _wire, "component": _component, "inline": _inline, "reference": _reference,
         "sp": _splice, "twist": _twist, "unshielded": _unshielded, "text": _text, "open": _open, "save": _save, "pdf": _pdf,
         "check": _check, "fix": _fix, "fit": _fit, "undo": _undo, "redo": _redo, "help": _help, "info": _info,
         "cut": _scissors, "copy": _copy, "paste": _paste, "delete": _delete, "lang": _lang, "auto": _fix}
_cache = {}


def icon(name):
    if name not in _cache:
        _cache[name] = _make(_DRAW[name]) if name in _DRAW else QIcon()
    return _cache[name]
