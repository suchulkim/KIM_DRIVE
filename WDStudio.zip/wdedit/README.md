# WD Studio
PDF 배선도 -> 배선도 템플릿/WDID 규칙에 맞는 SVG 자동 변환 + GUI 편집 + PDF/SVG 출력.

실행: `run.bat` 더블클릭 (또는 `python main.py [file.pdf|file.svg]`)  /  단독 exe: `build_exe.bat` -> dist\WDStudio.exe
CLI : `python main.py --convert in.pdf out.svg [--pdf out.pdf] [--fix] [--auto] [--check]`
설치: `pip install PyQt6 pymupdf`

구성: model.py(SVG 모델, AIM SVG 바이트 단위 무손실 왕복) pdfimport.py(PDF 자동 구조화) rules.py(규칙 검사/자동수정)
elements.py(템플릿 요소 생성) export.py(SVG/PDF 출력) optionmap.py(option->option_description 사전, option_map.json)
compare.py(변환 결과 vs 기준 SVG 비교: `python compare.py in.pdf ref.svg [x]`) gui.py(PyQt6 편집기)

변경 이력
- v0.2 (2026-11-05) 새 기준 SVG(6A5/6B1/6B2/6C1)로 검증/개선
  * wire ref 영문 1~2자 형식 지원(G0750A, V8365G ...), 하네스 소문자(Int) 지원
  * 컴포넌트 내부 사각형/가로지르는 선/접지기호 소속 처리, 커넥터 줄(A:..., B:...) 여러 줄 지원
  * reference connector 라벨(`시트:31/403.GND`)+좌표(`5D`), AUTO_GENERATED 블록 변환 시 자동 생성(컴포넌트/inline/reference)
  * option 코드 -> option_description 사전, inline ref `.n` 접미 제거
  * 저장 시 AIM 원본 바이트 보존(기준 SVG 5종 왕복 동일)

한계: 컴포넌트 harness/variant, 일부 option_description, 비표준 라벨(PDF 밖으로 잘린 텍스트)은 사람 확인 필요.


## v0.3.0 (2026-11-05) 개발자: 김수철 (KIM SUCHUL)
- 아이콘+텍스트 툴바, 선택/이동(Pan) 드롭다운, 캔버스 여백·용지 경계선
- DevTools 식 선택 강조(파란 오버레이 + `g#id-N.class W × H`), SVG 코드 트리(드래그로 다른 id 이동, 잘라내기/복사/붙여넣기)
- 속성 패널: visible data 속성 편집(양방향 즉시 반영), 코드 직접 편집
- 규칙 설명(메뉴/도움말), 흩어진 text 병합(SCATTERED_TEXT), 한국어/English 설정, 정보창
