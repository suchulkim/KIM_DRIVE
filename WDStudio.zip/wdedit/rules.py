"""배선도 템플릿 / WDID 규칙 검사 및 자동 수정."""
from __future__ import annotations
import re
from dataclasses import dataclass
from model import Doc, Group, Prim, fmt

EXCEPT_WDID = {"N_PT SENSOR", "N_CPD1", "N_CPD2", "EGG01C", "EGG02", "N_94/2", "N_4/171.1",
               "N_2FR", "N_2HR", "N_2GR", "N_2FL", "N_2HL", "N_2GL", "N_3HL", "N_2LL"}
RE_GEN = re.compile(r"^\d+/\d+$")
RE_INL = re.compile(r"^94/\d+:\d+$")
RE_WIRE_REF = re.compile(r"^([A-Z]{1,2}\d+)([A-Z]+)$")
WIRE_KEYS = ["variant", "option", "harness", "area", "signal", "color", "option_description"]
RE_SP = re.compile(r"^SP\d+[A-Z]+$")
RE_TW = re.compile(r"^(T2_25_\w+|MOAS_\w+)$")


@dataclass
class Issue:
    gid: int
    level: str          # error | warn
    code: str
    msg: str
    fixable: bool = False


def strip_decimal(ref: str) -> str:
    return re.sub(r"^(\d+/\d+)\.\w+$", r"\1", ref)


def _texts(g):
    return [p.text for p in g.prims if p.tag == "text"]


def check(doc: Doc) -> list:
    out = []
    seen = {}
    for g in doc.groups:
        seen.setdefault(g.gid, []).append(g)
    for gid, gs in seen.items():
        if len(gs) > 1:
            for g in gs[1:]:
                out.append(Issue(gid, "error", "DUP_ID", "id-%d 가 중복됩니다." % gid, True))
    for g in doc.groups:
        k, t = g.kind, g.type
        if g.cls in ("rectangle", "xygrid", "text") or k == "drawing":
            continue
        if t in ("physical_splice_connector",) or (t == "cable" and re.match(r"(unshielded|unshieldedtwist)", g.get("tag", ""))) \
                or (g.cls == "symbol" and any(RE_SP.match(x) or RE_TW.match(x) for x in _texts(g)) and k not in ("wire",)):
            if g.get("tag") != "AUTO_GENERATED":
                out.append(Issue(g.gid, "error", "SEPARATE_SPLICE",
                                 "Splice/twist/unshielded 가 별도 id 로 구성됨 : 물리적으로 연결된 wire 하위로 이동해야 함", True))
        if k == "wire":
            for key in ["tag", "ref"] + WIRE_KEYS:
                if not g.has(key):
                    out.append(Issue(g.gid, "error", "WIRE_META", "wire meta '%s' 누락" % key, True))
            ref = g.get("ref", "")
            m = RE_WIRE_REF.match(ref)
            if ref and not m:
                out.append(Issue(g.gid, "warn", "WIRE_REF", "wire ref '%s' 형식(신호명+문자) 아님" % ref))
            elif m and g.get("signal") and g.get("signal") != m.group(1):
                out.append(Issue(g.gid, "error", "WIRE_SIGNAL", "signal(%s) 이 ref(%s) 와 불일치" % (g.get("signal"), ref), True))
            tx = _texts(g)
            if ref and tx and not any(x.startswith(ref + " ") for x in tx):
                out.append(Issue(g.gid, "warn", "WIRE_LABEL", "라벨 텍스트가 ref '%s' 와 다름" % ref))
            if not any(p.tag == "path" for p in g.prims):
                out.append(Issue(g.gid, "error", "WIRE_PATH", "wire 에 path 없음"))
        elif t == "component":
            if g.get("tag") == "AUTO_GENERATED":
                continue
            ref = g.get("ref", "")
            if ref in EXCEPT_WDID:
                continue
            if not RE_GEN.match(ref):
                fx = bool(RE_GEN.match(strip_decimal(ref)))
                out.append(Issue(g.gid, "error", "WDID", "component ref '%s' 는 숫자/숫자 형식이어야 함" % ref, fx))
            for key in ("description", "harness", "variant"):
                if not g.has(key):
                    out.append(Issue(g.gid, "warn", "COMP_META", "component meta '%s' 누락" % key, True))
        elif t == "inline_connector":
            ref = g.get("ref", "")
            if ref in EXCEPT_WDID:
                continue
            if not RE_INL.match(ref):
                lab = next((x for x in _texts(g) if re.match(r"^94/\d+(\.\d+)?:\d+$", x)), None)
                fx = bool(lab)
                out.append(Issue(g.gid, "error", "WDID_INLINE", "inline connector ref '%s' 는 94/번호:핀 형식이어야 함" % ref, fx))
        elif t == "reference_connector":
            ref = g.get("ref", "")
            if ref in EXCEPT_WDID or not g.has("ref"):
                continue          # ref meta 가 없는 reference connector 는 AUTO_GENERATED 블록이 ref 를 가짐
            if not RE_GEN.match(ref):
                out.append(Issue(g.gid, "error", "WDID_REF", "reference connector ref '%s' 는 숫자/숫자(예 31/8) 형식이어야 함" % ref,
                                 bool(RE_GEN.match(strip_decimal(ref)))))
    for g in doc.groups:
        t = _free_text_target(doc, g)
        if t is not None:
            out.append(Issue(g.gid, "warn", "SCATTERED_TEXT",
                             "visible data(text)가 별도 id 로 흩어져 있음 : id-%d(%s) 하위로 병합해야 함" % (t.gid, t.kind), True))
    return out


RE_WLABEL1 = re.compile(r"^[A-Z]{1,2}\d{3,5}[A-Z]{1,3} \S+ [\d.]+ \S+$")
RE_ILABEL = re.compile(r"^94/\d+(\.\d+)?:\d+$")


def _free_text_target(doc: Doc, g: Group):
    """별도 id 로 흩어진 text 그룹이 속해야 할 그룹을 찾는다. 없으면 None."""
    tp = [p for p in g.prims if p.tag == "text"]
    if g.cls != "text" or g.type != "text" or len(tp) != 1 or len(g.prims) != 1:
        return None
    bb = tp[0].bbox()
    if not bb:
        return None
    cx, cy = (bb[0] + bb[2]) / 2, (bb[1] + bb[3]) / 2
    txt = tp[0].text
    from model import path_points
    # (1) component 사각형 안(헤더 바로 위 포함) -> component
    for c in doc.groups:
        if c.type == "component" and c.get("tag") != "AUTO_GENERATED":
            r = next((p for p in c.prims if p.tag == "rect"), None)
            if r:
                x, y, w, h = (float(r.attrs[k]) for k in ("x", "y", "width", "height"))
                if x - 2 <= cx <= x + w + 2 and y - 2 <= cy <= y + h + 2:
                    return c
    # (2) wire 라벨 -> 가장 가까운 wire
    if RE_WLABEL1.match(txt):
        best, bd = None, 12.0
        for w in doc.groups:
            if w.kind != "wire":
                continue
            for p in w.prims:
                if p.tag == "path" and p.attrs.get("stroke") == "#000000":
                    pts = path_points(p.attrs["d"])
                    for a, b in zip(pts, pts[1:]):
                        d = _segd((cx, cy), a, b)
                        if d < bd:
                            best, bd = w, d
        return best
    # (3) inline 라벨 -> 가까운 inline connector
    if RE_ILABEL.match(txt):
        best, bd = None, 40.0
        for i in doc.groups:
            if i.type == "inline_connector":
                bb2 = i.bbox()
                if bb2:
                    d = max(0, bb2[0] - cx, cx - bb2[2]) + max(0, bb2[1] - cy, cy - bb2[3])
                    if d < bd:
                        best, bd = i, d
        return best
    return None


def merge_scattered_text(doc: Doc) -> int:
    n = 0
    for g in list(doc.groups):
        t = _free_text_target(doc, g)
        if t is not None:
            t.prims.extend(g.prims); t.dirty(); doc.remove(g); n += 1
    return n


def fix(doc: Doc, only=None) -> int:
    """자동 수정 가능한 항목 처리. 수정 건수 반환."""
    n = 0
    # 중복 id
    used = set()
    for g in doc.groups:
        if g.gid in used:
            g.gid = max(max(x.gid for x in doc.groups) + 1, 3)
            g.dirty(); n += 1
        used.add(g.gid)
    for g in doc.groups:
        k, t = g.kind, g.type
        if k == "wire":
            tx = _texts(g)
            first = next((x for x in tx if re.match(r"^[A-Z]{1,2}\d+[A-Z]+ ", x)), None)
            if not g.has("ref") and first:
                g.set("ref", first.split(" ")[0])
                n += 1
            m = RE_WIRE_REF.match(g.get("ref", ""))
            for key in WIRE_KEYS:
                if not g.has(key):
                    g.set(key, "*opt*" if key == "variant" else "", key in ("variant", "option", "option_description"))
                    n += 1
            if m and g.get("signal") != m.group(1):
                g.set("signal", m.group(1), False); n += 1
            if not g.has("tag"):
                g.set("tag", "w_%d_" % (900000 + g.gid)); n += 1
        elif t == "component" and g.get("tag") != "AUTO_GENERATED":
            ref = g.get("ref", "")
            if ref not in EXCEPT_WDID and not RE_GEN.match(ref) and RE_GEN.match(strip_decimal(ref)):
                g.set("ref", strip_decimal(ref)); n += 1
            for key in ("description", "harness", "variant"):
                if not g.has(key):
                    g.set(key, "*opt*" if key != "description" else ""); n += 1
        elif t == "inline_connector":
            ref = g.get("ref", "")
            if ref not in EXCEPT_WDID and not RE_INL.match(ref):
                lab = next((x for x in _texts(g) if re.match(r"^94/\d+(\.\d+)?:\d+$", x)), None)
                if lab:
                    g.set("ref", re.sub(r"^(94/\d+)\.\d+(:\d+)$", r"\1\2", lab)); n += 1
        elif t == "reference_connector":
            ref = g.get("ref", "")
            if ref and ref not in EXCEPT_WDID and not RE_GEN.match(ref) and RE_GEN.match(strip_decimal(ref)):
                g.set("ref", strip_decimal(ref)); n += 1
    import optionmap
    n += optionmap.apply(doc)
    n += move_separate_symbols(doc)
    n += merge_scattered_text(doc)
    return n


def move_separate_symbols(doc: Doc) -> int:
    """별도 id 로 구성된 splice / twist / unshielded 를 가장 가까운 wire 하위로 이동."""
    wires = [g for g in doc.groups if g.kind == "wire"]
    n = 0
    for g in list(doc.groups):
        bad = g.type == "physical_splice_connector" or (g.type == "cable" and re.match(r"(unshielded|unshieldedtwist)", g.get("tag", ""))) \
            or (g.cls == "symbol" and g.kind not in ("wire", "component", "inline_connector", "reference_connector", "drawing")
                and any(RE_SP.match(x) or RE_TW.match(x) for x in _texts(g)))
        if not bad or not wires:
            continue
        bb = g.bbox()
        if not bb:
            continue
        cx, cy = (bb[0] + bb[2]) / 2, (bb[1] + bb[3]) / 2
        best, bd = None, 1e18
        for w in wires:
            for p in w.prims:
                if p.tag != "path":
                    continue
                from model import path_points
                pts = path_points(p.attrs["d"])
                for a, b in zip(pts, pts[1:]):
                    d = _segd((cx, cy), a, b)
                    if d < bd:
                        bd, best = d, w
        if best is None:
            continue
        best.prims.extend(g.prims)
        best.dirty()
        doc.remove(g)
        n += 1
    return n


def _segd(p, a, b):
    import math
    ax, ay = a; bx, by = b; px, py = p
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    t = 0 if L2 == 0 else max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / L2))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def regenerate_auto_symbols(doc: Doc, start_id: int = 100) -> int:
    """AUTO_GENERATED 심볼 블록(컴포넌트/인라인 ref 텍스트 복제)을 다시 만든다. id 충돌 방지."""
    for g in [g for g in doc.groups if g.get("tag") == "AUTO_GENERATED"]:
        doc.remove(g)
    used = {g.gid for g in doc.groups}
    nid = max(start_id, max(used) + 1 if used else start_id)
    cnt = 0
    for g in list(doc.groups):
        if g.type not in ("component", "inline_connector", "reference_connector") or g.get("tag") == "AUTO_GENERATED":
            continue
        ref = g.get("ref", "")
        if g.type == "inline_connector":
            ref = re.sub(r"^(94/\d+)(\.\d+)?(:\d+)?$", r"\1", ref)
        elif g.type == "reference_connector":
            # 예: 1B2_Grounding_IP_Roof:31/403.GND -> 31/403
            lab = next((x for x in _texts(g) if re.search(r"\d+/\d+", x)), "")
            mm = re.search(r"(\d+/\d+)", lab)
            ref = mm.group(1) if mm else strip_decimal(ref)
        else:
            ref = strip_decimal(ref)
        # 복제할 텍스트 : 컴포넌트는 첫 번째(참조) 텍스트, inline 은 라벨
        txt = None
        for p in g.prims:
            if p.tag == "text":
                if g.type == "component" and not re.match(r"^\d+/\d+(\.\w+)?$", p.text):
                    continue
                if g.type == "reference_connector" and not re.search(r"\d+/\d+", p.text):
                    continue
                txt = p
                break
        if not txt:
            continue
        a = Group(gid=nid, cls="symbol")
        a.meta = [("type", "component", True), ("tag", "AUTO_GENERATED", True), ("ref", ref, True),
                  ("description", "AUTO_GENERATED", True), ("harness", "*opt*", True), ("variant", "*opt*", True)]
        a.prims.append(Prim("text", dict(txt.attrs), txt.text))
        doc.add(a)
        nid += 1; cnt += 1
    return cnt


RULE_HELP = {
 "ko": """[규칙 검사 (F5)]
현재 도면이 배선도 템플릿/WDID 규칙을 지키는지 검사하고, 위반 항목을 '규칙 검사' 패널에 오류/경고로 나열합니다. 항목을 더블클릭하면 해당 요소로 이동합니다. 도면은 바꾸지 않습니다.
 - id 중복 / wire 필수 meta 누락 / signal 과 ref 불일치 / 라벨 텍스트와 ref 불일치
 - component ref 는 숫자/숫자(예 4/223), inline connector ref 는 94/번호:핀(예 94/420:1), reference connector ref 는 숫자/숫자(예 31/8)
 - splice/twist/unshielded 가 별도 id 로 구성된 경우(물리적으로 연결된 wire id 하위여야 함)
 - 관련 텍스트가 별도 id 로 흩어진 경우(component/wire/inline 하위로 병합해야 함)

[자동 수정 (F6)]
검사에서 '자동수정 가능'으로 표시된 항목만 고칩니다(실행 취소 가능).
 - 중복 id 번호 재부여, 누락된 wire meta 보충, signal 을 ref 에서 다시 계산
 - ref 의 '.숫자' 접미 제거(예 94/541.1:11 -> 94/541:11, 7/162.2 -> 7/162), 비어 있는 option_description 을 option 사전으로 채움
 - 별도 id 의 splice/twist/unshielded 를 가장 가까운 wire id 하위로 이동
 - 흩어진 text 를 해당 component/wire/inline id 하위로 병합
고칠 수 없는 항목(예: 형식이 전혀 다른 ref)은 속성/코드 패널에서 직접 수정하세요.

[AUTO_GENERATED 심볼 재생성]
배선도 템플릿은 component / inline connector / reference connector 마다 ref 텍스트를 복제한 'AUTO_GENERATED' 심볼 블록(id 100번대)을 둡니다. 이 메뉴는 기존 AUTO_GENERATED 블록을 모두 지우고 현재 도면 기준으로 다시 만듭니다. component 의 ref 를 바꾸었거나 요소를 추가/삭제한 뒤에 실행하세요.""",
 "en": """[Rule check (F5)]
Checks whether the current diagram follows the wiring-diagram template / WDID rules and lists violations as errors/warnings in the 'Rule check' panel. Double-click an entry to jump to the element. It does not modify the diagram.
 - duplicate ids / missing wire meta / signal not matching ref / label text not matching ref
 - component ref = number/number (e.g. 4/223), inline connector ref = 94/number:pin (e.g. 94/420:1), reference connector ref = number/number (e.g. 31/8)
 - splice/twist/unshielded built as a separate id (must be inside the physically connected wire id)
 - related text scattered into separate ids (must be merged into the component/wire/inline id)

[Auto fix (F6)]
Fixes only the items marked 'auto-fixable' (undoable).
 - renumber duplicate ids, fill missing wire meta, recompute signal from ref
 - strip the '.number' suffix of refs (94/541.1:11 -> 94/541:11, 7/162.2 -> 7/162), fill empty option_description from the option dictionary
 - move separate splice/twist/unshielded ids into the nearest wire id
 - merge scattered text into its component/wire/inline id
Items that cannot be fixed automatically (e.g. a completely wrong ref format) must be edited in the attribute/code panel.

[Regenerate AUTO_GENERATED symbols]
The template keeps an 'AUTO_GENERATED' symbol block (ids 100+) that duplicates the ref text of every component / inline connector / reference connector. This command deletes all existing AUTO_GENERATED blocks and rebuilds them from the current diagram. Run it after changing a component ref or adding/removing elements.""",
}
