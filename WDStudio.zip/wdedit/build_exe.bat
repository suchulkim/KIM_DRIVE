@echo off
chcp 65001 >nul
cd /d "%~dp0"
REM 단독 실행 파일(dist\WDStudio.exe) 빌드
python -m pip install PyQt6 pymupdf pyinstaller
python -m PyInstaller --noconsole --onefile --name WDStudio main.py --hidden-import gui --hidden-import model --hidden-import pdfimport --hidden-import rules --hidden-import elements --hidden-import export --hidden-import optionmap --hidden-import version --hidden-import icons --hidden-import i18n
echo.
echo 완료: dist\WDStudio.exe
pause
