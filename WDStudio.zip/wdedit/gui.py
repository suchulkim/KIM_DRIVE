"""WD Studio GUI (PyQt6)."""
from __future__ import annotations
import html as _html
import math
import os
import re
import sys

from PyQt6.QtCore import Qt, QPointF, QRectF, QSize, QTimer, pyqtSignal
from PyQt6.QtGui import (QAction, QActionGroup, QBrush, QColor, QFont, QFontMetricsF, QKeySequence, QPainter, QPainterPath,
                         QPainterPathStroker, QPen, QTextDocument, QTransform, QFontDatabase)
from PyQt6.QtWidgets import (QAbstractItemView, QApplication, QDialog, QDialogButtonBox, QDockWidget, QFileDialog,
                             QFormLayout, QGraphicsEllipseItem, QGraphicsItem, QGraphicsItemGroup, QGraphicsPathItem,
                             QGraphicsRectItem, QGraphicsScene, QGraphicsSimpleTextItem, QGraphicsView, QHBoxLayout,
                             QHeaderView, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMenu, QMessageBox,
                             QPlainTextEdit, QPushButton, QStyle, QStyledItemDelegate, QTableWidget, QTableWidgetItem,
                             QTabWidget, QToolBar, QToolButton, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

import elements as E
import i18n
import rules
from export import export_pdf, export_svg, load_any
from i18n import tr
from icons import icon
from model import Doc, Group, Prim, fmt, parse_group_xml, parse_path, path_points
from version import APP_NAME, BUILD_DATE, DEVELOPER, VERSION

MONO = "Consolas"


# ============================================================================ 그리기 보조
def svg_arc_to_path(path: QPainterPath, x1, y1, rx, ry, phi, fa, fs, x2, y2):
    """SVG 호(endpoint) -> QPainterPath.arcTo (W3C 부록 F.6)."""
    if rx == 0 or ry == 0 or (x1 == x2 and y1 == y2):
        path.lineTo(x2, y2); return
    rx, ry = abs(rx), abs(ry)
    ph = math.radians(phi)
    c, s = math.cos(ph), math.sin(ph)
    dx, dy = (x1 - x2) / 2, (y1 - y2) / 2
    x1p, y1p = c * dx + s * dy, -s * dx + c * dy
    lam = x1p ** 2 / rx ** 2 + y1p ** 2 / ry ** 2
    if lam > 1:
        rx *= math.sqrt(lam); ry *= math.sqrt(lam)
    num = rx ** 2 * ry ** 2 - rx ** 2 * y1p ** 2 - ry ** 2 * x1p ** 2
    den = rx ** 2 * y1p ** 2 + ry ** 2 * x1p ** 2
    co = math.sqrt(max(0, num / den)) if den else 0
    if fa == fs:
        co = -co
    cxp, cyp = co * rx * y1p / ry, -co * ry * x1p / rx
    cx = c * cxp - s * cyp + (x1 + x2) / 2
    cy = s * cxp + c * cyp + (y1 + y2) / 2

    def ang(ux, uy, vx, vy):
        return math.atan2(ux * vy - uy * vx, ux * vx + uy * vy)
    th1 = ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry)
    dth = ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry)
    if not fs and dth > 0:
        dth -= 2 * math.pi
    elif fs and dth < 0:
        dth += 2 * math.pi
    path.arcTo(QRectF(cx - rx, cy - ry, 2 * rx, 2 * ry), -math.degrees(th1), -math.degrees(dth))


def prim_path(p: Prim) -> QPainterPath:
    qp = QPainterPath()
    cx = cy = 0.0
    for cmd, a in parse_path(p.attrs.get("d", "")):
        if cmd == "M":
            qp.moveTo(a[0], a[1]); cx, cy = a[0], a[1]
        elif cmd == "L":
            qp.lineTo(a[0], a[1]); cx, cy = a[0], a[1]
        elif cmd == "H":
            qp.lineTo(a[0], cy); cx = a[0]
        elif cmd == "V":
            qp.lineTo(cx, a[0]); cy = a[0]
        elif cmd == "C":
            qp.cubicTo(a[0], a[1], a[2], a[3], a[4], a[5]); cx, cy = a[4], a[5]
        elif cmd == "A":
            svg_arc_to_path(qp, cx, cy, a[0], a[1], a[2], int(a[3]), int(a[4]), a[5], a[6]); cx, cy = a[5], a[6]
        elif cmd == "Z":
            qp.closeSubpath()
    return qp


def col(s, default="#000000"):
    return QColor(default if s in (None, "none") else s)


def _f(a, k, d=0.0):
    try:
        return float(a.get(k, d))
    except Exception:
        return d


class GroupItem(QGraphicsItemGroup):
    def __init__(self, grp: Group, window):
        super().__init__()
        self.grp = grp
        self.win = window
        self.prim_items = []
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, True)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, True)
        for p in self.grp.prims:
            it = self._prim_item(p)
            self.prim_items.append(it)
            if it is not None:
                self.addToGroup(it)

    def _prim_item(self, p: Prim):
        a = p.attrs
        try:
            pen = QPen(col(a.get("stroke"), "#000000"), _f(a, "stroke-width", 0.75))
            pen.setCapStyle(Qt.PenCapStyle.RoundCap if a.get("stroke-linecap") == "round" else Qt.PenCapStyle.FlatCap)
            pen.setJoinStyle(Qt.PenJoinStyle.MiterJoin if a.get("stroke-linejoin") == "miter" else Qt.PenJoinStyle.RoundJoin)
            brush = QBrush(col(a["fill"])) if a.get("fill") not in (None, "none") else QBrush(Qt.BrushStyle.NoBrush)
            if a.get("stroke") in (None, "none"):
                pen = QPen(Qt.PenStyle.NoPen)
            if p.tag == "path":
                it = QGraphicsPathItem(prim_path(p))
            elif p.tag == "rect":
                it = QGraphicsRectItem(_f(a, "x"), _f(a, "y"), _f(a, "width"), _f(a, "height"))
            elif p.tag == "ellipse":
                cx, cy, rx, ry = (_f(a, k) for k in ("cx", "cy", "rx", "ry"))
                it = QGraphicsEllipseItem(cx - rx, cy - ry, 2 * rx, 2 * ry)
            elif p.tag == "text":
                it = QGraphicsSimpleTextItem(p.text)
                f = QFont(a.get("font-family", "Helvetica"))
                f.setStyleHint(QFont.StyleHint.SansSerif)
                f.setPixelSize(max(1, int(round(_f(a, "font-size", 8)))))
                it.setFont(f)
                it.setBrush(QBrush(col(a.get("fill"))))
                it.setPen(QPen(Qt.PenStyle.NoPen))
                fm = QFontMetricsF(f)
                nat = max(1.0, fm.horizontalAdvance(p.text))
                L = _f(a, "textLength", nat) or nat
                m = re.match(r"rotate\(([-\d.]+),", a.get("transform", ""))
                ang = float(m.group(1)) if m else 0
                tr_ = QTransform().translate(_f(a, "x"), _f(a, "y")).rotate(ang).scale(L / nat, 1)
                tr_.translate(-nat if a.get("text-anchor") == "end" else 0, -fm.ascent())
                it.setTransform(tr_)
                return it
            else:
                return None
            it.setPen(pen)
            it.setBrush(brush)
            return it
        except Exception:
            return None

    def shape(self):
        path = QPainterPath()
        st = QPainterPathStroker()
        st.setWidth(6)
        for ch in self.childItems():
            if isinstance(ch, QGraphicsSimpleTextItem):
                path.addRect(ch.mapToParent(ch.boundingRect()).boundingRect())
            elif isinstance(ch, QGraphicsPathItem):
                path.addPath(st.createStroke(ch.mapToParent(ch.path())))
            elif isinstance(ch, QGraphicsRectItem):
                rp = QPainterPath(); rp.addRect(ch.rect())
                path.addPath(st.createStroke(ch.mapToParent(rp)))
            else:
                path.addRect(ch.mapToParent(ch.boundingRect()).boundingRect())
        return path

    def prim_at(self, scene_pos):
        """scene 좌표 아래의 prim 번호(없으면 -1). 위에 그려진 것(뒤쪽 prim)부터 검사."""
        st = QPainterPathStroker(); st.setWidth(5)
        for k in range(len(self.prim_items) - 1, -1, -1):
            it = self.prim_items[k]
            if it is None:
                continue
            lp = it.mapFromScene(scene_pos)
            if isinstance(it, QGraphicsSimpleTextItem):
                if it.boundingRect().adjusted(-1, -1, 1, 1).contains(lp):
                    return k
            elif isinstance(it, QGraphicsPathItem):
                if st.createStroke(it.path()).contains(lp):
                    return k
            elif isinstance(it, QGraphicsRectItem):
                rp = QPainterPath(); rp.addRect(it.rect())
                if st.createStroke(rp).contains(lp):
                    return k
            elif it.boundingRect().adjusted(-2, -2, 2, 2).contains(lp):
                return k
        return -1

    def mouseMoveEvent(self, ev):
        super().mouseMoveEvent(ev)
        self.win.refresh_overlays()

    def mouseReleaseEvent(self, ev):
        super().mouseReleaseEvent(ev)
        if abs(self.pos().x()) > 1e-6 or abs(self.pos().y()) > 1e-6:
            QTimer.singleShot(0, self.win.move_selected)


class View(QGraphicsView):
    def __init__(self, scene, window):
        super().__init__(scene)
        self.win = window
        self.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.setDragMode(QGraphicsView.DragMode.RubberBandDrag)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setBackgroundBrush(QBrush(QColor("#c9ccd1")))          # 캔버스(작업영역) 바탕 : 용지보다 어두운 회색
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self._pan = None

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        if getattr(self.win, 'auto_fit', False):
            self.win.fit(True)

    def wheelEvent(self, ev):
        self.win.auto_fit = False
        f = 1.15 if ev.angleDelta().y() > 0 else 1 / 1.15
        self.scale(f, f)

    def mousePressEvent(self, ev):
        if ev.button() == Qt.MouseButton.MiddleButton:
            self.win.auto_fit = False
            self._pan = ev.position(); self.setCursor(Qt.CursorShape.ClosedHandCursor); return
        if ev.button() == Qt.MouseButton.LeftButton:
            tool = self.win.tool
            if tool not in ("select", "pan"):
                self.win.tool_press(self.mapToScene(ev.position().toPoint()), ev); return
            if tool == "select" and (ev.modifiers() & Qt.KeyboardModifier.AltModifier):
                self.win.pick_prim(self.mapToScene(ev.position().toPoint())); return
        super().mousePressEvent(ev)

    def mouseMoveEvent(self, ev):
        if self._pan is not None:
            d = ev.position() - self._pan; self._pan = ev.position()
            self.horizontalScrollBar().setValue(int(self.horizontalScrollBar().value() - d.x()))
            self.verticalScrollBar().setValue(int(self.verticalScrollBar().value() - d.y()))
            return
        if self.win.tool not in ("select", "pan"):
            self.win.tool_move(self.mapToScene(ev.position().toPoint()))
        super().mouseMoveEvent(ev)

    def mouseReleaseEvent(self, ev):
        if self._pan is not None:
            self._pan = None; self.win.apply_cursor(); return
        if ev.button() == Qt.MouseButton.LeftButton and self.win.tool not in ("select", "pan"):
            self.win.tool_release(self.mapToScene(ev.position().toPoint())); return
        super().mouseReleaseEvent(ev)
        if self.win.tool == "pan":
            self.setCursor(Qt.CursorShape.OpenHandCursor)

    def mouseDoubleClickEvent(self, ev):
        if self.win.tool == "wire":
            self.win.finish_wire(); return
        if self.win.tool == "select":
            self.win.pick_prim(self.mapToScene(ev.position().toPoint())); return
        super().mouseDoubleClickEvent(ev)

    def keyPressEvent(self, ev):
        if ev.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and self.win.tool == "wire":
            self.win.finish_wire(); return
        if ev.key() == Qt.Key.Key_Escape:
            self.win.cancel_tool(); return
        super().keyPressEvent(ev)


class FormDialog(QDialog):
    def __init__(self, parent, title, fields):
        super().__init__(parent)
        self.setWindowTitle(title)
        lay = QFormLayout(self)
        self.edits = {}
        for name, default in fields:
            e = QLineEdit(default)
            self.edits[name] = e
            lay.addRow(tr(name), e)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        lay.addRow(bb)

    def values(self):
        return {k: e.text().strip() for k, e in self.edits.items()}


# ============================================================================ DevTools 형 코드 트리
_TOK = re.compile(r'<!\[CDATA\[.*?\]\]>|</?[\w-]+|[\w:-]+="[^"]*"|/?>|\s+|[^<>\s]+', re.S)


def code_html(s: str) -> str:
    out = []
    for m in _TOK.finditer(s):
        t = m.group(0); e = _html.escape(t)
        if t.startswith("<![CDATA["):
            out.append('<span style="color:#c41a16">%s</span>' % e)
        elif t.startswith("<") and re.match(r"</?[\w-]+$", t):
            out.append('<span style="color:#881280">%s</span>' % e)
        elif t in ("/>", ">"):
            out.append('<span style="color:#881280">%s</span>' % e)
        elif re.match(r'[\w:-]+="', t):
            k, v = t.split("=", 1)
            out.append('<span style="color:#994500">%s</span>=<span style="color:#1a1aa6">%s</span>' % (_html.escape(k), _html.escape(v)))
        else:
            out.append(e.replace(" ", "&nbsp;"))
    return "".join(out)


class CodeDelegate(QStyledItemDelegate):
    def _doc(self, index, w=None):
        d = QTextDocument()
        d.setDefaultFont(index.model().data(index, Qt.ItemDataRole.FontRole) or QFont(MONO, 9))
        d.setDocumentMargin(1)
        d.setHtml('<span style="white-space:pre">%s</span>' % index.data(Qt.ItemDataRole.UserRole + 1))
        return d

    def paint(self, painter, option, index):
        painter.save()
        sel = bool(option.state & QStyle.StateFlag.State_Selected)
        if sel:
            painter.fillRect(option.rect, QColor("#1a73e8"))
        d = self._doc(index)
        if sel:
            d.setHtml('<span style="white-space:pre;color:white">%s</span>' % _html.escape(index.data(Qt.ItemDataRole.DisplayRole)).replace(" ", "&nbsp;"))
        painter.translate(option.rect.left(), option.rect.top())
        d.drawContents(painter)
        painter.restore()

    def sizeHint(self, option, index):
        fm = QFontMetricsF(QFont(MONO, 9))
        return QSize(int(fm.horizontalAdvance(index.data(Qt.ItemDataRole.DisplayRole) or "")) + 8, 19)


class CodeTree(QTreeWidget):
    dropped = pyqtSignal(list, object)           # [token...], target token

    def __init__(self):
        super().__init__()
        self.setHeaderHidden(True)
        self.setUniformRowHeights(True)
        self.setItemDelegate(CodeDelegate(self))
        self.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.setDragEnabled(True); self.setAcceptDrops(True); self.setDropIndicatorShown(True)
        self.setDragDropMode(QAbstractItemView.DragDropMode.DragDrop)
        self.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.setIndentation(14)
        self.header().setStretchLastSection(False)
        self.header().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        f = QFont(MONO, 9); f.setStyleHint(QFont.StyleHint.Monospace); self.setFont(f)

    def dropEvent(self, ev):
        tgt = self.itemAt(ev.position().toPoint())
        toks = [i.data(0, Qt.ItemDataRole.UserRole) for i in self.selectedItems()]
        ev.ignore()                                  # 트리 자체는 Qt 가 바꾸지 않고, 모델(Doc)을 고친 뒤 다시 그린다
        if tgt is not None and toks:
            self.dropped.emit(toks, tgt.data(0, Qt.ItemDataRole.UserRole))


def _grp_open(g: Group) -> str:
    return '<g id="id-%d" class="%s">' % (g.gid, g.cls)


# ============================================================================ 메인 윈도우
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.resize(1600, 980)
        self.doc = self.blank_doc(*self.default_canvas())
        self.scene = QGraphicsScene()
        self.view = View(self.scene, self)
        self.setCentralWidget(self.view)
        self.items = []
        self.by_gid = {}
        self.overlays = []
        self.page_rect = QRectF(0, 0, 1200, 800)
        self.tool = "select"
        self.sel_prims = []
        self._pts = []; self._rubber = None; self._drag0 = None
        self.undo_stack, self.redo_stack = [], []
        self.modified = False
        self._busy = False; self._loading = False
        self.clip = None
        self.auto_fit = True
        self.extra_gids = set()
        self._tr = []
        self._make_actions()
        self._make_docks()
        self.retranslate()
        self.statusBar().showMessage(tr("PDF 또는 SVG 파일을 여세요 (Ctrl+O)"))
        self.rebuild()
        QTimer.singleShot(0, self.fit)

    # ------------------------------------------------------------------ 번역 등록
    def reg(self, fn):
        self._tr.append(fn); fn()

    def retranslate(self):
        for fn in self._tr:
            fn()
        self.setWindowTitle("%s v%s%s" % (APP_NAME, VERSION, (" - " + os.path.basename(self.doc.path)) if getattr(self.doc, "path", None) else ""))
        self.ver_label.setText("%s v%s  |  %s: %s" % (APP_NAME, VERSION, tr("개발자"), DEVELOPER))

    # ------------------------------------------------------------------ 액션/메뉴/툴바
    def _act(self, name, key, fn, shortcut=None, tip=None, ico=None, checkable=False):
        a = QAction(self, checkable=checkable)
        if ico:
            a.setIcon(icon(ico))
        if shortcut:
            a.setShortcut(shortcut)

        def upd(a=a, key=key, tip=tip):
            a.setText(tr(key))
            if tip:
                a.setToolTip(tr(tip)); a.setStatusTip(tr(tip))
        self.reg(upd)
        a.triggered.connect(lambda _=False: fn())
        setattr(self, name, a)
        return a

    def _menu(self, key):
        m = self.menuBar().addMenu("")
        m.setToolTipsVisible(True)
        self.reg(lambda: m.setTitle(tr(key)))
        return m

    def _make_actions(self):
        S = QKeySequence
        self.ver_label = QLabel("")
        self.statusBar().addPermanentWidget(self.ver_label)
        # --- 파일
        a_new = self._act("a_new", "새로 만들기…", self.new_doc, S.StandardKey.New, ico="open")
        a_defsize = self._act("a_defsize", "기본 캔버스 크기…", self.set_default_canvas, None,
                              tip="새 도면의 기본 캔버스 크기를 설정합니다 (SVG 단위)")
        a_open = self._act("a_open", "열기 (PDF/SVG)…", self.open_file, S.StandardKey.Open, ico="open")
        a_save = self._act("a_save", "SVG 저장", self.save_svg, S.StandardKey.Save, ico="save")
        a_saveas = self._act("a_saveas", "다른 이름으로 SVG 저장…", self.save_svg_as, S("Ctrl+Shift+S"), ico="save")
        a_pdf = self._act("a_pdf", "PDF 내보내기…", self.export_pdf_dlg, S("Ctrl+E"), ico="pdf")
        a_exit = self._act("a_exit", "종료", self.close, S.StandardKey.Quit)
        # --- 편집
        a_undo = self._act("a_undo", "실행 취소", self.undo, S.StandardKey.Undo, ico="undo")
        a_redo = self._act("a_redo", "다시 실행", self.redo, S.StandardKey.Redo, ico="redo")
        a_cut = self._act("a_cut", "잘라내기", self.cut, S.StandardKey.Cut, ico="cut")
        a_copy = self._act("a_copy", "복사", self.copy, S.StandardKey.Copy, ico="copy")
        a_paste = self._act("a_paste", "붙여넣기", self.paste, S.StandardKey.Paste, ico="paste")
        a_del = self._act("a_del", "삭제", self.delete_selected, S.StandardKey.Delete, ico="delete")
        a_all = self._act("a_all", "전체 선택", lambda: [i.setSelected(True) for i in self.items], S.StandardKey.SelectAll)
        # --- 보기
        a_fit = self._act("a_fit", "전체 보기", self.fit, S("Ctrl+0"), ico="fit")
        a_zi = self._act("a_zi", "확대", lambda: self._zoom(1.25), S.StandardKey.ZoomIn)
        a_zo = self._act("a_zo", "축소", lambda: self._zoom(0.8), S.StandardKey.ZoomOut)
        # --- 규칙
        a_chk = self._act("a_chk", "규칙 검사", self.run_check, S("F5"), ico="check",
                          tip="현재 도면이 템플릿/WDID 규칙을 지키는지 검사하여 오류·경고 목록을 보여줍니다 (도면은 변경하지 않음)")
        a_fix = self._act("a_fix", "자동 수정", self.run_fix, S("F6"), ico="fix",
                          tip="'자동수정 가능' 항목을 고칩니다: ref 접미 제거, 누락 meta 보충, 별도 id 의 splice/twist 와 흩어진 text 병합 등")
        a_auto = self._act("a_auto", "AUTO_GENERATED 심볼 재생성", self.run_auto, None, ico="auto",
                           tip="component/inline/reference 의 ref 텍스트를 복제한 AUTO_GENERATED 블록(id 100번대)을 삭제 후 다시 생성합니다")
        a_help = self._act("a_help", "규칙 설명…", self.show_rule_help, S("F1"), ico="help")
        a_about = self._act("a_about", "WD Studio 정보…", self.show_about, None, ico="info")

        mb = self.menuBar()
        m = self._menu("파일"); [m.addAction(x) for x in (a_new, a_open, a_save, a_saveas, a_pdf)]; m.addSeparator(); m.addAction(a_exit)
        m = self._menu("편집"); [m.addAction(x) for x in (a_undo, a_redo)]; m.addSeparator(); [m.addAction(x) for x in (a_cut, a_copy, a_paste, a_del)]; m.addSeparator(); m.addAction(a_all)
        m = self._menu("보기"); [m.addAction(x) for x in (a_fit, a_zi, a_zo)]
        self.draw_menu = self._menu("그리기")
        m = self._menu("규칙"); [m.addAction(x) for x in (a_chk, a_fix, a_auto)]
        m = self._menu("설정")
        m.addAction(a_defsize)
        lm = m.addMenu(""); self.reg(lambda: lm.setTitle(tr("언어 / Language"))); lm.setIcon(icon("lang"))
        g = QActionGroup(self)
        for code, key in (("ko", "한국어"), ("en", "English")):
            a = QAction(key, self, checkable=True); a.setChecked(i18n.LANG == code); g.addAction(a); lm.addAction(a)
            a.triggered.connect(lambda _=False, c=code: self.set_language(c))
        m = self._menu("도움말"); m.addAction(a_help); m.addAction(a_about)

        # --- 툴바 (아이콘 + 텍스트)
        def mk_tb(key):
            tb = QToolBar(self); tb.setMovable(False); tb.setIconSize(QSize(22, 22))
            tb.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
            self.reg(lambda: tb.setWindowTitle(tr(key)))
            return tb
        tb = mk_tb("파일 도구"); self.addToolBar(tb); [tb.addAction(x) for x in (a_new, a_open, a_save, a_pdf)]
        tb.addSeparator(); [tb.addAction(x) for x in (a_undo, a_redo)]
        tb.addSeparator(); [tb.addAction(x) for x in (a_cut, a_copy, a_paste, a_del)]
        tb.addSeparator(); [tb.addAction(x) for x in (a_chk, a_fix, a_fit)]
        self.addToolBarBreak()
        tb2 = mk_tb("그리기 도구"); self.addToolBar(tb2)
        grp = QActionGroup(self); self.tool_actions = {}

        def tool_act(key, label, tip, ico):
            a = QAction(self, checkable=True); a.setIcon(icon(ico))
            self.reg(lambda a=a: (a.setText(tr(label)), a.setToolTip(tr(tip)), a.setStatusTip(tr(tip))))
            a.triggered.connect(lambda _=False, k=key: self.set_tool(k))
            grp.addAction(a); self.tool_actions[key] = a
            return a
        # 선택/이동 드롭다운 (예시 화면과 동일)
        sel = tool_act("select", "선택", "선택: 클릭/드래그로 요소 선택, 선택 후 드래그하면 요소 이동", "select")
        pan = tool_act("pan", "이동", "이동(Pan): 마우스 드래그로 화면을 이동 (마우스 가운데 버튼 드래그도 가능)", "pan")
        nav_menu = QMenu(self); nav_menu.addAction(sel); nav_menu.addAction(pan)
        self.nav_btn = QToolButton(); self.nav_btn.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)
        self.nav_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon); self.nav_btn.setIconSize(QSize(22, 22))
        self.nav_btn.setMenu(nav_menu); self.nav_btn.setDefaultAction(sel)
        tb2.addWidget(self.nav_btn); tb2.addSeparator()
        sel.triggered.connect(lambda: self.nav_btn.setDefaultAction(sel)); pan.triggered.connect(lambda: self.nav_btn.setDefaultAction(pan))
        self.tool_actions["select"].setChecked(True)
        for key, label, tip, ico in [("wire", "Wire", "클릭으로 꺾임점 추가, 더블클릭/Enter 로 완료", "wire"),
                                      ("component", "Component", "드래그하여 사각형 생성", "component"),
                                      ("inline", "Inline", "wire 위를 클릭 (Shift: 세로)", "inline"),
                                      ("reference", "Reference", "클릭하여 reference connector 추가", "reference"),
                                      ("sp", "Splice(SP)", "wire 끝점 근처 클릭", "sp"),
                                      ("twist", "Twist", "wire 사이를 클릭 (왼쪽-위 모서리)", "twist"),
                                      ("unshielded", "Unshielded", "wire 사이를 클릭", "unshielded"),
                                      ("text", "Text", "클릭하여 일반 텍스트 추가", "text")]:
            a = tool_act(key, label, tip, ico); tb2.addAction(a); self.draw_menu.addAction(a)
        self.draw_menu.insertAction(self.draw_menu.actions()[0], sel); self.draw_menu.insertAction(self.draw_menu.actions()[1], pan)
        self.draw_menu.insertSeparator(self.draw_menu.actions()[2])

    def _make_docks(self):
        # ---- 요소 목록 / SVG 코드 (DevTools 형)
        self.tree = CodeTree()
        self.tree.itemExpanded.connect(self.tree_expand)
        self.tree.itemSelectionChanged.connect(self.on_tree_selection)
        self.tree.dropped.connect(self.on_tree_drop)
        self.tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self.tree_menu)
        d = QDockWidget(self); d.setWidget(self.tree); d.setObjectName("dock_tree")
        self.reg(lambda: d.setWindowTitle(tr("요소 목록 / SVG 코드")))
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, d)
        self.resizeDocks([d], [520], Qt.Orientation.Horizontal)
        # ---- 속성
        w = QWidget(); l = QVBoxLayout(w)
        self.sel_label = QLabel(""); l.addWidget(self.sel_label)
        self.props = QTabWidget()
        mw = QWidget(); ml = QVBoxLayout(mw); ml.setContentsMargins(2, 2, 2, 2)
        self.meta_tbl = QTableWidget(0, 2); self.meta_tbl.horizontalHeader().setStretchLastSection(True)
        self.meta_tbl.cellChanged.connect(self.meta_changed)
        hb = QHBoxLayout(); self.b_madd = QPushButton(); self.b_mdel = QPushButton()
        self.b_madd.clicked.connect(self.add_meta_row); self.b_mdel.clicked.connect(self.del_meta_row)
        hb.addWidget(self.b_madd); hb.addWidget(self.b_mdel)
        ml.addLayout(hb); ml.addWidget(self.meta_tbl)
        vw = QWidget(); vl = QVBoxLayout(vw); vl.setContentsMargins(2, 2, 2, 2)
        self.prim_list = QListWidget(); self.prim_list.setMaximumHeight(150)
        self.prim_list.currentRowChanged.connect(self.prim_list_changed)
        self.attr_tbl = QTableWidget(0, 2); self.attr_tbl.horizontalHeader().setStretchLastSection(True)
        self.attr_tbl.cellChanged.connect(self.attr_changed)
        hb2 = QHBoxLayout(); self.b_aadd = QPushButton(); self.b_adel = QPushButton()
        self.b_aadd.clicked.connect(self.add_attr_row); self.b_adel.clicked.connect(self.del_attr_row)
        hb2.addWidget(self.b_aadd); hb2.addWidget(self.b_adel)
        vl.addWidget(self.prim_list); vl.addLayout(hb2); vl.addWidget(self.attr_tbl)
        self.props.addTab(vw, ""); self.props.addTab(mw, "")
        l.addWidget(self.props)
        d2 = QDockWidget(self); d2.setWidget(w); d2.setObjectName("dock_props")
        self.reg(lambda: (d2.setWindowTitle(tr("속성")), self.props.setTabText(0, tr("visible data")), self.props.setTabText(1, tr("metadata")),
                          self.meta_tbl.setHorizontalHeaderLabels([tr("meta"), tr("값")]), self.attr_tbl.setHorizontalHeaderLabels([tr("속성명"), tr("값")]),
                          self.b_madd.setText(tr("meta 추가")), self.b_mdel.setText(tr("meta 삭제")),
                          self.b_aadd.setText(tr("속성 추가")), self.b_adel.setText(tr("속성 삭제"))))
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, d2)
        # ---- 규칙 검사
        w2 = QWidget(); l2 = QVBoxLayout(w2)
        h = QHBoxLayout()
        for attr, key, fn in (("b_chk", "검사", self.run_check), ("b_fix", "자동수정", self.run_fix), ("b_auto", "AUTO_GENERATED", self.run_auto), ("b_help", "규칙 설명", self.show_rule_help)):
            b = QPushButton(); b.clicked.connect(lambda _=False, f=fn: f()); h.addWidget(b); setattr(self, attr, b)
            self.reg(lambda b=b, key=key: b.setText(tr(key)))
        self.b_chk.setToolTip(""); l2.addLayout(h)
        self.issue_list = QListWidget(); self.issue_list.itemDoubleClicked.connect(self.goto_issue)
        l2.addWidget(self.issue_list)
        self.summary = QLabel(""); l2.addWidget(self.summary)
        d3 = QDockWidget(self); d3.setWidget(w2); d3.setObjectName("dock_rules")
        self.reg(lambda: d3.setWindowTitle(tr("규칙 검사 패널")))
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, d3)
        # ---- 코드 편집
        w3 = QWidget(); l3 = QVBoxLayout(w3)
        self.code_hint = QLabel(""); l3.addWidget(self.code_hint)
        self.code = QPlainTextEdit(); f = QFont(MONO, 9); f.setStyleHint(QFont.StyleHint.Monospace); self.code.setFont(f)
        self.code.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap); l3.addWidget(self.code)
        hb3 = QHBoxLayout(); self.b_apply = QPushButton(); self.b_revert = QPushButton()
        self.b_apply.clicked.connect(self.apply_code); self.b_revert.clicked.connect(self.show_code)
        hb3.addWidget(self.b_apply); hb3.addWidget(self.b_revert); l3.addLayout(hb3)
        d4 = QDockWidget(self); d4.setWidget(w3); d4.setObjectName("dock_code")
        self.reg(lambda: (d4.setWindowTitle(tr("코드 편집")), self.b_apply.setText(tr("적용")), self.b_revert.setText(tr("되돌리기")),
                          self.code_hint.setText(tr("선택한 그룹(id)의 SVG 코드를 직접 수정하고 [적용]을 누르세요"))))
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, d4)
        self.resizeDocks([d4], [220], Qt.Orientation.Vertical)
        self.scene.selectionChanged.connect(self.on_scene_selection)

    # ------------------------------------------------------------------ 언어 / 도움말
    def set_language(self, code):
        i18n.set_lang(code)
        self.retranslate()
        self.refresh_all()
        self.run_check() if self.issue_list.count() else None

    def show_about(self):
        dlg = QDialog(self); dlg.setWindowTitle(tr("정보"))
        l = QVBoxLayout(dlg)
        lab = QLabel("<h2>%s</h2><p>%s</p><table><tr><td><b>%s</b></td><td>&nbsp;%s</td></tr><tr><td><b>%s</b></td><td>&nbsp;%s</td></tr>"
                     "<tr><td><b>%s</b></td><td>&nbsp;%s</td></tr></table>" % (
                         APP_NAME, tr("PDF 배선도를 배선도 템플릿/WDID 규칙에 맞는 SVG 로 변환하고 편집하는 도구"),
                         tr("버전"), "v" + VERSION, tr("빌드 날짜"), BUILD_DATE, tr("개발자"), DEVELOPER))
        lab.setTextFormat(Qt.TextFormat.RichText); l.addWidget(lab)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Close); bb.rejected.connect(dlg.reject); bb.accepted.connect(dlg.accept)
        bb.button(QDialogButtonBox.StandardButton.Close).clicked.connect(dlg.accept); l.addWidget(bb)
        dlg.exec()

    def show_rule_help(self):
        dlg = QDialog(self); dlg.setWindowTitle(tr("규칙 설명")); dlg.resize(780, 620)
        l = QVBoxLayout(dlg); t = QPlainTextEdit(); t.setReadOnly(True); t.setPlainText(rules.RULE_HELP["en" if i18n.LANG == "en" else "ko"])
        l.addWidget(t); bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Close); bb.button(QDialogButtonBox.StandardButton.Close).clicked.connect(dlg.accept); l.addWidget(bb)
        dlg.exec()

    # ------------------------------------------------------------------ 장면
    def rebuild(self):
        self._busy = True
        sel = {i.grp.gid for i in self.items if i.isSelected()}
        self.scene.clear(); self.overlays = []
        self.items = []; self.by_gid = {}
        vb = self.doc.viewbox
        page = QRectF(vb[0], vb[1], vb[2], vb[3]); self.page_rect = page
        m = max(page.width(), page.height()) * 1.0                       # 용지 주변 작업 여백
        self.scene.setSceneRect(page.adjusted(-m, -m, m, m))
        sh = self.scene.addRect(page.translated(7, 7), QPen(Qt.PenStyle.NoPen), QBrush(QColor(0, 0, 0, 60))); sh.setZValue(-102)
        pen = QPen(QColor("#1a73e8"), 3); pen.setCosmetic(True)
        pg = self.scene.addRect(page, pen, QBrush(Qt.GlobalColor.white)); pg.setZValue(-101)   # 용지(캔버스) 경계
        lab = self.scene.addSimpleText("%s  %.0f × %.0f" % (tr("캔버스"), page.width(), page.height()))
        lab.setBrush(QBrush(QColor("#1a73e8"))); lab.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations, True)
        lab.setPos(page.left(), page.top()); lab.setTransform(QTransform().translate(0, -20)); lab.setZValue(-100)
        for g in self.doc.groups:
            if g.cls in ("rectangle", "xygrid"):
                continue
            it = GroupItem(g, self)
            it.setZValue(-1 if g.kind == "component" else 0)
            self.scene.addItem(it); self.items.append(it); self.by_gid[g.gid] = it
            if g.gid in sel:
                it.setSelected(True)
        self.apply_item_flags()
        self.populate_tree()
        self._busy = False
        self.refresh_all()

    def rebuild_group(self, gid):
        old = self.by_gid.get(gid)
        g = next((x for x in self.doc.groups if x.gid == gid), None)
        if g is None:
            return self.rebuild()
        if old is None:                       # 화면에 그려지지 않는 그룹(rectangle/xygrid)
            self.refresh_tree_group(g); return
        self._busy = True
        was = old.isSelected(); z = old.zValue(); idx = self.items.index(old)
        self.scene.removeItem(old)
        it = GroupItem(g, self); it.setZValue(z); self.scene.addItem(it)
        self.items[idx] = it; self.by_gid[gid] = it
        it.setSelected(was); self.apply_item_flags()
        self.refresh_tree_group(g)
        self._busy = False
        self.refresh_overlays()

    def _zoom(self, f):
        self.auto_fit = False; self.view.scale(f, f)

    def apply_item_flags(self):
        sel = self.tool == "select"
        for i in self.items:
            i.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, sel)
            i.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, sel)
            i.setAcceptedMouseButtons(Qt.MouseButton.LeftButton if sel else Qt.MouseButton.NoButton)

    def fit(self, auto=False):
        self.auto_fit = True
        p = self.page_rect; pad = max(p.width(), p.height()) * 0.3
        self.view.resetTransform()
        self.view.fitInView(p.adjusted(-pad, -pad, pad, pad), Qt.AspectRatioMode.KeepAspectRatio)

    # ------------------------------------------------------------------ 선택 강조
    def refresh_overlays(self):
        for o in self.overlays:
            if o.scene() is not None:
                self.scene.removeItem(o)
        self.overlays = []
        for it in self.items:
            if it.isSelected():
                self._overlay(it.sceneBoundingRect(), "g#id-%d.%s" % (it.grp.gid, it.grp.cls), QColor(26, 115, 232, 70), QColor(26, 115, 232))
        for gid, k in self.sel_prims:
            it = self.by_gid.get(gid)
            if it and k < len(it.prim_items) and it.prim_items[k] is not None:
                p = it.grp.prims[k]
                self._overlay(it.prim_items[k].sceneBoundingRect(), "%s #%d" % (p.tag, k), QColor(255, 152, 0, 110), QColor(230, 110, 0))

    def _overlay(self, r: QRectF, label, fill, line):
        r = r.adjusted(-1.5, -1.5, 1.5, 1.5)
        pen = QPen(line, 2); pen.setCosmetic(True)
        box = self.scene.addRect(r, pen, QBrush(fill)); box.setZValue(2000); box.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
        chip = QGraphicsRectItem(0, 0, 10, 10); chip.setZValue(2001)
        txt = QGraphicsSimpleTextItem("%s   %.2f × %.2f" % (label, r.width() - 3, r.height() - 3), chip)
        f = QFont("Arial", 9); f.setBold(True); txt.setFont(f); txt.setBrush(QBrush(line.darker(130))); txt.setPos(4, 1)
        br = txt.boundingRect(); chip.setRect(0, 0, br.width() + 8, br.height() + 2)
        chip.setBrush(QBrush(QColor(255, 255, 255, 240))); cp = QPen(line, 1); cp.setCosmetic(True); chip.setPen(cp)
        chip.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations, True)
        chip.setPos(r.left(), r.top()); chip.setTransform(QTransform().translate(0, -chip.rect().height() - 3))
        chip.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
        self.scene.addItem(chip)
        self.overlays += [box, chip]

    # ------------------------------------------------------------------ 트리 (SVG 코드)
    def populate_tree(self):
        self.tree.blockSignals(True)
        self.tree.clear()
        for g in self.doc.groups:
            self.tree.addTopLevelItem(self._group_node(g))
        self.tree.blockSignals(False)

    def _node(self, plain, token):
        it = QTreeWidgetItem([plain]); it.setData(0, Qt.ItemDataRole.UserRole, token)
        it.setData(0, Qt.ItemDataRole.UserRole + 1, code_html(plain))
        it.setFlags(it.flags() | Qt.ItemFlag.ItemIsDragEnabled | Qt.ItemFlag.ItemIsDropEnabled)
        return it

    def _group_node(self, g: Group):
        label = g.get("ref", "") or ""
        it = self._node(_grp_open(g), ("g", g.gid))
        if g.meta or g.prims:
            it.addChild(QTreeWidgetItem(["…"]))
        return it

    def _fill_group(self, it: QTreeWidgetItem):
        gid = it.data(0, Qt.ItemDataRole.UserRole)[1]
        g = next((x for x in self.doc.groups if x.gid == gid), None)
        it.takeChildren()
        if g is None:
            return
        if g.meta:
            mn = self._node("<metadata>", ("metadata", gid))
            for k, (n, v, c) in enumerate(g.meta):
                mn.addChild(self._node('<meta name="%s">%s</meta>' % (n, ("<![CDATA[%s]]>" % v) if c else v), ("meta", gid, k)))
            it.addChild(mn)
        for k, p in enumerate(g.prims):
            it.addChild(self._node(p.to_xml(), ("prim", gid, k)))

    def tree_expand(self, item):
        if item.childCount() == 1 and item.child(0).data(0, Qt.ItemDataRole.UserRole) is None and item.data(0, Qt.ItemDataRole.UserRole):
            tok = item.data(0, Qt.ItemDataRole.UserRole)
            if tok[0] == "g":
                self.tree.blockSignals(True); self._fill_group(item); self.tree.blockSignals(False)

    def refresh_tree_group(self, g: Group):
        it = self._tree_group_item(g.gid)
        if it is None:
            return
        was = it.isExpanded()
        self.tree.blockSignals(True)
        it.setText(0, _grp_open(g)); it.setData(0, Qt.ItemDataRole.UserRole + 1, code_html(_grp_open(g)))
        it.takeChildren()
        if g.meta or g.prims:
            it.addChild(QTreeWidgetItem(["…"]))
        if was:
            self._fill_group(it)
        self.tree.blockSignals(False)

    def _tree_group_item(self, gid):
        for r in range(self.tree.topLevelItemCount()):
            it = self.tree.topLevelItem(r)
            if it.data(0, Qt.ItemDataRole.UserRole)[1] == gid:
                return it
        return None

    def _tree_prim_item(self, gid, k):
        it = self._tree_group_item(gid)
        if it is None:
            return None
        if not it.isExpanded():
            self.tree.blockSignals(True); it.setExpanded(True); self._fill_group(it); self.tree.blockSignals(False)
        for r in range(it.childCount()):
            c = it.child(r)
            if c.data(0, Qt.ItemDataRole.UserRole) == ("prim", gid, k):
                return c
        return None

    def sync_tree_selection(self):
        self.tree.blockSignals(True)
        self.tree.clearSelection()
        first = None
        if self.sel_prims:
            for gid, k in self.sel_prims:
                c = self._tree_prim_item(gid, k)
                if c is not None:
                    c.setSelected(True); first = first or c
        else:
            for gid in [i.grp.gid for i in self.items if i.isSelected()] + sorted(self.extra_gids):
                n = self._tree_group_item(gid)
                if n is not None:
                    n.setSelected(True); first = first or n
        if first is not None:
            self.tree.scrollToItem(first)
        self.tree.blockSignals(False)

    def tree_menu(self, pos):
        m = QMenu(self)
        for a in (self.a_cut, self.a_copy, self.a_paste, self.a_del):
            m.addAction(a)
        m.exec(self.tree.viewport().mapToGlobal(pos))

    def on_tree_selection(self):
        if self._busy:
            return
        toks = [i.data(0, Qt.ItemDataRole.UserRole) for i in self.tree.selectedItems() if i.data(0, Qt.ItemDataRole.UserRole)]
        gids = {t[1] for t in toks}
        self.sel_prims = [(t[1], t[2]) for t in toks if t[0] == "prim"]
        self.extra_gids = {g for g in gids if g not in self.by_gid}
        self._busy = True
        for it in self.items:
            it.setSelected(it.grp.gid in gids)
        self._busy = False
        self.refresh_all(sync_tree=False)
        its = [i for i in self.items if i.isSelected()]
        if its:
            self.view.ensureVisible(its[0])

    def on_tree_drop(self, toks, target):
        """요소/속성 줄을 다른 id(그룹) 위로 드래그 -> 그 id 하위로 이동."""
        if not target or target[0] == "meta":
            return
        tgt = next((g for g in self.doc.groups if g.gid == target[1]), None)
        if tgt is None:
            return
        prim_t = [t for t in toks if t[0] == "prim" and t[1] != tgt.gid]
        grp_t = [t for t in toks if t[0] == "g" and t[1] != tgt.gid]
        if not prim_t and not grp_t:
            return
        if grp_t and QMessageBox.question(self, tr("병합"), tr("요소(그룹)를 다른 id 로 병합하시겠습니까? 원래 id 는 삭제됩니다.")) != QMessageBox.StandardButton.Yes:
            return
        self.push_undo()
        by = {g.gid: g for g in self.doc.groups}
        moved = []
        for gid in sorted({t[1] for t in prim_t}):
            src = by[gid]
            idxs = sorted({t[2] for t in prim_t if t[1] == gid})
            moved += [src.prims[k] for k in idxs]
            for k in reversed(idxs):
                del src.prims[k]
            src.dirty()
        for t in grp_t:
            src = by.get(t[1])
            if src:
                moved += src.prims; self.doc.remove(src)
        tgt.prims.extend(moved); tgt.dirty()
        self.sel_prims = [(tgt.gid, len(tgt.prims) - len(moved) + i) for i in range(len(moved))]
        self.rebuild()
        for i in self.items:
            i.setSelected(i.grp.gid == tgt.gid)
        self.refresh_all()
        self.statusBar().showMessage("%s: %d → id-%d" % (tr("이동 완료"), len(moved), tgt.gid))

    # ------------------------------------------------------------------ 선택 → 패널
    def selected_groups(self):
        gs = [i.grp for i in self.items if i.isSelected()]
        have = {g.gid for g in gs}
        gs += [g for g in self.doc.groups if g.gid in self.extra_gids and g.gid not in have and g.gid not in self.by_gid]
        return gs

    def on_scene_selection(self):
        if self._busy:
            return
        self.sel_prims = []; self.extra_gids = set()
        try:
            self.refresh_all()
        except RuntimeError:
            pass

    def refresh_all(self, sync_tree=True):
        if self._busy:
            return
        self.refresh_overlays()
        if sync_tree:
            self.sync_tree_selection()
        self.refresh_props()
        self.show_code()

    def pick_prim(self, scene_pos):
        for it in sorted(self.items, key=lambda i: -i.zValue()):
            if it.sceneBoundingRect().contains(scene_pos):
                k = it.prim_at(scene_pos)
                if k >= 0:
                    self.select_prim(it.grp.gid, k); return

    def select_prim(self, gid, k):
        self._busy = True
        for i in self.items:
            i.setSelected(i.grp.gid == gid)
        self._busy = False
        self.sel_prims = [(gid, k)]
        self.extra_gids = {gid} if gid not in self.by_gid else set()
        self.refresh_all()

    def refresh_props(self):
        self._loading = True
        gs = self.selected_groups()
        self.meta_tbl.setRowCount(0); self.attr_tbl.setRowCount(0); self.prim_list.clear()
        if len(gs) == 1:
            g = gs[0]
            self.sel_label.setText("id-%d   (%s / %s)" % (g.gid, g.cls, g.kind))
            for n, v, c in g.meta:
                r = self.meta_tbl.rowCount(); self.meta_tbl.insertRow(r)
                self.meta_tbl.setItem(r, 0, QTableWidgetItem(n)); self.meta_tbl.setItem(r, 1, QTableWidgetItem(v))
            for k, p in enumerate(g.prims):
                brief = ("'%s'" % p.text) if p.tag == "text" else (p.attrs.get("d", "")[:40] if p.tag == "path" else "")
                self.prim_list.addItem("#%d  %s  %s" % (k, p.tag, brief))
            cur = next((k for gid, k in self.sel_prims if gid == g.gid), -1)
            if len(self.sel_prims) == 1 and cur >= 0:
                self.prim_list.setCurrentRow(cur)
                self.fill_attr_table(g.prims[cur])
        else:
            self.sel_label.setText(tr("선택 %d개") % len(gs) if gs else tr("선택 없음"))
        self._loading = False

    def fill_attr_table(self, p: Prim):
        self.attr_tbl.setRowCount(0)
        for k, v in p.attrs.items():
            r = self.attr_tbl.rowCount(); self.attr_tbl.insertRow(r)
            self.attr_tbl.setItem(r, 0, QTableWidgetItem(k)); self.attr_tbl.setItem(r, 1, QTableWidgetItem(str(v)))
        if p.tag == "text":
            r = self.attr_tbl.rowCount(); self.attr_tbl.insertRow(r)
            it = QTableWidgetItem("CDATA"); it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.attr_tbl.setItem(r, 0, it); self.attr_tbl.setItem(r, 1, QTableWidgetItem(p.text))

    def prim_list_changed(self, row):
        if self._loading or row < 0:
            return
        gs = self.selected_groups()
        if len(gs) == 1:
            self.select_prim(gs[0].gid, row)

    # ------------------------------------------------------------------ 속성 편집 (표 <-> 캔버스 양방향)
    def _cur_prim(self):
        gs = self.selected_groups()
        if len(gs) == 1 and len(self.sel_prims) == 1 and self.sel_prims[0][0] == gs[0].gid:
            k = self.sel_prims[0][1]
            if k < len(gs[0].prims):
                return gs[0], k, gs[0].prims[k]
        return None

    def attr_changed(self, r, c):
        if self._loading:
            return
        cur = self._cur_prim()
        if not cur:
            return
        g, k, p = cur
        self.push_undo()
        attrs = {}
        for i in range(self.attr_tbl.rowCount()):
            n = self.attr_tbl.item(i, 0).text().strip() if self.attr_tbl.item(i, 0) else ""
            v = self.attr_tbl.item(i, 1).text() if self.attr_tbl.item(i, 1) else ""
            if n == "CDATA":
                p.text = v
            elif n:
                attrs[n] = v
        p.attrs = attrs
        g.dirty()
        self.rebuild_group(g.gid)
        QTimer.singleShot(0, self.refresh_props)       # 수정한 값이 바로 캔버스와 목록/코드에 반영
        QTimer.singleShot(0, self.show_code)

    def add_attr_row(self):
        cur = self._cur_prim()
        if not cur:
            return
        dlg = FormDialog(self, tr("속성 추가"), [("이름", "")])
        if dlg.exec() and dlg.values()["이름"]:
            self.push_undo()
            cur[2].attrs[dlg.values()["이름"]] = ""; cur[0].dirty()
            self.rebuild_group(cur[0].gid); self.refresh_props(); self.show_code()

    def del_attr_row(self):
        cur = self._cur_prim(); r = self.attr_tbl.currentRow()
        if not cur or r < 0 or not self.attr_tbl.item(r, 0):
            return
        n = self.attr_tbl.item(r, 0).text()
        if n in cur[2].attrs:
            self.push_undo(); del cur[2].attrs[n]; cur[0].dirty()
            self.rebuild_group(cur[0].gid); self.refresh_props(); self.show_code()

    def meta_changed(self, r, c):
        if self._loading:
            return
        gs = self.selected_groups()
        if len(gs) != 1:
            return
        g = gs[0]; self.push_undo()
        meta = []
        for i in range(self.meta_tbl.rowCount()):
            n = (self.meta_tbl.item(i, 0).text() if self.meta_tbl.item(i, 0) else "").strip()
            v = self.meta_tbl.item(i, 1).text() if self.meta_tbl.item(i, 1) else ""
            if n:
                old = next((x for x in g.meta if x[0] == n), None)
                meta.append((n, v, old[2] if old else True))
        g.meta = meta; g.dirty()
        self.rebuild_group(g.gid); self.show_code()

    def add_meta_row(self):
        self._loading = True
        r = self.meta_tbl.rowCount(); self.meta_tbl.insertRow(r)
        self.meta_tbl.setItem(r, 0, QTableWidgetItem("")); self.meta_tbl.setItem(r, 1, QTableWidgetItem(""))
        self._loading = False
        self.meta_tbl.editItem(self.meta_tbl.item(r, 0))

    def del_meta_row(self):
        r = self.meta_tbl.currentRow()
        if r >= 0:
            self.meta_tbl.removeRow(r); self.meta_changed(r, 0)

    # ------------------------------------------------------------------ 코드 편집
    def show_code(self):
        gs = self.selected_groups()
        self.code.setPlainText(gs[0].to_xml().replace("\r\n", "\n") if len(gs) == 1 else "")
        self.code.setReadOnly(len(gs) != 1)

    def apply_code(self):
        gs = self.selected_groups()
        if len(gs) != 1:
            QMessageBox.information(self, tr("코드 편집"), tr("한 개의 그룹을 선택하세요")); return
        try:
            ng = parse_group_xml(self.code.toPlainText())
        except Exception as ex:
            QMessageBox.warning(self, tr("코드 오류"), str(ex)); return
        old = gs[0]
        if ng.gid != old.gid and any(x.gid == ng.gid for x in self.doc.groups):
            QMessageBox.warning(self, tr("코드 오류"), "id-%d 가 이미 존재합니다." % ng.gid); return
        self.push_undo()
        idx = next(i for i, x in enumerate(self.doc.items) if x is old)
        self.doc.items[idx] = ng
        self.sel_prims = []
        self.rebuild()
        for i in self.items:
            i.setSelected(i.grp.gid == ng.gid)
        self.refresh_all()
        self.statusBar().showMessage(tr("코드 적용 완료"))

    # ------------------------------------------------------------------ 편집 : 이동/삭제/클립보드/undo
    def push_undo(self):
        self.undo_stack.append(self.doc.to_xml())
        if len(self.undo_stack) > 80:
            self.undo_stack.pop(0)
        self.redo_stack.clear()
        self.modified = True

    def undo(self):
        if self.undo_stack:
            self.redo_stack.append(self.doc.to_xml()); self._restore(self.undo_stack.pop())

    def redo(self):
        if self.redo_stack:
            self.undo_stack.append(self.doc.to_xml()); self._restore(self.redo_stack.pop())

    def _restore(self, xml):
        path, title = self.doc.path, self.doc.title
        self.doc = Doc.parse(xml); self.doc.path, self.doc.title = path, title
        self.sel_prims = []
        self.rebuild()

    def move_selected(self):
        moved = [i for i in self.items if i.isSelected() and (abs(i.pos().x()) > 1e-6 or abs(i.pos().y()) > 1e-6)]
        if not moved:
            return
        self.push_undo()
        for i in moved:
            i.grp.translate(i.pos().x(), i.pos().y())
        for i in moved:
            self.rebuild_group(i.grp.gid)
        self.refresh_props(); self.show_code()           # 캔버스에서 바꾼 위치가 attribute(x,y,d..)에 즉시 반영

    def delete_selected(self):
        if self.sel_prims:
            self.push_undo()
            by = {g.gid: g for g in self.doc.groups}
            for gid in {g for g, _ in self.sel_prims}:
                ks = sorted({k for g, k in self.sel_prims if g == gid}, reverse=True)
                for k in ks:
                    if gid in by and k < len(by[gid].prims):
                        del by[gid].prims[k]
                by[gid].dirty()
            self.sel_prims = []
            self.rebuild(); return
        gs = self.selected_groups()
        if gs:
            self.push_undo()
            for g in gs:
                self.doc.remove(g)
            self.rebuild()

    def _collect_clip(self):
        if self.sel_prims:
            by = {g.gid: g for g in self.doc.groups}
            xs = [by[g].prims[k].to_xml() for g, k in sorted(self.sel_prims) if g in by and k < len(by[g].prims)]
            return {"kind": "prims", "xml": xs}
        gs = self.selected_groups()
        if gs:
            return {"kind": "groups", "xml": [g.to_xml() for g in gs]}
        return None

    def copy(self):
        c = self._collect_clip()
        if c:
            self.clip = c
            QApplication.clipboard().setText("\n".join(c["xml"]))
            self.statusBar().showMessage("%s: %d" % (tr("복사"), len(c["xml"])))

    def cut(self):
        self.copy()
        if self.clip:
            self.delete_selected()

    def paste(self):
        from model import parse_prim_xml
        clip = self.clip
        if clip is None:
            txt = QApplication.clipboard().text().strip()
            if txt.startswith("<g "):
                clip = {"kind": "groups", "xml": re.findall(r'<g id="id-\d+".*?</g>', txt, re.S)}
            elif txt.startswith("<"):
                clip = {"kind": "prims", "xml": [l for l in txt.splitlines() if l.strip()]}
        if not clip:
            self.statusBar().showMessage(tr("클립보드가 비어 있습니다.")); return
        if clip["kind"] == "prims":
            gs = self.selected_groups()
            if len(gs) != 1:
                self.statusBar().showMessage(tr("붙여넣기 대상 그룹을 선택하세요.")); return
            self.push_undo(); g = gs[0]; start = len(g.prims)
            for x in clip["xml"]:
                try:
                    g.prims.append(parse_prim_xml(x))
                except Exception:
                    pass
            g.dirty(); self.sel_prims = [(g.gid, k) for k in range(start, len(g.prims))]
            self.rebuild(); return
        self.push_undo(); new = []
        for x in clip["xml"]:
            try:
                g = parse_group_xml(x)
            except Exception:
                continue
            g.gid = self.doc.next_id()
            g.translate(10, 10)
            tg = g.get("tag", "")
            if tg and tg != "AUTO_GENERATED":
                g.set("tag", re.sub(r"_\d+_$", "_%d_" % (960000 + g.gid), tg) if re.search(r"_\d+_$", tg) else tg + "_c%d" % g.gid)
            self.doc.add(g); new.append(g.gid)
        self.sel_prims = []
        self.rebuild()
        for i in self.items:
            i.setSelected(i.grp.gid in new)
        self.refresh_all()

    def keyPressEvent(self, ev):
        super().keyPressEvent(ev)

    # ------------------------------------------------------------------ 파일
    @staticmethod
    def default_canvas():
        try:
            w = float(i18n.get_setting("canvas_w", 1874.25)); h = float(i18n.get_setting("canvas_h", 1251))
            return (w, h) if w > 0 and h > 0 else (1874.25, 1251.0)
        except Exception:
            return 1874.25, 1251.0

    def set_default_canvas(self):
        w, h = self.default_canvas()
        dlg = FormDialog(self, tr("기본 캔버스 크기…"), [("캔버스 폭", fmt(w)), ("캔버스 높이", fmt(h))])
        if dlg.exec():
            try:
                nw, nh = (float(dlg.values()[k]) for k in ("캔버스 폭", "캔버스 높이"))
                assert nw > 0 and nh > 0
            except Exception:
                QMessageBox.warning(self, tr("기본 캔버스 크기…"), tr("숫자를 입력하세요 (>0)")); return
            i18n.set_setting("canvas_w", nw); i18n.set_setting("canvas_h", nh)
            self.statusBar().showMessage("%s%s × %s" % (tr("기본 캔버스 크기 저장: "), fmt(nw), fmt(nh)))

    @staticmethod
    def blank_doc(nw, nh, title="new_wiring"):
        d = Doc(); d.viewbox = [0.0, 0.0, nw, nh]; d.title = title
        rw, rh = nw - 0.2325, nh - 0.3765
        for gid, cls, st, fl in ((2, "rectangle", "#ffffff", "#ffffff"), (3, "xygrid", "none", "none")):
            d.add(parse_group_xml('<g id="id-%d" class="%s">\n<rect x="-0.15" y="-0.0345" width="%s" height="%s" stroke="%s" fill="%s" stroke-width="0.75"/>\n</g>' % (gid, cls, fmt(rw), fmt(rh), st, fl)))
        return d

    def new_doc(self):
        if self.modified and QMessageBox.question(self, tr("새 도면"), tr("새 도면을 만들기 전에 현재 변경 내용을 버릴까요?")) != QMessageBox.StandardButton.Yes:
            return
        w, h = self.default_canvas()
        dlg = FormDialog(self, tr("새 도면"), [("도면 이름", "new_wiring"), ("캔버스 폭", fmt(w)), ("캔버스 높이", fmt(h))])
        if not dlg.exec():
            return
        v = dlg.values()
        try:
            nw, nh = float(v["캔버스 폭"]), float(v["캔버스 높이"])
            assert nw > 0 and nh > 0
        except Exception:
            QMessageBox.warning(self, tr("새 도면"), tr("숫자를 입력하세요 (>0)")); return
        d = self.blank_doc(nw, nh, v["도면 이름"] or "new_wiring")
        self.doc = d; self.sel_prims = []; self.extra_gids = set()
        self.undo_stack.clear(); self.redo_stack.clear(); self.modified = False
        self.setWindowTitle("%s v%s - %s" % (APP_NAME, VERSION, d.title))
        self.rebuild(); self.fit(); QTimer.singleShot(0, self.fit)
        self.run_check()
        self.statusBar().showMessage("%s: %s × %s" % (tr("새 도면"), fmt(nw), fmt(nh)))

    def open_file(self, path=None):
        if not path:
            path, _ = QFileDialog.getOpenFileName(self, tr("열기"), "", "WD (*.pdf *.svg);;PDF (*.pdf);;SVG (*.svg)")
        if not path:
            return
        try:
            doc, imp = load_any(path)
        except Exception as ex:
            QMessageBox.critical(self, tr("열기 실패"), str(ex)); return
        self.doc = doc; self.sel_prims = []; self.extra_gids = set()
        self.undo_stack.clear(); self.redo_stack.clear()
        self.modified = path.lower().endswith(".pdf")
        self.setWindowTitle("%s v%s - %s" % (APP_NAME, VERSION, os.path.basename(path)))
        self.rebuild(); self.fit(); QTimer.singleShot(0, self.fit); QTimer.singleShot(150, self.fit)
        msg = tr("열기 완료: ") + os.path.basename(path)
        if imp is not None:
            st = imp.stats
            msg += "  | wire %d, component %d, inline %d, reference %d, SP %d, twist %d, unshielded %d" % (
                st["wire"], st["component"], st["inline"], st["reference"], st["sp"], st["twist"], st["unshielded"])
            if imp.warn:
                self._warn_box = QMessageBox(QMessageBox.Icon.Information, tr("변환 경고"), "\n".join(imp.warn), parent=self)
                self._warn_box.setModal(False); self._warn_box.show()
        self.statusBar().showMessage(msg)
        self.run_check()

    def save_svg(self):
        if not self.doc.path:
            return self.save_svg_as()
        export_svg(self.doc, self.doc.path); self.modified = False
        self.statusBar().showMessage(tr("저장: ") + self.doc.path)

    def save_svg_as(self):
        path, _ = QFileDialog.getSaveFileName(self, tr("SVG 저장"), (self.doc.title or "wiring") + ".svg", "SVG (*.svg)")
        if path:
            export_svg(self.doc, path); self.modified = False
            self.setWindowTitle("%s v%s - %s" % (APP_NAME, VERSION, os.path.basename(path)))
            self.statusBar().showMessage(tr("저장: ") + path)

    def export_pdf_dlg(self):
        path, _ = QFileDialog.getSaveFileName(self, tr("PDF 내보내기…"), (self.doc.title or "wiring") + ".pdf", "PDF (*.pdf)")
        if path:
            try:
                export_pdf(self.doc, path); self.statusBar().showMessage(tr("PDF 저장: ") + path)
            except Exception as ex:
                QMessageBox.critical(self, tr("PDF 내보내기 실패"), str(ex))

    # ------------------------------------------------------------------ 도구
    def set_tool(self, key):
        self.cancel_tool()
        self.tool = key
        self.view.setDragMode({"select": QGraphicsView.DragMode.RubberBandDrag, "pan": QGraphicsView.DragMode.ScrollHandDrag}.get(key, QGraphicsView.DragMode.NoDrag))
        self.apply_item_flags(); self.apply_cursor()
        self.statusBar().showMessage(self.tool_actions[key].toolTip())

    def apply_cursor(self):
        self.view.setCursor({"select": Qt.CursorShape.ArrowCursor, "pan": Qt.CursorShape.OpenHandCursor}.get(self.tool, Qt.CursorShape.CrossCursor))

    def cancel_tool(self):
        self._pts = []; self._drag0 = None
        if self._rubber is not None:
            self.scene.removeItem(self._rubber); self._rubber = None

    @staticmethod
    def snap(p, step=1.0):
        return QPointF(round(p.x() / step) * step, round(p.y() / step) * step)

    def tool_press(self, p, ev):
        t = self.tool
        if t == "wire":
            self._pts.append(self.snap(p, 0.5)); self._update_rubber(p)
        elif t == "component":
            self._drag0 = p
        elif t == "inline":
            w, d, q = E.nearest_wire(self.doc, (p.x(), p.y()))
            x, y = (q if (w and d < 15) else (p.x(), p.y()))
            dlg = FormDialog(self, tr("Inline"), [("ref (94/번호:핀)", "94/")])
            if dlg.exec():
                self.push_undo()
                self.doc.add(E.inline_group(self.doc, x, y, dlg.values()["ref (94/번호:핀)"], vertical=bool(ev.modifiers() & Qt.KeyboardModifier.ShiftModifier)))
                self.rebuild()
        elif t == "reference":
            dlg = FormDialog(self, tr("Reference"), [("ref (31/숫자)", "31/")])
            if dlg.exec():
                self.push_undo(); self.doc.add(E.reference_group(self.doc, p.x(), p.y(), dlg.values()["ref (31/숫자)"])); self.rebuild()
        elif t == "sp":
            w, d, q = E.nearest_wire(self.doc, (p.x(), p.y()))
            if not w:
                self.statusBar().showMessage(tr("wire 가 없습니다.")); return
            dlg = FormDialog(self, tr("Splice(SP)"), [("라벨 (SP숫자문자)", "SP")])
            if dlg.exec():
                self.push_undo(); pts = []
                for pr in w.prims:
                    if pr.tag == "path" and pr.attrs.get("stroke") == "#000000":
                        pts = path_points(pr.attrs["d"]); break
                ends = [pts[0], pts[-1]] if pts else [q]
                c = min(ends, key=lambda e: math.dist(e, (p.x(), p.y())))
                w.prims.append(E.dot_prim(*c)); w.prims.extend(E.sp_prims(c[0], c[1], dlg.values()["라벨 (SP숫자문자)"]))
                w.dirty(); self.rebuild_group(w.gid)
        elif t in ("twist", "unshielded"):
            w, d, q = E.nearest_wire(self.doc, (p.x(), p.y()))
            if not w:
                self.statusBar().showMessage(tr("wire 가 없습니다.")); return
            dlg = FormDialog(self, tr("Twist" if t == "twist" else "Unshielded"), [("라벨", "T2_25_T01_01" if t == "twist" else "MOAS_S01_01")])
            if dlg.exec():
                self.push_undo(); w.prims.extend(E.twist_prims(p.x(), p.y(), dlg.values()["라벨"], t == "unshielded")); w.dirty(); self.rebuild_group(w.gid)
        elif t == "text":
            dlg = FormDialog(self, tr("Text"), [("내용", "")])
            if dlg.exec() and dlg.values()["내용"]:
                self.push_undo(); s = dlg.values()["내용"]
                g = Group(gid=self.doc.next_id(), cls="text")
                g.meta = [("type", "text", True), ("tag", E.next_tag(self.doc, "gr_", "_8_"), True)]
                g.prims.append(E._text(p.x(), p.y(), s, size=12.1398, length=len(s) * 7))
                self.doc.add(g); self.rebuild()

    def _update_rubber(self, cur):
        if self._rubber is not None:
            self.scene.removeItem(self._rubber)
        path = QPainterPath(self._pts[0])
        for q in self._pts[1:]:
            path.lineTo(q)
        path.lineTo(cur)
        pen = QPen(QColor("#0a84ff"), 1, Qt.PenStyle.DashLine); pen.setCosmetic(True)
        self._rubber = self.scene.addPath(path, pen); self._rubber.setZValue(1000)

    def tool_move(self, p):
        if self.tool == "wire" and self._pts:
            self._update_rubber(p)
        elif self.tool == "component" and self._drag0 is not None:
            if self._rubber is not None:
                self.scene.removeItem(self._rubber)
            pen = QPen(QColor("#0a84ff"), 1, Qt.PenStyle.DashLine); pen.setCosmetic(True)
            self._rubber = self.scene.addRect(QRectF(self._drag0, p).normalized(), pen); self._rubber.setZValue(1000)

    def tool_release(self, p):
        if self.tool == "component" and self._drag0 is not None:
            r = QRectF(self._drag0, p).normalized()
            self.cancel_tool()
            if r.width() < 8 or r.height() < 8:
                return
            dlg = FormDialog(self, tr("Component"), [("ref (숫자/숫자)", "4/"), ("description", ""), ("harness", "*opt*"), ("variant", "*opt*")])
            if dlg.exec():
                v = dlg.values(); self.push_undo()
                self.doc.add(E.component_group(self.doc, round(r.x(), 3), round(r.y(), 3), round(r.width(), 3), round(r.height(), 3),
                                               v["ref (숫자/숫자)"], v["description"], v["harness"], v["variant"]))
                self.rebuild()

    def finish_wire(self):
        pts = [(q.x(), q.y()) for q in self._pts]
        dedup = []
        for q in pts:
            if not dedup or math.dist(q, dedup[-1]) > 0.5:
                dedup.append(q)
        self.cancel_tool()
        if len(dedup) < 2:
            return
        dlg = FormDialog(self, tr("Wire"), [("ref (신호명+문자)", ""), ("harness", ""), ("variant", "*opt*"), ("option", ""), ("area", "0.35"), ("color", ""), ("option_description", "")])
        if dlg.exec():
            v = dlg.values(); self.push_undo()
            self.doc.add(E.wire_group(self.doc, dedup, v["ref (신호명+문자)"], v["variant"], v["option"], v["harness"], v["area"], v["color"], v["option_description"]))
            self.rebuild()

    # ------------------------------------------------------------------ 규칙
    def run_check(self):
        self.issues = rules.check(self.doc)
        self.issue_list.clear()
        for i in self.issues:
            it = QListWidgetItem("[%s] id-%d %s %s" % (tr("오류") if i.level == "error" else tr("경고"), i.gid, i.msg, tr("(자동수정 가능)") if i.fixable else ""))
            it.setData(Qt.ItemDataRole.UserRole, i.gid)
            it.setForeground(QColor("#c0392b" if i.level == "error" else "#b9770e"))
            self.issue_list.addItem(it)
        e = sum(1 for i in self.issues if i.level == "error")
        self.summary.setText(tr("오류 %d, 경고 %d, 자동수정 가능 %d") % (e, len(self.issues) - e, sum(1 for i in self.issues if i.fixable)))

    def run_fix(self):
        self.push_undo(); n = rules.fix(self.doc); self.sel_prims = []
        self.rebuild(); self.run_check()
        self.statusBar().showMessage(tr("자동 수정 %d건 적용") % n)

    def run_auto(self):
        self.push_undo(); n = rules.regenerate_auto_symbols(self.doc); self.sel_prims = []
        self.rebuild(); self.run_check()
        self.statusBar().showMessage(tr("AUTO_GENERATED 심볼 %d개 생성") % n)

    def goto_issue(self, item):
        gid = item.data(Qt.ItemDataRole.UserRole)
        self.sel_prims = []
        self._busy = True
        for i in self.items:
            i.setSelected(i.grp.gid == gid)
        self._busy = False
        self.refresh_all()
        if gid in self.by_gid:
            self.view.centerOn(self.by_gid[gid])

    def closeEvent(self, ev):
        if self.modified:
            r = QMessageBox.question(self, tr("종료 확인"), tr("저장하지 않은 변경 내용이 있습니다. 종료할까요?"))
            if r != QMessageBox.StandardButton.Yes:
                ev.ignore(); return
        ev.accept()


def main(argv=None):
    argv = argv or sys.argv
    i18n.load_lang()
    app = QApplication(argv)
    app.setApplicationName(APP_NAME)
    w = MainWindow()
    w.show()
    if len(argv) > 1 and os.path.exists(argv[1]):
        w.open_file(argv[1])
    sys.exit(app.exec())
