"""다국어(한국어/English). 한국어 문자열이 key 이다 : tr("열기") -> 영어 모드에서는 EN["열기"]."""
import json
import os

LANG = "ko"
_SETTINGS = os.path.join(os.path.expanduser("~"), ".wdstudio_settings.json")


def load_lang():
    global LANG
    try:
        with open(_SETTINGS, encoding="utf-8") as f:
            LANG = json.load(f).get("lang", "ko")
    except Exception:
        LANG = "ko"
    return LANG


def set_lang(lang):
    global LANG
    LANG = lang if lang in ("ko", "en") else "ko"
    set_setting("lang", LANG)


def _read():
    try:
        with open(_SETTINGS, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def get_setting(key, default=None):
    return _read().get(key, default)


def set_setting(key, value):
    d = _read(); d[key] = value
    try:
        with open(_SETTINGS, "w", encoding="utf-8") as f:
            json.dump(d, f)
    except Exception:
        pass


def tr(s):
    if LANG == "en":
        return EN.get(s, s)
    return s


EN = {
    # 메뉴
    "파일": "File", "편집": "Edit", "보기": "View", "그리기": "Draw", "규칙": "Rules", "설정": "Settings", "도움말": "Help",
    "열기 (PDF/SVG)…": "Open (PDF/SVG)…", "SVG 저장": "Save SVG", "다른 이름으로 SVG 저장…": "Save SVG As…",
    "PDF 내보내기…": "Export PDF…", "종료": "Exit",
    "실행 취소": "Undo", "다시 실행": "Redo", "잘라내기": "Cut", "복사": "Copy", "붙여넣기": "Paste", "삭제": "Delete",
    "전체 선택": "Select All", "전체 보기": "Fit View", "확대": "Zoom In", "축소": "Zoom Out",
    "규칙 검사": "Rule Check", "자동 수정": "Auto Fix", "AUTO_GENERATED 심볼 재생성": "Regenerate AUTO_GENERATED symbols",
    "규칙 설명…": "Rule Help…", "WD Studio 정보…": "About WD Studio…", "언어 / Language": "Language / 언어",
    "한국어": "Korean", "English": "English",
    # 툴바
    "선택": "Select", "이동": "Pan", "선택/이동": "Select / Pan", "도구": "Tools", "파일 도구": "File", "편집 도구": "Edit", "그리기 도구": "Draw", "규칙 도구": "Rules",
    "Wire": "Wire", "Component": "Component", "Inline": "Inline", "Reference": "Reference", "Splice(SP)": "Splice(SP)",
    "Twist": "Twist", "Unshielded": "Unshielded", "Text": "Text", "열기": "Open", "저장": "Save", "PDF": "PDF",
    "검사": "Check", "자동수정": "Auto Fix", "전체보기": "Fit",
    "선택: 클릭/드래그로 요소 선택, 선택 후 드래그하면 요소 이동": "Select: click/drag to select; drag a selected element to move it",
    "이동(Pan): 마우스 드래그로 화면을 이동 (마우스 가운데 버튼 드래그도 가능)": "Pan: drag with the mouse to move the view (middle-button drag also works)",
    "클릭으로 꺾임점 추가, 더블클릭/Enter 로 완료": "Click to add bend points, double-click/Enter to finish",
    "드래그하여 사각형 생성": "Drag to create a rectangle", "wire 위를 클릭 (Shift: 세로)": "Click on a wire (Shift: vertical)",
    "클릭하여 reference connector 추가": "Click to add a reference connector", "wire 끝점 근처 클릭": "Click near a wire end",
    "wire 사이를 클릭 (왼쪽-위 모서리)": "Click between wires (top-left corner)", "wire 사이를 클릭": "Click between wires",
    "클릭하여 일반 텍스트 추가": "Click to add free text",
    # 도크/패널
    "요소 목록 / SVG 코드": "Elements / SVG code", "속성": "Properties", "규칙 검사 패널": "Rule check", "코드 편집": "Code editor",
    "metadata": "metadata", "visible data": "visible data", "meta": "meta", "값": "Value", "속성명": "Attribute",
    "meta 추가": "Add meta", "meta 삭제": "Delete meta", "속성 추가": "Add attribute", "속성 삭제": "Delete attribute",
    "선택 없음": "Nothing selected", "선택 %d개": "%d selected", "적용": "Apply", "되돌리기": "Revert", "AUTO_GENERATED": "AUTO_GENERATED",
    "선택한 그룹(id)의 SVG 코드를 직접 수정하고 [적용]을 누르세요": "Edit the SVG code of the selected group (id) and press [Apply]",
    "한 개의 그룹을 선택하세요": "Select a single group", "코드 적용 완료": "Code applied", "코드 오류": "Code error",
    "오류": "Error", "경고": "Warning", "자동수정 가능": "auto-fixable", "오류 %d, 경고 %d, 자동수정 가능 %d": "Errors %d, warnings %d, auto-fixable %d",
    "(자동수정 가능)": "(auto-fixable)", "자동 수정 %d건 적용": "Auto-fix applied: %d", "AUTO_GENERATED 심볼 %d개 생성": "AUTO_GENERATED symbols created: %d",
    "<metadata>": "<metadata>",
    # 메시지
    "PDF 또는 SVG 파일을 여세요 (Ctrl+O)": "Open a PDF or SVG file (Ctrl+O)", "열기 실패": "Open failed", "변환 경고": "Conversion warnings",
    "열기 완료: ": "Opened: ", "저장: ": "Saved: ", "PDF 저장: ": "PDF saved: ", "PDF 내보내기 실패": "PDF export failed",
    "종료 확인": "Exit", "저장하지 않은 변경 내용이 있습니다. 종료할까요?": "There are unsaved changes. Exit anyway?",
    "wire 가 없습니다.": "There is no wire.", "ref (94/번호:핀)": "ref (94/number:pin)", "ref (31/숫자)": "ref (31/number)",
    "라벨 (SP숫자문자)": "Label (SP<digits><letters>)", "라벨": "Label", "내용": "Text", "ref (숫자/숫자)": "ref (number/number)", "description": "description",
    "harness": "harness", "variant": "variant", "ref (신호명+문자)": "ref (signal+letter)", "option": "option", "area": "area", "color": "color",
    "option_description": "option_description", "클립보드가 비어 있습니다.": "Clipboard is empty.", "붙여넣기 대상 그룹을 선택하세요.": "Select a target group to paste into.",
    "다른 id 로 이동": "Moved to another id", "요소(그룹)를 다른 id 로 병합하시겠습니까? 원래 id 는 삭제됩니다.": "Merge this element (group) into another id? The original id will be deleted.",
    "병합": "Merge", "이동 완료": "Moved", "시트 정보": "Sheet",
    # 정보
    "정보": "About", "개발자": "Developer", "버전": "Version", "빌드 날짜": "Build date",
    "PDF 배선도를 배선도 템플릿/WDID 규칙에 맞는 SVG 로 변환하고 편집하는 도구": "Converts PDF wiring diagrams to template/WDID-compliant SVG and lets you edit them",
    "규칙 설명": "Rule help", "닫기": "Close", "드래그하여 이동 / Ctrl+C,X,V": "Drag to move / Ctrl+C,X,V",
    "캔버스": "Canvas", "새로 만들기…": "New…", "새 도면": "New drawing", "기본 캔버스 크기…": "Default canvas size…", "도면 이름": "Drawing name",
    "캔버스 폭": "Canvas width", "캔버스 높이": "Canvas height", "기본값으로 저장": "Save as default",
    "새 도면을 만들기 전에 현재 변경 내용을 버릴까요?": "Discard current changes and create a new drawing?",
    "새 도면의 기본 캔버스 크기를 설정합니다 (SVG 단위)": "Set the default canvas size for new drawings (SVG units)",
    "기본 캔버스 크기 저장: ": "Default canvas size saved: ", "숫자를 입력하세요 (>0)": "Enter a number (>0)",
    "새 속성 이름": "New attribute name", "이름": "Name",
}
