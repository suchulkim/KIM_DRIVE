#!/usr/bin/env python3
"""배선도 편집기.

GUI :  python main.py [file.pdf|file.svg]
CLI :  python main.py --convert in.pdf out.svg [--pdf out.pdf] [--check] [--fix] [--auto]
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def cli(args):
    import rules
    from export import load_any, export_pdf, export_svg
    src, dst = args[0], args[1]
    doc, imp = load_any(src)
    if "--fix" in args:
        print("auto-fix:", rules.fix(doc))
    if "--auto" in args:
        print("AUTO_GENERATED:", rules.regenerate_auto_symbols(doc))
    if imp is not None:
        print(imp.stats)
        for w in imp.warn:
            print("warn:", w)
    export_svg(doc, dst)
    if "--pdf" in args:
        export_pdf(doc, args[args.index("--pdf") + 1])
    if "--check" in args:
        for i in rules.check(doc):
            print("[%s] id-%d %s" % (i.level, i.gid, i.msg))


if __name__ == "__main__":
    if len(sys.argv) > 3 and sys.argv[1] == "--convert":
        cli(sys.argv[2:])
    else:
        from gui import main
        main()
