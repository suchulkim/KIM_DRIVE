"""SVG 배선도 문서 모델 (AIM 형식 유지).

- 파싱된 그룹이 수정되지 않았으면 원본 텍스트를 그대로 출력(무손실 왕복).
- 수정된(dirty) 그룹만 AIM 포맷으로 재생성.
"""
from __future__ import annotations
import re
import math
from dataclasses import dataclass, field
from typing import Optional

NL = "\r\n"


def fmt(v: float) -> str:
    """AIM 스타일 숫자 서식(유효숫자 6자리)."""
    s = "%.6g" % v
    if "e" in s:
        s = ("%.6f" % v).rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


# ----------------------------------------------------------------------------
# path 데이터 도구
# ----------------------------------------------------------------------------
_TOK = re.compile(r"[MLHVCSQTAZmlhvcsqtaz]|-?\d*\.?\d+(?:[eE][-+]?\d+)?")
_NARGS = {"M": 2, "L": 2, "H": 1, "V": 1, "C": 6, "S": 4, "Q": 4, "T": 2, "A": 7, "Z": 0}


def parse_path(d: str):
    """[(cmd, [numbers])] (명령별 한 세트씩). 절대좌표 명령만 지원(AIM 출력은 절대좌표)."""
    toks = _TOK.findall(d)
    out, i, cmd = [], 0, None
    while i < len(toks):
        t = toks[i]
        if t.isalpha():
            cmd = t.upper()
            i += 1
            if cmd == "Z":
                out.append(("Z", []))
            continue
        n = _NARGS[cmd]
        out.append((cmd, [float(x) for x in toks[i:i + n]]))
        i += n
        if cmd == "M":
            cmd = "L"
    return out


def build_path(cmds) -> str:
    parts = []
    for c, a in cmds:
        if c == "Z":
            parts.append("Z")
        elif c == "A":
            parts.append("A%s,%s %s %d,%d, %s,%s " % (fmt(a[0]), fmt(a[1]), fmt(a[2]), int(a[3]), int(a[4]), fmt(a[5]), fmt(a[6])))
        else:
            parts.append(c + ",".join(fmt(x) for x in a))
    s = " ".join(p for p in parts)
    return s.replace("  ", " ")


def path_points(d: str):
    """끝점(그리기 경로상의 점) 리스트."""
    pts = []
    for c, a in parse_path(d):
        if c in ("M", "L", "T"):
            pts.append((a[0], a[1]))
        elif c == "H":
            pts.append((a[0], pts[-1][1] if pts else 0))
        elif c == "V":
            pts.append((pts[-1][0] if pts else 0, a[0]))
        elif c in ("C", "S", "Q"):
            pts.append((a[-2], a[-1]))
        elif c == "A":
            pts.append((a[5], a[6]))
    return pts


def translate_path(d: str, dx: float, dy: float) -> str:
    out = []
    for c, a in parse_path(d):
        a = list(a)
        if c in ("M", "L", "T"):
            a[0] += dx; a[1] += dy
        elif c == "H":
            a[0] += dx
        elif c == "V":
            a[0] += dy
        elif c in ("C", "S", "Q"):
            for k in range(0, len(a), 2):
                a[k] += dx; a[k + 1] += dy
        elif c == "A":
            a[5] += dx; a[6] += dy
        out.append((c, a))
    return build_path(out)


# ----------------------------------------------------------------------------
# 요소 모델
# ----------------------------------------------------------------------------
@dataclass
class Prim:
    tag: str                      # path | rect | ellipse | text
    attrs: dict                   # 속성(순서 유지)
    text: str = ""                # <text> 내용

    def to_xml(self) -> str:
        a = " ".join('%s="%s"' % (k, v) for k, v in self.attrs.items())
        if self.tag == "text":
            return "<text %s><![CDATA[%s]]></text>" % (a, self.text)
        return "<%s %s/>" % (self.tag, a)

    def translate(self, dx: float, dy: float):
        t, at = self.tag, self.attrs
        if t == "path":
            at["d"] = translate_path(at["d"], dx, dy)
        elif t == "rect":
            at["x"] = fmt(float(at["x"]) + dx); at["y"] = fmt(float(at["y"]) + dy)
        elif t == "ellipse":
            at["cx"] = fmt(float(at["cx"]) + dx); at["cy"] = fmt(float(at["cy"]) + dy)
        elif t == "text":
            x = float(at["x"]) + dx; y = float(at["y"]) + dy
            at["x"] = fmt(x); at["y"] = fmt(y)
            m = re.match(r"rotate\(([-\d.]+),", at.get("transform", ""))
            ang = m.group(1) if m else "0"
            at["transform"] = "rotate(%s,%s,%s)" % (ang, fmt(x), fmt(y))

    def bbox(self):
        t, at = self.tag, self.attrs
        if t == "path":
            pts = path_points(at["d"])
            if not pts:
                return None
            xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
            return (min(xs), min(ys), max(xs), max(ys))
        if t == "rect":
            x, y, w, h = (float(at[k]) for k in ("x", "y", "width", "height"))
            return (x, y, x + w, y + h)
        if t == "ellipse":
            cx, cy, rx, ry = (float(at[k]) for k in ("cx", "cy", "rx", "ry"))
            return (cx - rx, cy - ry, cx + rx, cy + ry)
        if t == "text":
            x, y = float(at["x"]), float(at["y"])
            L = float(at.get("textLength", 20)); fs = float(at.get("font-size", 8))
            m = re.match(r"rotate\(([-\d.]+),", at.get("transform", ""))
            ang = float(m.group(1)) % 360 if m else 0
            anchor = at.get("text-anchor", "start")
            x0 = x - (L if anchor == "end" else 0)
            if ang == 0:
                return (x0, y - fs, x0 + L, y + fs * .25)
            if ang == 270:
                return (x - fs, y - L if anchor != "end" else y, x + fs * .25, y if anchor != "end" else y + L)
            return (x - fs, y - fs, x + fs, y + fs)
        return None


@dataclass
class Group:
    gid: int
    cls: str
    meta: list = field(default_factory=list)   # [(name, value, cdata)]
    prims: list = field(default_factory=list)
    raw: Optional[str] = None                   # 원본 텍스트(미수정 시 그대로 출력)
    has_meta_block: bool = True

    # --- metadata 접근
    def get(self, name, default=None):
        for n, v, _ in self.meta:
            if n == name:
                return v
        return default

    def set(self, name, value, cdata=True):
        for i, (n, v, c) in enumerate(self.meta):
            if n == name:
                self.meta[i] = (n, value, c)
                self.dirty()
                return
        self.meta.append((name, value, cdata))
        self.dirty()

    def has(self, name):
        return any(n == name for n, _, _ in self.meta)

    @property
    def type(self):
        return self.get("type", "")

    def dirty(self):
        self.raw = None

    @property
    def kind(self) -> str:
        """wire | component | inline_connector | reference_connector | drawing | text | rectangle | xygrid | other"""
        t = self.type
        if self.cls == "wire":
            return "wire"
        if t in ("component", "inline_connector", "reference_connector", "drawing"):
            return t
        if self.cls in ("rectangle", "xygrid", "text"):
            return self.cls
        return "other"

    # --- 이동
    def translate(self, dx, dy):
        for p in self.prims:
            p.translate(dx, dy)
        self.dirty()

    def clone(self):
        import copy
        g = Group(self.gid, self.cls, raw=self.raw)
        g.meta = list(self.meta); g.has_meta_block = self.has_meta_block
        g.prims = [Prim(p.tag, dict(p.attrs), p.text) for p in self.prims]
        return g

    def bbox(self):
        bs = [b for b in (p.bbox() for p in self.prims) if b]
        if not bs:
            return None
        return (min(b[0] for b in bs), min(b[1] for b in bs), max(b[2] for b in bs), max(b[3] for b in bs))

    # --- 직렬화
    def meta_xml(self) -> str:
        k = self.kind
        lines = []
        one_line = k in ("wire", "inline_connector")
        buf = []
        for n, v, c in self.meta:
            s = ('<meta name="%s"><![CDATA[%s]]></meta>' % (n, v)) if c else ('<meta name="%s">%s</meta>' % (n, v))
            if one_line and n not in ("type", "tag"):
                buf.append(s)
            else:
                if buf:
                    lines.append("".join(buf)); buf = []
                lines.append(s)
        if buf:
            lines.append("".join(buf))
        return NL.join(lines)

    def to_xml(self) -> str:
        if self.raw is not None:
            return self.raw
        out = ['<g id="id-%d" class="%s">' % (self.gid, self.cls)]
        if self.has_meta_block and self.meta:
            out.append("<metadata>")
            out.append(self.meta_xml())
            if self.kind in ("component", "reference_connector", "drawing") and self.cls == "symbol":
                out.append("")
            out.append("</metadata>")
        for p in self.prims:
            out.append(p.to_xml())
        out.append("</g>")
        return NL.join(out)


_G_RE = re.compile(r'<g id="id-(\d+)" class="([^"]*)">(.*?)</g>', re.S)
_META_RE = re.compile(r'<meta name="([^"]+)">(?:<!\[CDATA\[(.*?)\]\]>|(.*?))</meta>', re.S)
_PRIM_RE = re.compile(r'<(path|rect|ellipse|text)\b([^>]*?)(?:/>|>(.*?)</text>)', re.S)
_ATTR_RE = re.compile(r'([\w:-]+)="([^"]*)"')


def parse_group(m) -> Group:
    gid, cls, body = int(m.group(1)), m.group(2), m.group(3)
    g = Group(gid, cls, raw=m.group(0))
    mm = re.search(r"<metadata>(.*?)</metadata>", body, re.S)
    g.has_meta_block = mm is not None
    if mm:
        for x in _META_RE.finditer(mm.group(1)):
            if x.group(2) is not None:
                g.meta.append((x.group(1), x.group(2), True))
            else:
                g.meta.append((x.group(1), x.group(3) or "", False))
        body = body.replace(mm.group(0), "")
    for x in _PRIM_RE.finditer(body):
        attrs = dict(_ATTR_RE.findall(x.group(2)))
        txt = ""
        if x.group(1) == "text":
            t = re.search(r"<!\[CDATA\[(.*?)\]\]>", x.group(3) or "", re.S)
            txt = t.group(1) if t else (x.group(3) or "")
        g.prims.append(Prim(x.group(1), attrs, txt))
    return g


def parse_group_xml(text: str) -> Group:
    """<g id="id-N" class="..."> ... </g> 한 개를 Group 으로 파싱 (수동 코드 편집/붙여넣기용). 형식 오류면 ValueError."""
    m = _G_RE.search(text.strip())
    if not m or m.group(0).strip() != text.strip():
        raise ValueError('<g id="id-숫자" class="..."> ... </g> 형식의 단일 그룹이어야 합니다.')
    g = parse_group(m)
    g.raw = None                      # 수정된 코드이므로 재직렬화
    return g


def parse_prim_xml(text: str) -> Prim:
    m = _PRIM_RE.search(text.strip())
    if not m:
        raise ValueError("<path|rect|ellipse|text ...> 형식이 아닙니다.")
    attrs = dict(_ATTR_RE.findall(m.group(2)))
    txt = ""
    if m.group(1) == "text":
        t = re.search(r"<!\[CDATA\[(.*?)\]\]>", m.group(3) or "", re.S)
        txt = t.group(1) if t else (m.group(3) or "")
    return Prim(m.group(1), attrs, txt)


class Doc:
    def __init__(self):
        self.header = ('<?xml version="1.0" encoding="UTF-8"?>' + NL +
                       '<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.0//EN" "http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd">' + NL +
                       '<!--Created with AIM-->' + NL +
                       '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 800">' + NL)
        self.viewbox = [0.0, 0.0, 1000.0, 800.0]
        self.items: list = []        # Group 또는 str(그룹 사이 원문)
        self.path = None
        self.title = ""
        self.after = NL          # </svg> 뒤 원문(AIM 은 개행 없음)

    # --- 접근
    @property
    def groups(self):
        return [i for i in self.items if isinstance(i, Group)]

    def by_id(self, gid):
        for g in self.groups:
            if g.gid == gid:
                return g

    def next_id(self, start=3):
        used = {g.gid for g in self.groups}
        n = max(start, max(used) + 1 if used else start)
        return n

    def add(self, g: Group, index: Optional[int] = None):
        if index is None:
            self.items.append(g)
        else:
            self.items.insert(index, g)
        return g

    def remove(self, g: Group):
        self.items = [i for i in self.items if i is not g]

    # --- 입출력
    @classmethod
    def parse(cls, text: str) -> "Doc":
        d = cls()
        m = re.search(r"<svg\b[^>]*viewBox=\"([^\"]+)\"[^>]*>", text)
        if not m:
            raise ValueError("SVG viewBox를 찾을 수 없습니다.")
        d.header = text[:m.end()]
        d.viewbox = [float(x) for x in m.group(1).replace(",", " ").split()]
        end = text.rfind("</svg>")
        d.after = text[end + 6:] if end >= 0 else NL
        body = text[m.end():end if end >= 0 else len(text)]
        pos = 0
        for gm in _G_RE.finditer(body):
            if gm.start() > pos:
                d.items.append(body[pos:gm.start()])
            d.items.append(parse_group(gm))
            pos = gm.end()
        tail = body[pos:]
        if tail:
            d.items.append(tail)
        for g in d.groups:
            if g.type.startswith("textvar"):
                for p in g.prims:
                    if p.tag == "text":
                        d.title = p.text
        return d

    @classmethod
    def load(cls, path: str) -> "Doc":
        with open(path, "r", encoding="utf-8", newline="") as f:
            d = cls.parse(f.read())
        d.path = path
        return d

    def to_xml(self) -> str:
        # viewBox 반영
        hdr = re.sub(r'viewBox="[^"]+"', 'viewBox="%s"' % " ".join(fmt(v) for v in self.viewbox), self.header, count=1)
        parts = [hdr]
        prev_group = False
        for it in self.items:
            if isinstance(it, Group):
                if prev_group:
                    parts.append(NL)
                parts.append(it.to_xml())
                prev_group = True
            else:
                parts.append(it)
                prev_group = False
        parts.append(("" if parts[-1].endswith("\n") else NL) + "</svg>" + self.after)
        return "".join(parts)

    def save(self, path: str):
        with open(path, "w", encoding="utf-8", newline="") as f:
            f.write(self.to_xml())
        self.path = path
